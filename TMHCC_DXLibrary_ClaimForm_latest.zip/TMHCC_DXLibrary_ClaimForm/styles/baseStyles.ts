import { css } from 'styled-components';

export const baseFormStyles = css`
  /* ── Portal mask overlay ── */
  .claim-form__portal-mask {
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.4);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
  }

  /* ── Two-column page layout ── */
  .claim-form-page {
    display: flex;
    width: 100%;
    flex: 1;
    min-height: 0;
  }

  .claim-form-page__image {
    flex: 0 0 50%;
    align-self: flex-start;
    position: sticky;
    top: 0;
    height: 100vh;
    overflow: hidden;
    background-size: cover;
    background-position: center;
    background-repeat: no-repeat;
    background-color: #f1f5f9;
  }

  .claim-form-page__panel {
    flex: 0 0 50%;
    height: 100%;
    display: flex;
    flex-direction: column;
    min-height: 0;
    overflow: hidden;
    background: #f7f7f8;
  }

  /* ── Step navigation ── */
  .claim-form__step-nav {
    background: transparent;
    padding: 0.75rem 1.25rem;
    display: flex;
    gap: 0.5rem;
    flex-shrink: 0;
  }

  .claim-form__step-card {
    flex: 1;
    min-width: 0;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.75rem 1rem;
    gap: 0.5rem;
    border-radius: 8px;
  }

  .claim-form__step-card--clickable {
    cursor: pointer;
  }

  .claim-form__step-card--complete {
    background: #7fc3ea;
  }

  .claim-form__step-card--current {
    background: #7fc3ea;
  }

  .claim-form__step-card--upcoming {
    background: #C8CDD3;
  }

  .claim-form__step-card-info {
    display: flex;
    flex-direction: column;
    gap: 0.15rem;
  }

  .claim-form__step-card-label {
    font-size: 0.75rem;
    font-weight: 700;
    letter-spacing: 0.01em;
  }

  .claim-form__step-card--complete .claim-form__step-card-label,
  .claim-form__step-card--current .claim-form__step-card-label {
    color: rgba(0, 0, 0, 0.6);
  }

  .claim-form__step-card--upcoming .claim-form__step-card-label {
    color: #8A929B;
  }

  .claim-form__step-card-name {
    font-size: 0.875rem;
    white-space: normal;
    word-break: break-word;
    line-height: 1.2;
  }

  .claim-form__step-card--complete .claim-form__step-card-name,
  .claim-form__step-card--current .claim-form__step-card-name {
    font-weight: 700;
    color: #111827;
  }

  .claim-form__step-card--upcoming .claim-form__step-card-name {
    font-weight: 600;
    color: #8A929B;
  }

  .claim-form__step-card-icon {
    width: 22px;
    height: 22px;
    border-radius: 50%;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 0.65rem;
    font-weight: 700;
  }

  .claim-form__step-card--complete .claim-form__step-card-icon {
    background: #ffffff;
    color: #da2128;
  }

  .claim-form__step-card--current .claim-form__step-card-icon {
    border: 2px solid rgba(0, 0, 0, 0.4);
  }

  .claim-form__step-card--upcoming .claim-form__step-card-icon {
    border: 2px solid #b0b7bf;
  }

  /* ── Form body ── */
  .claim-form {
    flex: 1;
    min-height: 0;
    overflow-y: auto;
    background: transparent;
    padding: 1.25rem 1.5rem;
    font-family: var(--pega-font-family, 'Open Sans', Arial, sans-serif);
  }

  /* ── Sections ── */
  .claim-form__section {
    margin-bottom: 1rem;
    padding: 1.25rem;
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    background: #ffffff;
    box-shadow: 0 1px 3px rgba(0, 0, 0, 0.06);
  }

  .claim-form__section-title {
    margin: 0 0 1rem;
    font-size: 1.1rem;
    color: #111827;
    display: flex;
    align-items: center;
    gap: 0.5rem;
    font-weight: 700;
  }

  .claim-form__section-index {
    width: 22px;
    height: 22px;
    border-radius: 50%;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    font-size: 0.7rem;
    font-weight: 700;
    background: #001b3d;
    color: #ffffff;
    flex-shrink: 0;
  }

  .claim-form__subheading {
    font-size: 0.8rem;
    font-weight: 600;
    color: #374151;
    padding: 0.5rem 0 0.375rem;
    border-bottom: 1px solid #e5e7eb;
    margin-bottom: 0.25rem;
  }
    /* ── Section Variants (NEW) ── */

/* ✅ Bigger main title (Your Details) */
.claim-form__section-title--primary {
  font-size: 1.3rem;
  font-weight: 700;
}

/* ✅ Smaller title (Policyholder Address) */
.claim-form__section-title--secondary {
  font-size: 1rem;
  font-weight: 600;
}

/* ✅ Grey container for grouped fields */
.claim-form__group {
  background: #f7f7f8;
  padding: 1.25rem;
  border-radius: 12px;
  margin-bottom: 1.25rem;
}

/* ✅ Spacing between stacked sections */
.claim-form__section + .claim-form__section {
  margin-top: 1rem;
}
  /* ── Grid & fields ── */
  .claim-form__grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 1rem;
  }
.claim-form__section-title--primary {
  margin-bottom: 0.75rem;
}
  .claim-form__field {
    display: flex;
    flex-direction: column;
    gap: 0.375rem;
    font-size: 0.8rem;
    color: #001b3d;
    font-weight: 500;
  }

  .claim-form__field--full {
    grid-column: 1 / -1;
  }

  .claim-form__field input,
  .claim-form__field select,
  .claim-form__field textarea {
    width: 100%;
    border: 1px solid #d1d5db;
    border-radius: 6px;
    padding: 0.625rem 0.75rem;
    font-size: 0.875rem;
    background: #ffffff;
    color: #001b3d;
    box-sizing: border-box;
    font-family: inherit;
    transition: border-color 0.15s ease, box-shadow 0.15s ease;
  }

  .claim-form__field input:focus,
  .claim-form__field select:focus,
  .claim-form__field textarea:focus {
    outline: none;
    border-color: #1A3D6B;
    box-shadow: 0 0 0 3px rgba(26, 61, 107, 0.15);
  }

  .claim-form__field select {
    appearance: none;
    background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='10' height='6'%3E%3Cpath d='M0 0l5 6 5-6z' fill='%236b7280'/%3E%3C/svg%3E");
    background-repeat: no-repeat;
    background-position: right 0.75rem center;
    background-color: #ffffff;
    padding-right: 2rem;
    cursor: pointer;
  }

  .claim-form__field select option {
    background: #ffffff;
    color: #001b3d;
  }

  .claim-form__field input::placeholder,
  .claim-form__field textarea::placeholder {
    color: #9ca3af;
    font-weight: 400;
  }

  .claim-form__phone-group {
    display: flex;
    gap: 4px;
    align-items: stretch;
  }

  .claim-form__phone-group .claim-form__dialing-select {
    flex-shrink: 0;
    width: auto;
    min-width: 0;
    padding-right: 1.75rem;
    border-radius: 6px;
  }

  .claim-form__phone-group .claim-form__phone-input {
    flex: 1;
    min-width: 0;
    width: 0;
  }

  .claim-form__required-star {
    color: #ef4444;
    margin-left: 0.1em;
  }

  .claim-form__error {
    color: #ef4444;
    font-size: 0.75rem;
    font-weight: 400;
  }

  .claim-form__hint {
    color: #6b7280;
    font-size: 0.72rem;
    font-weight: 400;
  }

  /* ── File upload ── */
  .claim-form__upload-dropzone {
    border: 2px dashed #d1d5db;
    min-height: 140px;
    padding: 1.5rem;
    border-radius: 8px;
    text-align: center;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 0.4rem;
    color: #6b7280;
    position: relative;
    background: transparent;
    transition: border-color 0.15s ease;
  }

  .claim-form__upload-dropzone:hover {
    border-color: #9ca3af;
  }

  .claim-form__upload-dropzone--disabled {
    background: transparent;
    border-color: #e5e7eb;
    cursor: not-allowed;
    pointer-events: none;
    opacity: 0.5;
  }

  .claim-form__upload-spinner {
    display: flex;
    flex-direction: column;
    align-items: center;
    gap: 0.5rem;
    pointer-events: none;
  }

  .claim-form__upload-spinner-text {
    font-size: 0.875rem;
    color: #6b7280;
  }

  .claim-form__file-input {
    opacity: 0;
    position: absolute;
    inset: 0;
    cursor: pointer;
  }

  .claim-form__upload-title {
    margin: 0;
    font-size: 1rem;
    color: #001b3d;
    font-weight: 700;
  }

  .claim-form__upload-subtitle {
    margin: 0;
    font-size: 0.75rem;
    color: #8a96a3;
  }

  .claim-form__file-list {
    margin-top: 0.75rem;
    display: flex;
    flex-direction: column;
    gap: 0.35rem;
  }

  .claim-form__file-list-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 0.5rem;
    padding: 0.4rem 0.6rem;
    border: 1px solid #e5e7eb;
    border-radius: 6px;
    background: #f9fafb;
    font-size: 0.8rem;
    color: #374151;
  }

  .claim-form__delete-file {
    border: none;
    background: transparent;
    color: #9ca3af;
    cursor: pointer;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    padding: 0.2rem;
  }

  .claim-form__delete-file:hover {
    color: #ef4444;
  }

  /* ── Attachment cards ── */
  .claim-form__attachment-list {
    margin-top: 0.75rem;
    display: flex;
    flex-direction: column;
    gap: 0.5rem;
  }

  .claim-form__attachment-card {
    border: 1px solid #e5e7eb;
    border-radius: 8px;
    background: #ffffff;
    padding: 0.75rem 1rem;
    box-shadow: 0 1px 2px rgba(0, 0, 0, 0.04);
    display: flex;
    align-items: flex-start;
    gap: 0.5rem;
  }

  .claim-form__attachment-card-body {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 0.4rem;
  }

  .claim-form__attachment-file-info {
    display: flex;
    align-items: baseline;
    gap: 0.4rem;
    min-width: 0;
  }

  .claim-form__attachment-card-name {
    font-size: 0.875rem;
    font-weight: 600;
    color: #001b3d;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    max-width: 70%;
  }

  .claim-form__attachment-card-size {
    font-size: 0.75rem;
    color: #6b7280;
    white-space: nowrap;
  }

  .claim-form__attachment-input--error {
    border-color: #ef4444 !important;
  }

  .claim-form__attachment-delete-btn {
    flex-shrink: 0;
    border: none;
    background: transparent;
    cursor: pointer;
    padding: 0.25rem;
    border-radius: 4px;
    line-height: 1;
    transition: color 0.15s ease, background-color 0.15s ease;
  }

  .claim-form__attachment-delete-btn:hover {
    color: #ef4444;
    background: #fef2f2;
  }

  /* ── Consent ── */
  .claim-form__consent-box {
    margin-top: 1rem;
    padding: 0.875rem;
    border: 1px solid #e5e7eb;
    border-radius: 6px;
    display: flex;
    align-items: flex-start;
    gap: 0.625rem;
    color: #374151;
    font-size: 0.8rem;
    background: #f9fafb;
    line-height: 1.5;
  }

  /* ── Actions ── */
  .claim-form__footer {
    flex-shrink: 0;
    padding: 0.875rem 1.5rem;
    border-top: 1px solid #e5e7eb;
    background: #f7f7f8;
  }

  .claim-form__actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 1rem;
  }

  .claim-form__actions-left {
    display: flex;
    align-items: center;
    gap: 0.5rem;
  }

  .claim-form__button {
    border-radius: 6px !important;
    min-width: 120px;
    font-weight: 600 !important;
    border: 1px solid transparent;
    padding: 0.65rem 1.5rem;
    cursor: pointer;
    font-size: 0.875rem;
    line-height: 1;
    transition: background-color 0.15s ease, border-color 0.15s ease, opacity 0.2s ease;
  }

  .claim-form__button--primary {
    background: #1a3d6b;
    color: #ffffff !important;
    border-color: #111827 !important;
  }

  .claim-form__button-content {
    display: inline-flex;
    align-items: center;
    gap: 0.45rem;
  }

  .claim-form__button-icon-circle {
    width: 1.1rem;
    height: 1.1rem;
    border-radius: 9999px;
    border: 1px solid rgba(255, 255, 255, 0.6);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    line-height: 0;
  }

  .claim-form__button--secondary {
    background: #ffffff !important;
    color: rgb(55, 65, 81) !important;
    border-color: #d1d5db !important;
  }

  .claim-form__button:disabled {
    opacity: 0.5 !important;
    cursor: not-allowed;
  }

  .claim-form__processing-content {
    display: inline-flex;
    align-items: center;
    gap: 0.45rem;
    color: #ffffff;
  }

  /* ── Feedback ── */
  .claim-form__feedback {
    margin-top: 0.75rem;
    font-size: 0.875rem;
    border-radius: 6px;
    padding: 0.5rem 0.75rem;
  }

  .claim-form__feedback--error {
    color: #b91c1c;
    background: #fef2f2;
    border: 1px solid #fecaca;
  }

  .claim-form__feedback--success {
    color: #15803d;
    background: #f0fdf4;
    border: 1px solid #bbf7d0;
  }

  /* ── Turnstile ── */
  .claim-form__turnstile-gate {
    margin: 0 0 1rem;
    text-align: center;
  }

  .claim-form__turnstile-gate-text {
    margin: 0 0 0.75rem;
    color: #374151;
    font-size: 0.95rem;
    line-height: 1.45;
  }

  .claim-form__turnstile-booting {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
    color: #6b7280;
    font-size: 0.85rem;
    margin-bottom: 0.75rem;
  }

  .claim-form__turnstile-host {
    display: flex;
    justify-content: center;
    margin: 0.5rem 0 1.25rem;
    min-height: 65px;
  }

  .claim-form__turnstile-host--hidden {
    position: fixed;
    left: 0;
    top: 0;
    width: 320px;
    height: 70px;
    margin: 0;
    opacity: 0.02;
    pointer-events: none;
    z-index: 0;
    overflow: hidden;
  }

  /* ── Review screen ── */
  .review-grid {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 1rem 1.5rem;
  }

  .review-field {
    display: flex;
    flex-direction: column;
    gap: 0.3rem;
  }

  .review-field--full {
    grid-column: 1 / -1;
  }

  .review-field__label {
    font-size: 0.75rem;
    font-weight: 500;
    color: #6b7280;
  }

  .review-field__value {
    font-size: 0.875rem;
    font-weight: 500;
    color: #111827;
    word-break: break-word;
  }

  .review-field__file-list {
    margin: 0.25rem 0 0;
    padding: 0 0 0 1rem;
    font-size: 0.875rem;
    color: #111827;
    list-style: disc;
    line-height: 1.6;
  }

  /* ── Discard modal ── */
  .claim-form__discard-modal {
    padding: 1rem;
    font-family: var(--pega-font-family, 'Open Sans', Arial, sans-serif);
  }

  .claim-form__discard-modal-text {
    margin: 0 0 1rem;
    color: #374151;
    font-size: 0.95rem;
  }

  .claim-form__discard-modal-actions {
    display: flex;
    justify-content: flex-end;
    gap: 0.75rem;
  }

  /* ── Confirmation screen ── */
  .claim-confirmation-shell {
  background: #eaf3fc;
  min-height: 100%;
  padding: 1rem 1.5rem;
}


    .claim-confirmation {
  max-width: 900px;
  margin: 0 auto;
  padding: 0;
}
  }

  .claim-confirmation__title {
    margin: 0;
    color: #111827;
    font-size: 1.75rem;
    line-height: 1.25;
    font-weight: 700;
  }

  .claim-confirmation__lead {
    margin: 1.25rem 0 0;
    color: #4b5563;
    font-size: 0.95rem;
    line-height: 1.55;
  }

  .claim-confirmation__case-id {
    margin: 0.875rem 0 0;
    color: #15803d;
    font-size: 1.4rem;
    line-height: 1.1;
    font-weight: 700;
  }

  .claim-confirmation__section-title {
  margin-top: 28px;
  margin-bottom: 10px;
    margin: 1.75rem 0 0;
    color: #111827;
    font-size: 1.25rem;
    line-height: 1.3;
    font-weight: 700;
  }

  .claim-confirmation__body {
    margin: 0.875rem 0 0;
    color: #4b5563;
    font-size: 0.95rem;
    line-height: 1.55;
  }

  .claim-confirmation__emphasis {
    margin: 0.5rem 0 0;
    color: #111827;
    font-size: 0.95rem;
    line-height: 1.5;
    font-weight: 600;
  }

  .claim-confirmation__download-error {
    margin: 0.875rem 0 0;
    color: #ef4444;
    font-size: 0.875rem;
    line-height: 1.4;
  }

 .claim-confirmation__actions {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 16px;
  margin-top: 1rem;
  flex-wrap: wrap;
}
  .claim-confirmation__actions button {
  flex: 1;          /* ✅ equal width */
  max-width: 280px; /* ✅ prevents stretching too wide */
}


/* ✅ Card styling */
.claim-form__group--location {
  background: #f4f5f7;
  border: 1px solid #dcdcdc;
  border-radius: 12px;
  padding: 20px;
}

/* ✅ Title */
.claim-form__card-title {
  font-size: .95rem;
  font-weight: 600;
  margin-bottom: 16px;
}

/* ✅ Radio group */
.claim-form__radio-group {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

/* ✅ Radio alignment */
.claim-form__radio {
  display: flex;
  align-items: center;
  gap: 10px;
  font-size: 16px;
}
.claim-form__group--white {
  background: #ffffff !important;
  border: 1px solid #d4dce5;
}
/* ✅ Same look as policy address card */
.claim-form__group--card {
  background: #ffffff !important;   /* ✅ remove grey */
  border: 1px solid #dcdcdc;        /* ✅ border line */
  border-radius: 12px;              /* ✅ rounded corners */
  padding: 20px;                   /* ✅ spacing inside */
  margin-top: 16px;
}
'.claim-form__required-star': {
  color: '#d32f2f',
  marginLeft: '2px'
}

/* ✅ Divider line */
.claim-form__divider {
  border-top: 1px solid #dcdcdc;
  margin: 20px 0;
}
  .claim-confirmation__actions .claim-confirmation__button {
    min-width: 200px;
    border-radius: 8px;
    font-size: 0.875rem;
    font-weight: 600;
    padding: 0.7rem 1.75rem;
    cursor: pointer;
    transition: background-color 0.15s ease, color 0.15s ease;
    line-height: 1;
  }

  .claim-confirmation__actions .claim-confirmation__button:disabled {
    opacity: 0.5;
    cursor: not-allowed;
  }

  /* ── Responsive ── */

  /* Mid-range: form panel is 450-650px wide — compact the step cards */
  @media (min-width: 901px) and (max-width: 1300px) {
    .claim-form__step-card {
      padding: 0.45rem 0.55rem;
      gap: 0.25rem;
    }

    .claim-form__step-card-label {
      font-size: 0.52rem;
    }

    .claim-form__step-card-name {
      font-size: 0.7rem;
    }

    .claim-form__step-card-icon {
      display: none;
    }
  }

  @media (max-width: 900px) {
    .claim-form-page {
      flex-direction: column;
      height: auto;
      overflow: visible;
    }

    .claim-form-page__image {
      flex: 0 0 240px;
      height: 240px;
    }

    .claim-form-page__panel {
      flex: 1 0 auto;
      height: auto;
    }

    .claim-form__step-nav {
      flex-wrap: wrap;
    }

    .claim-form__step-card {
      flex: 1 0 calc(50% - 0.5rem);
    }

    .claim-form__grid,
    .review-grid {
      grid-template-columns: 1fr;
    }
  }

  @media (max-width: 480px) {
    .claim-form__step-card {
      flex: 1 0 100%;
    }

    .claim-form__step-card-icon {
      display: none;
    }
  }

/* ✅ Header alignment */
.claim-form__header {
  display: flex;
  align-items: center;
 gap:6px
}

/* ✅ Info icon button */

 
/* Info icon button — uses Pega Icon component, no hand-drawn circle */
.claim-form__info-icon {
  display: inline-flex;
  align-items: center;
  justify-content: center;
  border: none;
  background: transparent;
  color: #84C2EA;
  padding: 0;
  cursor: pointer;
  line-height: 0;
  vertical-align: middle;
  font-style: normal;
  transition: color 0.15s ease;
}

.claim-form__info-icon i,
.claim-form__info-icon * {
  font-style: normal;
}

.claim-form__info-icon:hover {
  color: #1A3D6B;
}

/* ✅ Fix for hidden/blank icon text */


/* ✅ Info box container */
.claim-form__info-box {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;

  gap: 12px;
  margin: 0.75rem 0 1rem;
  padding: 0.75rem 1rem;

  border-radius: 10px;

  background: #eff9fd;
  border-left: 5px solid #84c2ea;
}

/* Left section */
.claim-form__info-left {
  display: flex;
  align-items: flex-start;
  gap: 10px;
  flex: 1;
}

/* Icon inside info box — Pega Icon component, blue to match box accent */
.claim-form__info-box-icon {
  display: flex;
  align-items: center;
  justify-content: center;
  color: #1A3D6B;
  flex-shrink: 0;
  line-height: 0;
  font-style: normal;
}

.claim-form__info-box-icon i,
.claim-form__info-box-icon * {
  font-style: normal;
}

/* ✅ Ensure inner icon always shows */


/* Info text */
.claim-form__info-content {
  font-size: 0.9rem;
  color: #001b3d;
  line-height: 1.5;
}

/* ✅ CLOSE BUTTON (FORCE BLUE) */
.claim-form__info-close {
  border: none;
  background: transparent;

  font-size: 1.2rem;
  font-weight: 600;

  color: black !important;   /* ✅ BLUE */

  cursor: pointer;
}
  
.claim-form__label {
  font-weight: 600;
  color: #111827;  /* slightly darker for better readability */
}
.claim-form__field span {
  font-weight: 600;
}
.claim-form__divider {
  border-top: 1px solid #dcdcdc;
  margin: 16px 0;   /* ✅ adds space ABOVE and BELOW */
}
  .claim-form__label {
  display: inline-flex;
  align-items: center;
  gap: 4px;   /* small space between text and star */
  flex-wrap: wrap; /* ✅ prevents wrapping */
}

.claim-form__required-star {
  flex-shrink: 0;   /* ✅ prevents star jumping */
}
.claim-form-page__image::after {
  content: '';
  position: absolute;
  inset: 0;
  background: linear-gradient(to bottom, transparent 0%, transparent 50%, #1A3D6B 100%);
  opacity: 0.9;
  z-index: 1;
}

.claim-form__image-overlay {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  padding: 0 40px 36px;
  color: #ffffff;
  z-index: 2;
}

.claim-form__image-title {
  font-size: 2.2rem;
  font-weight: 700;
  margin: 0 0 8px;
  line-height: 1.2;
}

.claim-form__image-subtext {
  font-size: 0.9rem;
  line-height: 1.5;
  margin: 0 0 18px;
  opacity: 0.9;
}

.claim-form__image-contact {
  display: flex;
  gap: 36px;
  flex-wrap: wrap;
  margin-bottom: 14px;
}

.claim-form__image-contact div strong {
  display: block;
  font-size: 0.8rem;
  font-weight: 700;
}

.claim-form__image-contact div p {
  margin: 2px 0 0;
  font-size: 0.85rem;
  opacity: 0.9;
}

.claim-form__image-hours {
  font-size: 0.85rem;
}

.claim-form__image-hours strong {
  display: block;
  font-weight: 700;
  font-size: 0.8rem;
}

.claim-form__image-hours p {
  margin: 2px 0 0;
  opacity: 0.9;
}
.claim-form__evidence-info {
  color: #d97706;   /* ✅ orange */
  font-size: 0.9rem;
  margin-bottom: 16px;
}
.claim-form__upload-icon {
  font-size: 36px;
  color: #9ca3af;
  margin-bottom: 4px;
}
.review-card {
  background: #f3f4f6;
  border-radius: 12px;
  padding: 18px;
  margin-bottom: 16px;
  border: 1px solid #e5e7eb;
}

/* HEADER ROW */
.review-card__header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding-bottom: 10px;
  cursor: pointer;
  user-select: none;
}

/* LEFT SIDE */
.review-card__title {
  display: flex;
  align-items: center;
  gap: 10px;
}

/* NUMBER CIRCLE */
.review-card__index {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  background: #111827;
  color: white;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* TITLE TEXT */
.review-card__heading {
  font-size: 1.1rem;
  font-weight: 600;
}

/* RIGHT SIDE ICONS */
.review-card__icons {
  display: flex;
  align-items: center;
  gap: 12px;
}

/* ICON BUTTON */
.review-card__icon-btn {
  background: transparent;
  border: none;
  cursor: pointer;
  color: #374151;
  display: flex;
  align-items: center;
  justify-content: center;
}

/* CONTENT */
.review-card__content {
 .review-card__content {
  margin-top: 14px;
  padding-top: 10px;
}
}
.review-card__icon-btn svg {
  width: 18px;
  height: 18px;
}
  .review-card__icon-btn {
  color: #111827;   /* darker */
}
.review-card__icon-btn:hover {
  color: #1a3d6b;
}
.review-declaration {
  margin-top: 20px;
}

.review-declaration__title {
  font-size: 1.3rem;
  font-weight: 700;
  margin-bottom: 14px;
  color: #111827;
}

.review-declaration__item {
  margin-bottom: 18px;
}

/* Checkbox row */
.review-declaration__checkbox {
  display: flex;
  align-items: center;
  gap: 10px;
  font-weight: 600;
  color: #111827;
}

/* Paragraph text */
.review-declaration__text {
  margin-top: 6px;
  margin-left: 26px;   /* aligns under checkbox text */
  font-size: 0.95rem;
  line-height: 1.6;
  color: #1f2937;
}
.claim-confirmation-shell {
  background: #eaf3fc;
  min-height: 100%;
  padding: 1rem 1.5rem;
}
.claim-confirmation {
  color: #1a3d6b;
}

  .claim-confirmation__title {
  font-size: 2rem;
  font-weight: 700;
  color: #1a3d6b;
}
.claim-confirmation__subtitle {
  margin-top: 6px;
  color: #6b7280;
}
  .claim-confirmation__reference-card {
  
 background: #9fc3dd;     /* ✅ darker blue */
  padding: 24px;
  border-left: 6px solid #1a3d6b;
  margin: 24px 0

}
  .claim-confirmation__case-id {
  font-size: 2.2rem;
  font-weight: 700;
  color: #1a3d6b;
}
.claim-confirmation__list {
  margin-top: 10px;
  padding-left: 20px;
  line-height: 1.6;
}
  .claim-confirmation__section-title {
  margin-top: 24px;
  font-size: 1.3rem;
  font-weight: 700;
  color: #1a3d6b;
}
  .claim-confirmation__button--primary {
    background: #001b3d;
    color: #ffffff;
    border: 2px solid #001b3d;
  }

  .claim-confirmation__button--primary:hover:not(:disabled) {
    background: #1A3D6B;
    border-color: #1A3D6B;
  }

  .claim-confirmation__button--outline {
    background: #ffffff;
    color: #001b3d;
    border: 2px solid #001b3d;
  }

  .claim-confirmation__button--outline:hover:not(:disabled) {
    background: #f0f4f8;
  }
.claim-confirmation__body {
  margin-top: 12px;
  line-height: 1.6;
}

.claim-confirmation__rich-text {
  line-height: 1.6;
  color: #111827;
  font-size: 0.9rem;
}

.claim-confirmation__rich-text h1,
.claim-confirmation__rich-text h2,
.claim-confirmation__rich-text h3 {
  color: #001b3d;
  margin: 0.5rem 0 0.25rem;
  font-weight: 700;
}

.claim-confirmation__rich-text p {
  margin: 0.25rem 0;
}

.claim-confirmation__rich-text ul,
.claim-confirmation__rich-text ol {
  padding-left: 1.25rem;
  margin: 0.25rem 0;
}

.claim-confirmation__rich-text a {
  color: #1A3D6B;
}

.claim-confirmation__list {
  margin-top: 12px;
  margin-bottom: 20px;
  padding-left: 20px;
  line-height: 1.6;
}
  .claim-confirmation p {
  margin: 8px 0;   /* ✅ equal spacing between all lines */
}
.claim-confirmation p {
  margin: 10px 0;
}
`;
