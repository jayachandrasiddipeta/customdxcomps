export interface ListOption {
  key: string;
  label: string;
}

export interface CountryOption extends ListOption {
  dialingCode: string;
}

export const LIST_CATEGORIES = {
  PRODUCT: 'Product',
  RELATIONSHIP: 'Relationship',
  LOSS_TYPE: 'LossType',
  LOSS_LOCATION: 'LossLocation',
  GENERIC_YES_NO: 'GenericYesNo',
  ITEM_TYPE: 'ItemType',
  EVIDENCE_TYPE: 'EvidenceType'
} as const;

export async function fetchListValues(category: string, dataPageName: string): Promise<ListOption[]> {
  try {
    const context = '';
    const parameters = { Category: category };
    const paging = {
      pageNumber: 1,
      pageSize: 500,
    };
    const listValuesQuery = {
      select: [
        { field: "pyKeyString" },
        { field: "pyActualValue" },
        { field: "pyCategory" },
      ],
      useExtendedTimeout: false,
    };
    const response = await (
      window as any
    ).PCore.getDataPageUtils().getDataAsync(
      dataPageName,
      context,
      parameters,
      paging,
      listValuesQuery,
    );
    return (response?.data ?? []).map((item: Record<string, string>) => ({
      key: item.pyKeyString ?? '',
      label: item.pyActualValue ?? ''
    }));
  } catch {
    return [];
  }
}

export async function fetchAllListValues(dataPageName: string): Promise<Record<string, ListOption[]>> {
  const entries = await Promise.all(
    Object.values(LIST_CATEGORIES).map(async cat => ({
      cat,
      opts: await fetchListValues(cat, dataPageName)
    }))
  );
  return Object.fromEntries(entries.map(({ cat, opts }) => [cat, opts]));
}

export async function fetchCountryList(): Promise<CountryOption[]> {
  try {
    const context = '';
    const dataPageName = 'D_CountryList';
    const parameters = {};
    const paging = {
      pageNumber: 1,
      pageSize: 500,
    };
    const countryListQuery = {
      select: [
        { field: "Name" },
        { field: "ISOCode" },
        { field: "DialingCode" }
      ],
      useExtendedTimeout: false,
    };
    const response = await (
      window as any
    ).PCore.getDataPageUtils().getDataAsync(
      dataPageName,
      context,
      parameters,
      paging,
      countryListQuery,
    );
    return (response?.data ?? []).map((item: Record<string, string>) => ({
      key: item.ISOCode ?? '',
      label: item.Name ?? '',
      dialingCode: item.DialingCode ?? ''
    }));
  } catch {
    return [];
  }
}
