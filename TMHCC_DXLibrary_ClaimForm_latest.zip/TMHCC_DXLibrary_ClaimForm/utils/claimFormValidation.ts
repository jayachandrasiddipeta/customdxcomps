import type { ClaimFormData, ClaimFormErrors } from '../types';
import type { LocalizationMap } from './useLocalization';

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_PATTERN = /^\d{10}$/;

type FieldValidator = (value: string, formData: ClaimFormData) => string;

const buildValidators = (l: LocalizationMap): Partial<Record<keyof ClaimFormData, FieldValidator>> => {
  const req = (key: keyof LocalizationMap) => (v: string) => v ? '' : l[key];

  const notFuture = (reqKey: keyof LocalizationMap, futureKey: keyof LocalizationMap) => (v: string) => {
    if (!v) return l[reqKey];
    const today = new Date().toISOString().slice(0, 10);
    return v > today ? l[futureKey] : '';
  };

  return {
    firstName:          req('ErrFirstNameRequired'),
    lastName:           req('ErrLastNameRequired'),
    policyNumber: v => {
      if (!v) return l['ErrPolicyNumberRequired'];
      return new RegExp(l['PolicyNumberPattern']).test(v) ? '' : l['PolicyNumberFormatError'];
    },
    serviceNumber: v => {
      if (!v) return '';
      return new RegExp(l['ServiceNumberPattern']).test(v) ? '' : l['ServiceNumberFormatError'];
    },
    relationship:       req('ErrRelationshipRequired'),
    dateOfLoss:         notFuture('ErrDateOfLossRequired', 'ErrDateOfLossFuture'),
    lossType:           req('ErrLossTypeRequired'),
    causeOfLoss:        req('ErrCauseOfLossRequired'),
    lossCountry:        req('ErrCountryRequired'),
    lossAddressLine1:   req('ErrAddressLine1Required'),
    lossCity:           req('ErrCityRequired'),
    lossPostalCode:     req('ErrPostalCodeRequired'),
    description:        req('ErrDescriptionRequired'),
    itemType:           req('ErrItemTypeRequired'),
    purchasePrice:      req('ErrPurchasePriceRequired'),
    policyCountry:      req('ErrCountryRequired'),
    policyAddressLine1: req('ErrAddressLine1Required'),
    policyCity:         req('ErrCityRequired'),
    policyPostalCode:   req('ErrPostalCodeRequired'),
    claimedAmount:      req('ErrClaimedAmountRequired'),
    itemDescription:    req('ErrItemDescriptionRequired'),
    datePurchased:      notFuture('ErrDatePurchasedRequired', 'ErrDatePurchasedFuture'),

    email: v => {
      if (!v) return l['ErrEmailRequired'];
      return EMAIL_PATTERN.test(v) ? '' : l['ErrEmailInvalid'];
    },
    phoneNumber: v => {
      if (!v) return '';
      return PHONE_PATTERN.test(v) ? '' : l['ErrPhoneFormat'];
    },
    hasUserConfirmed: (_v, formData) =>
      formData.hasUserConfirmed ? '' : l['ErrConsentRequired'],
  };
};

const STEP_FIELDS: Record<number, (keyof ClaimFormData)[]> = {
  1: ['firstName', 'lastName', 'email', 'phoneNumber', 'policyNumber', 'serviceNumber'],
  2: ['dateOfLoss', 'lossType', 'description'],
  3: ['itemType', 'purchasePrice', 'claimedAmount', 'itemDescription', 'datePurchased'],
  4: []
};

export const getClaimFieldValidationError = (
  field: keyof ClaimFormData,
  formData: ClaimFormData,
  l: LocalizationMap
): string => {
  const validators = buildValidators(l);
  const validator = validators[field];
  if (!validator) return '';
  const value = typeof formData[field] === 'string' ? (formData[field] as string).trim() : '';
  return validator(value, formData);
};

export const getStepValidationErrors = (
  step: number,
  formData: ClaimFormData,
  l: LocalizationMap
): ClaimFormErrors => {
  const errors: ClaimFormErrors = {};
  const fields = STEP_FIELDS[step] ?? [];

  fields.forEach(field => {
    const fieldError = getClaimFieldValidationError(field, formData, l);
    if (fieldError) errors[field] = fieldError;
  });

  if (step === 2) {
    if (!formData.lossType) {
      errors.lossType = l['ErrLossTypeRequired'];
    }

    if (formData.lossType === 'OTH' && !formData.otherLossType) {
      errors.otherLossType = l['ErrFieldRequired'];
    }

    if (formData.lossType === 'TH') {
      if (!formData.theftReported) {
        errors.theftReported = l['ErrFieldRequired'];
      }
      if (formData.theftReported === 'Yes' && !formData.crimeReferenceNumber) {
        errors.crimeReferenceNumber = l['ErrFieldRequired'];
      }
    }

    if (!formData.lossLocationType) {
      errors.lossLocationType = l['ErrFieldRequired'];
    }

    if (formData.lossLocationType === 'DL') {
      if (!formData.lossCountry)      errors.lossCountry      = l['ErrFieldRequired'];
      if (!formData.lossAddressLine1) errors.lossAddressLine1 = l['ErrFieldRequired'];
      if (!formData.lossCity)         errors.lossCity         = l['ErrFieldRequired'];
      if (!formData.lossPostalCode)   errors.lossPostalCode   = l['ErrFieldRequired'];
    }
  }

  return errors;
};

export const getClaimFormValidationErrors = (
  formData: ClaimFormData,
  l: LocalizationMap
): ClaimFormErrors => {
  const errors: ClaimFormErrors = {};
  [1, 2, 3, 4].forEach(step => {
    Object.assign(errors, getStepValidationErrors(step, formData, l));
  });
  return errors;
};
