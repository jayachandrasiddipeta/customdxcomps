interface LovItem {
  pyKeyString: string;
  pyActualValue: string;
  pyCategory: string;
}

export const LOV_DATA: LovItem[] = [
  { pyKeyString: 'CL',   pyActualValue: 'Clothing',                                          pyCategory: 'ItemType'        },
  { pyKeyString: 'DA',   pyActualValue: 'Damage',                                            pyCategory: 'LossType'        },
  { pyKeyString: 'DL',   pyActualValue: 'Different location',                                pyCategory: 'LossLocation'    },
  { pyKeyString: 'DP',   pyActualValue: 'Dependent',                                         pyCategory: 'Relationship'    },
  { pyKeyString: 'DSFA', pyActualValue: 'Damage to my SFA (service family accommodation)',   pyCategory: 'LossType'        },
  { pyKeyString: 'DSLA', pyActualValue: 'Damage to my SLA (single living accommodation)',    pyCategory: 'LossType'        },
  { pyKeyString: 'EL',   pyActualValue: 'Electronics',                                       pyCategory: 'ItemType'        },
  { pyKeyString: 'EOO',  pyActualValue: 'Evidence of Ownership',                             pyCategory: 'EvidenceType'    },
  { pyKeyString: 'FI',   pyActualValue: 'Fire',                                              pyCategory: 'LossType'        },
  { pyKeyString: 'FU',   pyActualValue: 'Furniture',                                         pyCategory: 'ItemType'        },
  { pyKeyString: 'IOD',  pyActualValue: 'Image of Damaged Item',                             pyCategory: 'EvidenceType'    },
  { pyKeyString: 'LO',   pyActualValue: 'Loss',                                              pyCategory: 'LossType'        },
  { pyKeyString: 'MKCPP',pyActualValue: 'Military Kit Contents and Personal Possessions',    pyCategory: 'Product'         },
  { pyKeyString: 'No',   pyActualValue: 'No',                                                pyCategory: 'GenericYesNo'    },
  { pyKeyString: 'OD',   pyActualValue: 'Other',                                             pyCategory: 'EvidenceType'    },
  { pyKeyString: 'OSD',  pyActualValue: 'Other Supporting Document',                         pyCategory: 'EvidenceType'    },
  { pyKeyString: 'OTH',  pyActualValue: 'Other',                                             pyCategory: 'ItemType'        },
  { pyKeyString: 'OTH',  pyActualValue: 'Other',                                             pyCategory: 'LossType'        },
  { pyKeyString: 'PH',   pyActualValue: 'Policyholder',                                      pyCategory: 'Relationship'    },
  { pyKeyString: 'PHA',  pyActualValue: 'Same as policyholder address',                      pyCategory: 'LossLocation'    },
  { pyKeyString: 'POP',  pyActualValue: 'Proof of Purchase',                                 pyCategory: 'EvidenceType'    },
  { pyKeyString: 'SE',   pyActualValue: 'Sports Equipment',                                  pyCategory: 'ItemType'        },
  { pyKeyString: 'SP',   pyActualValue: 'Spouse',                                            pyCategory: 'Relationship'    },
  { pyKeyString: 'TH',   pyActualValue: 'Theft',                                             pyCategory: 'LossType'        },
  { pyKeyString: 'WD',   pyActualValue: 'Water Damage',                                      pyCategory: 'LossType'        },
  { pyKeyString: 'Yes',  pyActualValue: 'Yes',                                               pyCategory: 'GenericYesNo'    }
];

export function mockGetDataAsync(
  dataPage: string,
  _context: unknown,
  parameters: Record<string, string>
): Promise<{ data: LovItem[] }> {
  if (dataPage === 'D_ListOfValues') {
    const category = parameters?.Category ?? '';
    return Promise.resolve({
      data: LOV_DATA.filter(item => item.pyCategory === category)
    });
  }
  return Promise.resolve({ data: [] });
}
