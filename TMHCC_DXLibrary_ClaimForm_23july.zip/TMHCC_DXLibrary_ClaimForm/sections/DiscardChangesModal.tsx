import { Modal, useModalContext } from '@pega/cosmos-react-core';
import { LocalizationMap } from '../utils/useLocalization';

interface DiscardChangesModalProps {
  onDiscard: () => void;
  l: LocalizationMap;
}


const isSafeUrl = (url: string): boolean => {
  try { return new URL(url).protocol === 'https:'; } catch { return false; }
};

function DiscardChangesModal({ onDiscard,l }: DiscardChangesModalProps) {
  const { dismiss } = useModalContext();

  const handleDiscard = () => {
    dismiss();
    onDiscard();
    const url = String(l['ReturnHomePageLink']);
    if (isSafeUrl(url)) {
      window.location.href = url;
    }
  };

  return (
    <Modal
      heading={l['DiscardModalHeading']}
      onDismiss={() => dismiss()}
      center
      className='claim-form__discard-modal-box'
    >
      <div className='claim-form__discard-modal'>
        <p className='claim-form__discard-modal-text'>
          {l['DiscardModalBody']}
        </p>
        <div className='claim-form__discard-modal-actions'>
          <button
            type='button'
            className='claim-form__button claim-form__button--secondary'
            onClick={() => dismiss()}
          >
            {l['DiscardModalDismiss']}
          </button>
          <button
            type='button'
            className='claim-form__button claim-form__button--cancel'
            onClick={handleDiscard}
          >
            {l['DiscardModalConfirm']}
          </button>
        </div>
      </div>
    </Modal>
  );
}

export default DiscardChangesModal;
