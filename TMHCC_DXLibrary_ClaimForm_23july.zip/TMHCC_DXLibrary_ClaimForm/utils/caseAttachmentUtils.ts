import { extractPegaErrorMessage } from './pegaErrorUtils';

interface AttachmentItem {
  id: string;
  docType: string;
  otherDocType?: string;
}

interface AttachToCaseResponse {
  success: boolean;
  message?: string;
}

export const attachUploadedFilesToCase = async (caseId: string, attachments: AttachmentItem[]): Promise<AttachToCaseResponse> => {
  if (!caseId || attachments.length === 0) {
    return { success: true };
  }

  try {
    const payload = {
      attachments: attachments.map(({ id, docType, otherDocType }) => ({
        type: 'File',
        category: docType,
        ID: id,
        name: docType === 'Other' ? (otherDocType?.trim()) : '',
      }))
    };

    await (window as any).PCore.getRestClient().invokeCustomRestApi(`/api/application/v2/cases/${caseId}/attachments`, {
      method: 'POST',
      body: payload
    });

    return { success: true };
  } catch (error: unknown) {
    return {
      success: false,
      message: extractPegaErrorMessage(error, 'Failed to attach uploaded files to case')
    };
  }
};
