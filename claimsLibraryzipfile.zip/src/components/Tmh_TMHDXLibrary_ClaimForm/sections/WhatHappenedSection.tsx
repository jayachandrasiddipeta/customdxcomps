// import type { ClaimFormData, ClaimFormErrors } from '../types';

// const RELATIONSHIP_OPTIONS = ['', 'Policyholder', 'Spouse / Partner', 'Dependent', 'Other'];
// const COUNTRY_OPTIONS = ['', 'United Kingdom', 'United States', 'Australia', 'Canada', 'Germany', 'France', 'Other'];
// const LOSS_TYPE_OPTIONS = [
//   '',
//   'Theft',
//   'Loss',
//   'Damage',
//   'Fire',
//   'Water Damage',
//   'Other'
// ];

// interface WhatHappenedSectionProps {
//   formData: ClaimFormData;
//   errors: ClaimFormErrors;
//   onFieldChange: (field: keyof ClaimFormData, value: string) => void;
//   onFieldBlur: (field: keyof ClaimFormData) => void;
// }

// function WhatHappenedSection({ formData, errors, onFieldChange, onFieldBlur }: WhatHappenedSectionProps) {
//   return (
//     <section className='claim-form__section'>
//       <h3 className='claim-form__section-title'>
//         <span className='claim-form__section-index'>2</span>
//         What happened
//       </h3>
//       <div className='claim-form__grid'>
   

//         <label className='claim-form__field'>
//           <span>Date of Loss <span className='claim-form__required-star'>*</span></span>
//           <input
//             type='date'
//             required
//             value={formData.dateOfLoss}
//             onChange={e => onFieldChange('dateOfLoss', e.target.value)}
//             onBlur={() => onFieldBlur('dateOfLoss')}
//           />
//           {errors.dateOfLoss && <small className='claim-form__error'>{errors.dateOfLoss}</small>}
//         </label>

//         <label className='claim-form__field'>
//           <span>Loss Type <span className='claim-form__required-star'>*</span></span>
//           <input
//             type='text'
//             placeholder='What happened? (e.g. theft, accidental damage, loss)'
//             required
//             value={formData.lossType}
//             onChange={e => onFieldChange('lossType', e.target.value)}
//             onBlur={() => onFieldBlur('lossType')}
//           />
//           {errors.lossType && <small className='claim-form__error'>{errors.lossType}</small>}
//         </label>

      
//           {/* Location Selection */}
// <div className='claim-form__field claim-form__field--full'>
//   <span>
//     Where did this happen? 
//     <span className='claim-form__required-star'>*</span>
//   </span>

//   <label>
//     <input
//       type="radio"
//       name="lossLocationType"
//       value="same"
//       checked={formData.lossLocationType === 'same'}
//       onChange={() => onFieldChange('lossLocationType', 'same')}
//       onBlur={() => onFieldBlur('lossLocationType')}
//     />
//     Same as policyholder address
//   </label>

//   <label>
//     <input
//       type="radio"
//       name="lossLocationType"
//       value="different"
//       checked={formData.lossLocationType === 'different'}
//       onChange={() => onFieldChange('lossLocationType', 'different')}
//       onBlur={() => onFieldBlur('lossLocationType')}
//     />
//     Different location
//   </label>

//   {errors.lossLocationType && (
//     <small className='claim-form__error'>
//       {errors.lossLocationType}
//     </small>
//   )}
// </div>
//         <div className='claim-form__subheading claim-form__field--full'>Loss address</div>

//         <label className='claim-form__field claim-form__field--full'>
//           <span>Country <span className='claim-form__required-star'>*</span></span>
//           <select
//             required
//             value={formData.lossCountry}
//             onChange={e => onFieldChange('lossCountry', e.target.value)}
//             onBlur={() => onFieldBlur('lossCountry')}
//           >
//             {COUNTRY_OPTIONS.map(opt => (
//               <option key={opt} value={opt}>{opt || 'Select...'}</option>
//             ))}
//           </select>
//           {errors.lossCountry && <small className='claim-form__error'>{errors.lossCountry}</small>}
//         </label>

//         <label className='claim-form__field'>
//           <span>Address line 1 <span className='claim-form__required-star'>*</span></span>
//           <input
//             type='text'
//             required
//             value={formData.lossAddressLine1}
//             onChange={e => onFieldChange('lossAddressLine1', e.target.value)}
//             onBlur={() => onFieldBlur('lossAddressLine1')}
//           />
//           {errors.lossAddressLine1 && <small className='claim-form__error'>{errors.lossAddressLine1}</small>}
//         </label>

//         <label className='claim-form__field'>
//           <span>Address line 2</span>
//           <input
//             type='text'
//             value={formData.lossAddressLine2}
//             onChange={e => onFieldChange('lossAddressLine2', e.target.value)}
//           />
//         </label>

//         <label className='claim-form__field'>
//           <span>City / Town <span className='claim-form__required-star'>*</span></span>
//           <input
//             type='text'
//             required
//             value={formData.lossCity}
//             onChange={e => onFieldChange('lossCity', e.target.value)}
//             onBlur={() => onFieldBlur('lossCity')}
//           />
//           {errors.lossCity && <small className='claim-form__error'>{errors.lossCity}</small>}
//         </label>

//         <label className='claim-form__field'>
//           <span>Postal Code <span className='claim-form__required-star'>*</span></span>
//           <input
//             type='text'
//             required
//             value={formData.lossPostalCode}
//             onChange={e => onFieldChange('lossPostalCode', e.target.value)}
//             onBlur={() => onFieldBlur('lossPostalCode')}
//           />
//           {errors.lossPostalCode && <small className='claim-form__error'>{errors.lossPostalCode}</small>}
//         </label>

//         <label className='claim-form__field claim-form__field--full'>
//           <span>Describe what happened <span className='claim-form__required-star'>*</span></span>
//           <textarea
//             rows={4}
//             placeholder='Include when, where and how it happened, and anything else that may help us understand your claim.'
//             value={formData.description}
//             onChange={e => onFieldChange('description', e.target.value)}
//             onBlur={() => onFieldBlur('description')}
//           />
//           {errors.description && <small className='claim-form__error'>{errors.description}</small>}
//           <small className='claim-form__hint'>Include: when, where, how it happened, and any relevant circumstances</small>
//         </label>
//       </div>
//     </section>
//   );
// }

// export default WhatHappenedSection;

import { useState } from 'react';
import type { ClaimFormData, ClaimFormErrors } from '../types';
import InfoBox from './InfoTooltip';
const COUNTRY_OPTIONS = ['', 'United Kingdom', 'United States', 'Australia', 'Canada', 'Germany', 'France', 'Other'];

const LOSS_TYPE_OPTIONS = [
  '',
  'Theft',
  'Loss',
  'Damage',
  'Fire',
  'Water Damage',
  'Other'
];

interface WhatHappenedSectionProps {
  formData: ClaimFormData;
  errors: ClaimFormErrors;
  onFieldChange: (field: keyof ClaimFormData, value: string) => void;
  onFieldBlur: (field: keyof ClaimFormData) => void;
}

const WHAT_HAPPENED_INFO =
  "Provide a clear description of the incident. Include when and where it happened, what caused the loss or damage, and any important details that could help us understand your claim. The more information you provide, the quicker we can process it."

function WhatHappenedSection({
  formData,
  errors,
  onFieldChange,
  onFieldBlur
}: WhatHappenedSectionProps) {
  const [showInfo, setShowInfo] = useState(false);
  return (
    <section className="claim-form__section">
      <h3 className="claim-form__section-title">
        {/* <span className="claim-form__section-index">2</span> */}
        What Happened
            <button
          type="button"
          className="claim-form__info-icon"
          onClick={() => setShowInfo(prev => !prev)}
          aria-label="Show info"
        >
          i
        </button>
      </h3>
      {/* ✅ INFO BOX */}
     {showInfo && (
  <div className="claim-form__info-box">

    {/* ✅ LEFT SIDE */}
    <div className="claim-form__info-left">

      {/* ✅ ICON */}
      <div className="claim-form__info-box-icon">
        i
      </div>

      {/* ✅ TEXT */}
      <div className="claim-form__info-content">
        Please provide the policyholder's contact details and policy information.
        If you are claiming on behalf of someone else, select your relationship
        to the policyholder. All required fields are marked with an asterisk.
      </div>

    </div>

    {/* ✅ CLOSE BUTTON (RIGHT) */}
    <button
      type="button"
      className="claim-form__info-close"
      onClick={() => setShowInfo(false)}
    >
      ×
    </button>

  </div>
)}
      <div className="claim-form__grid">

        {/* ✅ CARD 1 */}
        <div className="claim-form__group claim-form__field--full">
          <div className="claim-form__grid">

            {/* Date */}
            <label className="claim-form__field">
              <span>
  Date of Loss <span className="claim-form__required-star">*</span>
</span>
              <input
                type="date"
                value={formData.dateOfLoss}
                onChange={(e) => onFieldChange('dateOfLoss', e.target.value)}
                onBlur={() => onFieldBlur('dateOfLoss')}
              />
              {errors.dateOfLoss && (
                <small className="claim-form__error">{errors.dateOfLoss}</small>
              )}
            </label>

            {/* Loss Type */}
            <label className="claim-form__field">
              <span>Loss Type <span className="claim-form__required-star">*</span></span>
              <select
                value={formData.lossType}
                onChange={(e) => {
                  onFieldChange('lossType', e.target.value);
                  onFieldBlur('lossType');
                }}
              >
                {LOSS_TYPE_OPTIONS.map(opt => (
                  <option key={opt} value={opt}>{opt || 'Select...'}</option>
                ))}
              </select>
              {errors.lossType && (
                <small className="claim-form__error">{errors.lossType}</small>
              )}
            </label>

            {/* ✅ Other */}
            {formData.lossType === 'Other' && (
              <label className="claim-form__field claim-form__field--full">
                <span>Specify Loss Type <span className="claim-form__required-star">*</span></span>
                <input
                  value={formData.otherLossType || ''}
                  onChange={(e) => onFieldChange('otherLossType', e.target.value)}
                  onBlur={() => onFieldBlur('otherLossType' as keyof ClaimFormData)}
                />
                {errors.otherLossType && (
                  <small className="claim-form__error">{errors.otherLossType}</small>
                )}
              </label>
            )}

            {/* ✅ Theft */}
            {formData.lossType === 'Theft' && (
              <>
                <div className="claim-form__subheading claim-form__field--full">
                  Theft Details
                </div>

                <label className="claim-form__field">
                 
<span>
  Was this theft reported to the police?&nbsp;
  <span className="claim-form__required-star">*</span>
</span>

                  <select
                    value={formData.theftReported || ''}
                    onChange={(e) => {
                      const value = e.target.value;
                      onFieldChange('theftReported', value);

                      if (value === 'No') {
                        onFieldChange('crimeReferenceNumber', '');
                      }

                      onFieldBlur('theftReported' as keyof ClaimFormData);
                    }}
                  >
                    <option value="">Select...</option>
                    <option value="Yes">Yes</option>
                    <option value="No">No</option>
                  </select>
                  {errors.theftReported && (
                    <small className="claim-form__error">{errors.theftReported}</small>
                  )}
                </label>

                {formData.theftReported === 'Yes' && (
                  <label className="claim-form__field">
                    <span>Crime Reference Number <span className="claim-form__required-star">*</span></span>
                    <input
                      value={formData.crimeReferenceNumber || ''}
                      onChange={(e) => onFieldChange('crimeReferenceNumber', e.target.value)}
                      onBlur={() => onFieldBlur('crimeReferenceNumber' as keyof ClaimFormData)}
                    />
                    {errors.crimeReferenceNumber && (
                      <small className="claim-form__error">{errors.crimeReferenceNumber}</small>
                    )}
                  </label>
                )}
              </>
            )}

            {/* Description */}
            <label className="claim-form__field claim-form__field--full">
              <span>Description <span className="claim-form__required-star">*</span></span>
              <textarea
                rows={4}
                value={formData.description}
                onChange={(e) => onFieldChange('description', e.target.value)}
                onBlur={() => onFieldBlur('description')}
              />
              {errors.description && (
                <small className="claim-form__error">{errors.description}</small>
              )}
            </label>

          </div>
        </div>

        {/* ✅ CARD 2 */}
        <div className="claim-form__group claim-form__group--card claim-form__field--full">

          <h4 className="claim-form__card-title">
            Where did this happen?
          </h4>

          {/* ✅ Radios */}
          <div className="claim-form__radio-group">

            <label className="claim-form__radio">
              <input
                type="radio"
                name="lossLocationType"
                value="same"
                checked={formData.lossLocationType === 'same'}
                onChange={() => {
                  onFieldChange('lossLocationType', 'same');
                  onFieldBlur('lossLocationType');   // ✅ FIX
                }}
              />
              <span>Same as policyholder address</span>
            </label>

            <label className="claim-form__radio">
              <input
                type="radio"
                name="lossLocationType"
                value="different"
                checked={formData.lossLocationType === 'different'}
                onChange={() => {
                  onFieldChange('lossLocationType', 'different');
                  onFieldBlur('lossLocationType');   // ✅ FIX
                }}
              />
              <span>Different location</span>
            </label>

          </div>

          {errors.lossLocationType && (
            <small className="claim-form__error">{errors.lossLocationType}</small>
          )}

          {/* ✅ Address */}
          {formData.lossLocationType === 'different' && (
            <>
         
            <div className="claim-form__divider claim-form__field--full" />
            <div className="claim-form__grid">

              <label className="claim-form__field claim-form__field--full">
                <span>Country <span className="claim-form__required-star">*</span></span>
                <select
                  value={formData.lossCountry}
                  onChange={(e) => onFieldChange('lossCountry', e.target.value)}
                  onBlur={() => onFieldBlur('lossCountry')}
                >
                  {COUNTRY_OPTIONS.map(opt => (
                    <option key={opt} value={opt}>{opt || 'Select...'}</option>
                  ))}
                </select>
                {errors.lossCountry && (
                  <small className="claim-form__error">{errors.lossCountry}</small>
                )}
              </label>

              <label className="claim-form__field claim-form__field--full">
                <span>Address Line 1 <span className="claim-form__required-star">*</span></span>
                <input
                  value={formData.lossAddressLine1}
                  onChange={(e) => onFieldChange('lossAddressLine1', e.target.value)}
                  onBlur={() => onFieldBlur('lossAddressLine1')}
                />
                {errors.lossAddressLine1 && (
                  <small className="claim-form__error">{errors.lossAddressLine1}</small>
                )}
              </label>
         {/* Address line 2 */}
<label className="claim-form__field claim-form__field--full">
  <span>Address Line 2</span>
  <input
    value={formData.lossAddressLine2}
    onChange={(e) => onFieldChange('lossAddressLine2', e.target.value)}
  />
</label>
              <label className="claim-form__field">
                <span>City / Town <span className="claim-form__required-star">*</span></span>
                <input
                  value={formData.lossCity}
                  onChange={(e) => onFieldChange('lossCity', e.target.value)}
                  onBlur={() => onFieldBlur('lossCity')}
                />
                {errors.lossCity && (
                  <small className="claim-form__error">{errors.lossCity}</small>
                )}
              </label>

              <label className="claim-form__field">
                <span>Postal Code <span className="claim-form__required-star">*</span></span>
                <input
                  value={formData.lossPostalCode}
                  onChange={(e) => onFieldChange('lossPostalCode', e.target.value)}
                  onBlur={() => onFieldBlur('lossPostalCode')}
                />
                {errors.lossPostalCode && (
                  <small className="claim-form__error">{errors.lossPostalCode}</small>
                )}
              </label>

            </div>
            </>
          )}

        </div>

      </div>
    </section>
  );
}

export default WhatHappenedSection;