import type { ClaimFormData, UploadedAttachment } from '../types';

interface ReviewSectionProps {
  formData: ClaimFormData;
}

function ReviewField({ label, value }: { label: string; value: string }) {
  return (
   <div className='review-field'>
  <span className='review-field__label'>
    {label}:
    <span className='review-field__value'>
      {value || '—'}
    </span>
  </span>
</div>

  );
}

import { useState,useEffect } from 'react';
import { Icon } from '@pega/cosmos-react-core';

function ReviewBlock({
  title,
  stepNum,
  children,
  onEdit
}: {
  title: string;
  stepNum: number;
  children: React.ReactNode;
  onEdit: () => void;
}) {
  const [isOpen, setIsOpen] = useState(stepNum === 1); // only first open

  return (
    <div className="review-card">

      {/* ✅ HEADER */}
     <div className="review-card__header">

  <div className="review-card__title">
    <span className="review-card__index">{stepNum}</span>
    <span className="review-card__heading">{title}</span>
  </div>

  <div className="review-card__icons">

    <button onClick={onEdit} className="review-card__icon-btn">
      <Icon name="pencil" />
    </button>

    <button
      onClick={() => setIsOpen(prev => !prev)}
      className="review-card__icon-btn"
    >
      <Icon name={isOpen ? 'caret-up' : 'caret-down'} />
    </button>

  </div>

</div>


      {/* ✅ CONTENT */}
      {isOpen && (
        <div className="review-card__content">
          <div className="review-grid">{children}</div>
        </div>
      )}

    </div>
  );
}


function ReviewSection({
  formData,
  setCurrentStep,
  setIsDeclarationValid
}: ReviewSectionProps & { setCurrentStep: (step: number) => void 
  setIsDeclarationValid: (valid: boolean) => void}
)
 {
  const [isFraudChecked, setIsFraudChecked] = useState(false);
const [isAccuracyChecked, setIsAccuracyChecked] = useState(false);


useEffect(() => {
  setIsDeclarationValid(isFraudChecked && isAccuracyChecked);
}, [isFraudChecked, isAccuracyChecked]);

  return (
    <div>
      <ReviewBlock title='Your Details' stepNum={1}  onEdit={() => setCurrentStep(1)}>
        <ReviewField label='First Name' value={formData.firstName} />
        <ReviewField label='Last Name' value={formData.lastName} />
        <ReviewField label='Email' value={formData.email} />
        <ReviewField label='Phone Number' value={formData.phoneNumber} />
        <ReviewField label='Policy Number' value={formData.policyNumber} />
        <ReviewField label='Membership Number' value={formData.membershipNumber} />
        <ReviewField label='Service Number' value={formData.serviceNumber} />
        <ReviewField label='Scheme / Product' value={formData.schemeOrProduct} />
      </ReviewBlock>

      <ReviewBlock title='What Happened' stepNum={2}  onEdit={() => setCurrentStep(2)}>
        <ReviewField label='Relationship to Policyholder' value={formData.relationship} />
        <ReviewField label='Date of Loss' value={formData.dateOfLoss} />
        <ReviewField label='Loss Type' value={formData.lossType} />
        <ReviewField label='Cause of Loss' value={formData.causeOfLoss} />
        <ReviewField label='Country' value={formData.lossCountry} />
        <ReviewField label='Address Line 1' value={formData.lossAddressLine1} />
        <ReviewField label='Address Line 2' value={formData.lossAddressLine2} />
        <ReviewField label='City / Town' value={formData.lossCity} />
        <ReviewField label='Postal Code' value={formData.lossPostalCode} />
        <div className='review-field review-field--full'>
          <span className='review-field__label'>Description</span>
          <span className='review-field__value'>{formData.description || '—'}</span>
        </div>
      </ReviewBlock>

      <ReviewBlock title='Items Affected' stepNum={3}  onEdit={() => setCurrentStep(3)}>
        <ReviewField label='Type of Item' value={formData.itemType} />
        <ReviewField label='Item Description' value={formData.itemDescription} />
        <ReviewField label='Purchase Price (£)' value={formData.purchasePrice} />
        <ReviewField label='Claimed Amount (£)' value={formData.claimedAmount} />
        <ReviewField label='Country' value={formData.policyCountry} />
        <ReviewField label='Address Line 1' value={formData.policyAddressLine1} />
        <ReviewField label='Address Line 2' value={formData.policyAddressLine2} />
        <ReviewField label='City / Town' value={formData.policyCity} />
        <ReviewField label='Postal Code' value={formData.policyPostalCode} />
      </ReviewBlock>

      <ReviewBlock title='Supporting Evidence' stepNum={4}  onEdit={() => setCurrentStep(4)}>
        <div className='review-field review-field--full'>
          <span className='review-field__label'>Uploaded Files</span>
          {formData.attachments.length > 0 ? (
            <ul className='review-field__file-list'>
              {formData.attachments.map((a: UploadedAttachment) => (
                <li key={a.id}>{a.name}</li>
              ))}
            </ul>
          ) : (
            <span className='review-field__value'>No files uploaded</span>
          )}
        </div>
        <ReviewField label='Declaration confirmed' value={formData.hasUserConfirmed ? 'Yes' : 'No'} />
      </ReviewBlock>
      <div className="review-declaration">

  <h3 className="review-declaration__title">
    Declaration
  </h3>

  {/* ✅ Fraud prevention */}
  <div className="review-declaration__item">

    <label className="review-declaration__checkbox">
    <input
  type="checkbox"
  checked={isFraudChecked}
  onChange={(e) => setIsFraudChecked(e.target.checked)}
/>

      <span className="review-declaration__heading">
        Fraud prevention notice
      </span>
    </label>

    <p className="review-declaration__text">
      I understand that, to prevent and detect fraud, the information I provide may be checked against and shared with fraud prevention agencies, public bodies, and other relevant organisations, including the police. This information may be used to verify my claim, manage my policy, recover debt, and prevent fraud.
    </p>

  </div>

  {/* ✅ Claim accuracy */}
  <div className="review-declaration__item">

    <label className="review-declaration__checkbox">
    <input
  type="checkbox"
  checked={isAccuracyChecked}
  onChange={(e) => setIsAccuracyChecked(e.target.checked)}
/>
      <span className="review-declaration__heading">
        Claim accuracy confirmation
      </span>
    </label>

    <p className="review-declaration__text">
      I confirm that the information I have provided as part of this claim is true, complete, and accurate to the best of my knowledge. I understand that providing false or misleading information may result in my claim being rejected, my cover being cancelled or void, and details being recorded with fraud prevention agencies.
    </p>

  </div>

</div>

    </div>
  );
}

export default ReviewSection;
