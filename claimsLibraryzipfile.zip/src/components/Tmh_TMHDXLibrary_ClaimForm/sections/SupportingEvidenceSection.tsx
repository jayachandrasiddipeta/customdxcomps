import type { ChangeEvent } from 'react';

import type { ClaimFormData, ClaimFormErrors, UploadedAttachment } from '../types';
import { ACCEPTED_FILE_TYPES } from '../utils/fileValidationUtils';
import { Icon} from '@pega/cosmos-react-core';
const DOC_TYPE_OPTIONS = [
  '',
  'Policy Document',
  'Proof of Purchase',
  'Police Report',
  'Medical Certificate',
  'Photograph',
  'Invoice / Receipt',
  'Other'
];

const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 MB';
  const mb = bytes / (1024 * 1024);
  return mb < 0.1 ? '< 0.1 MB' : `${mb.toFixed(2)} MB`;
};

interface SupportingEvidenceSectionProps {
  formData: ClaimFormData;
  errors: ClaimFormErrors;
  isUploading: boolean;
  onFileUpload: (files: File[]) => Promise<void>;
  onDeleteAttachment: (attachmentId: string) => void;
  onDocTypeChange: (attachmentId: string, docType: string) => void;
  onConsentChange: (checked: boolean) => void;
  onConsentBlur: () => void;
}

function SupportingEvidenceSection({
  formData,
  errors,
  isUploading,
  onFileUpload,
  onDeleteAttachment,
  onDocTypeChange,
  onConsentChange,
  onConsentBlur
}: SupportingEvidenceSectionProps) {
  const onFileChange = (event: ChangeEvent<HTMLInputElement>) => {
    const selectedFiles = Array.from(event.target.files || []);
    if (selectedFiles.length === 0) return;
    void onFileUpload(selectedFiles);
    event.target.value = '';
  };

  return (
    <section className='claim-form__section'>
      <h3 className='claim-form__section-title'>
        <span className='claim-form__section-index'>4</span>
        Supporting Evidence
      </h3>

<p className="claim-form__evidence-info">
  Upload documents or images that help verify your purchase, ownership, or claim details.
</p>

      <div className='claim-form__upload-dropzone'>
        <input
          className='claim-form__file-input'
          type='file'
          multiple
          accept={ACCEPTED_FILE_TYPES}
          onChange={onFileChange}
          disabled={isUploading}
        />
       <div className="claim-form__upload-icon">

  <svg width="40" height="40" viewBox="0 0 24 24" fill="none">
    <path d="M12 3V15" stroke="#9ca3af" strokeWidth="2" strokeLinecap="round"/>
    <path d="M7 8L12 3L17 8" stroke="#9ca3af" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
    <path d="M5 15V18C5 19.1 5.9 20 7 20H17C18.1 20 19 19.1 19 18V15"
          stroke="#9ca3af" strokeWidth="2" strokeLinecap="round"/>
  </svg>
</div>


<p className='claim-form__upload-title'>
  Drag and drop files here, or click to select
</p>

<p className='claim-form__upload-subtitle'>
  Maximum file size: 10MB
</p>

    
      </div>

      {formData.attachments.length > 0 && (
        <div className='claim-form__attachment-list'>
          {formData.attachments.map((attachment: UploadedAttachment) => (
            <div className='claim-form__attachment-card' key={attachment.id}>
              <div className='claim-form__attachment-card-header'>
               <div>
  <span
    className='claim-form__attachment-card-name'
    title={attachment.name}
  >
    {attachment.name}
  </span>

  {/* ✅ Add size here */}
  <div className='claim-form__attachment-card-size'>
    {formatFileSize(attachment.size)}
  </div>
</div>
                
                <button
                  type='button'
                  className='claim-form__attachment-card-delete'
                  aria-label={`Delete ${attachment.name}`}
                  onClick={() => onDeleteAttachment(attachment.id)}
                >
                 <Icon name="trash" />
                </button>
              </div>
              <div className='claim-form__attachment-card-meta'>
                <label className='claim-form__attachment-card-type'>
                  <span>
  What type of evidence is this?
  <span className='claim-form__required-star'>*</span>
</span>
                  <select
                    value={attachment.docType}
                    onChange={e => onDocTypeChange(attachment.id, e.target.value)}
                  >
                    {DOC_TYPE_OPTIONS.map(opt => (
                      <option key={opt} value={opt}>{opt || 'Select type…'}</option>
                    ))}
                  </select>
                </label>
                
              </div>
            </div>
          ))}
        </div>
      )}

      {/* <div className='claim-form__consent-box'>
        <input
          id='claim-consent'
          type='checkbox'
          checked={formData.hasUserConfirmed}
          onChange={event => onConsentChange(event.target.checked)}
          onBlur={onConsentBlur}
        />
        <label htmlFor='claim-consent'>
          I declare that the information provided is true and accurate to the best of my knowledge.
          I understand that providing false information may result in my claim being rejected and
          could constitute fraud.
        </label>
      </div> */}
      {errors.hasUserConfirmed && (
        <small className='claim-form__error'>{errors.hasUserConfirmed}</small>
      )}
    </section>
  );
}

export default SupportingEvidenceSection;
