import { useState } from 'react';

import { downloadPdfFromBase64, fetchClaimAcknowledgementBase64 } from '../utils/claimAcknowledgementUtils';

interface ClaimConfirmationViewProps {
  caseId: string;
  onClose: () => void;
  /** Pega data page name that returns the acknowledgement PDF as AckFileSource (base64). */
  acknowledgementDataPage: string;
}

function ClaimConfirmationView({ caseId, onClose, acknowledgementDataPage }: ClaimConfirmationViewProps) {
  const referenceId = caseId || 'Pending';
  const hasCaseId = Boolean(caseId?.trim());
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadError, setDownloadError] = useState('');

  const handleDownloadAcknowledgement = async () => {
    if (!hasCaseId) {
      return;
    }
    setDownloadError('');
    setIsDownloading(true);
    try {
      const base64 = await fetchClaimAcknowledgementBase64(caseId.trim(), acknowledgementDataPage);
      const safeName = caseId.trim().replace(/\s+/g, '-');
      downloadPdfFromBase64(base64, `Claim-Acknowledgement-${safeName}.pdf`);
    } catch (error) {
      setDownloadError(error instanceof Error ? error.message : 'Download failed.');
    } finally {
      setIsDownloading(false);
    }
  };
const handleSaveReference = () => {
  const content = `Claim Reference: FNOL-${referenceId}`;

  const blob = new Blob([content], { type: 'text/plain' });
  const url = window.URL.createObjectURL(blob);

  const link = document.createElement('a');
  link.href = url;
  link.download = `Claim-Reference-${referenceId}.txt`;

  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  window.URL.revokeObjectURL(url);
};

  return (
    <div className='claim-confirmation-shell'>
  <div className='claim-confirmation'>

    {/* ✅ MAIN TITLE */}
    <h2 className='claim-confirmation__title'>
      Your claim has been submitted
    </h2>

    <p className='claim-confirmation__subtitle'>
      A confirmation email has been sent.
    </p>

    {/* ✅ BLUE CARD */}
    <div className='claim-confirmation__reference-card'>

      <p className='claim-confirmation__reference-text'>
        Your claim reference number is:
      </p>

      <div className='claim-confirmation__case-id'>
        FNOL-{referenceId}
      </div>

      <p className='claim-confirmation__reference-subtext'>
        Please keep this reference number for any future correspondence regarding your claim.
      </p>

    </div>

    {/* ✅ WHAT HAPPENS NEXT */}
    <h3 className='claim-confirmation__section-title'>
      What happens next?
    </h3>

    <ul className='claim-confirmation__list'>
      <li>Your claim has been received and will be reviewed by our Claims Team.</li>
      <li>If we need any further information, we will contact you</li>
      <li>We will keep you updated as your claim progresses</li>
      <li>Please ensure any future correspondence quotes your claim reference number</li>
    </ul>

    {/* ✅ SUPPORT SECTION */}
    <h3 className='claim-confirmation__section-title'>
      Need support?
    </h3>

    <p className='claim-confirmation__body'>
      If you have any questions regarding your claim, please contact our Claims Team
      and quote your claim reference number.
    </p>

    <p><strong>Email:</strong> triclaims@tmhcc.com</p>
    <p><strong>Telephone:</strong> 08081 754 908 (freephone)</p>
    <p><strong>Support Hours:</strong> Monday – Friday, 9:00am – 5:00pm</p>

    {/* ✅ ACTIONS */}
    <div className='claim-confirmation__actions'>

      <button
        type='button'
        className='claim-confirmation__button claim-confirmation__button--outline'
        onClick={handleSaveReference}
        disabled={isDownloading}
      >
        {isDownloading ? 'Preparing...' : 'Save Claim Reference'}
      </button>

      <button
        type='button'
        className='claim-confirmation__button claim-confirmation__button--primary'
        onClick={onClose}
      >
        Return to Home Page
      </button>

    </div>

  </div>
</div>

  );
}

export default ClaimConfirmationView;
