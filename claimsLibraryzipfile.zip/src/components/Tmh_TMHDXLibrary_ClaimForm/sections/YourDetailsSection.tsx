import type { ClaimFormData, ClaimFormErrors } from '../types';
import { useState } from 'react';
import PolicyAddressSection from './PolicyAddress';
const PRODUCT_OPTIONS = ['', 'Military Kit Contents and Personal Possessions'];
const RELATIONSHIP_OPTIONS = ['', 'Policyholder', 'Spouse / Partner', 'Dependent', 'Other'];
const COUNTRY_OPTIONS = ['', 'United Kingdom', 'United States', 'Australia', 'Canada'];

interface YourDetailsSectionProps {
  formData: ClaimFormData;
  errors: ClaimFormErrors;
  onFieldChange: (field: keyof ClaimFormData, value: string) => void;
  onFieldBlur: (field: keyof ClaimFormData) => void;
}

function YourDetailsSection({
  formData,
  errors,
  onFieldChange,
  onFieldBlur
}: YourDetailsSectionProps) {
  const [showInfo, setShowInfo] = useState(false);

  return (
    <>
      {/* ✅ TITLE + ICON INLINE */}
      <h3 className="claim-form__section-title claim-form__section-title--primary claim-form__title-with-icon">
        Your details

        <button
          type="button"
          className="claim-form__info-icon"
          onClick={() => setShowInfo(prev => !prev)}
          aria-label="Show info"
        >
          i
        </button>
      </h3>

      {/* ✅ INFO BOX */}
     {showInfo && (
  <div className="claim-form__info-box">

    {/* ✅ LEFT SIDE */}
    <div className="claim-form__info-left">

      {/* ✅ ICON */}
      <div className="claim-form__info-box-icon">
        i
      </div>

      {/* ✅ TEXT */}
      <div className="claim-form__info-content">
        Please provide the policyholder's contact details and policy information.
        If you are claiming on behalf of someone else, select your relationship
        to the policyholder. All required fields are marked with an asterisk.
      </div>

    </div>

    {/* ✅ CLOSE BUTTON (RIGHT) */}
    <button
      type="button"
      className="claim-form__info-close"
      onClick={() => setShowInfo(false)}
    >
      ×
    </button>

  </div>
)}

      {/* ✅ GREY BACKGROUND FORM BLOCK */}
      <div className="claim-form__group">
        <div className="claim-form__grid">

          {/* Row 1 */}
          <label className="claim-form__field">
            <span>Policy Number <span className="claim-form__required-star">*</span></span>
            <input
              value={formData.policyNumber}
              onChange={(e) => onFieldChange('policyNumber', e.target.value)}
               onBlur={() => onFieldBlur('policyNumber')}
            />
            
  {errors.policyNumber && (
    <small className="claim-form__error">
      {errors.policyNumber}
    </small>
  )}

          </label>

          <label className="claim-form__field">
            <span>Product <span className="claim-form__required-star">*</span></span>
            <select
              value={formData.schemeOrProduct}
              onChange={(e) => onFieldChange('schemeOrProduct', e.target.value)}
               onBlur={() => onFieldBlur('schemeOrProduct')}
            >
                {errors.schemeOrProduct && (
    <small className="claim-form__error">
      {errors.schemeOrProduct}
    </small>
  )}
              {PRODUCT_OPTIONS.map(opt => (
                <option key={opt} value={opt}>
                  {opt || 'Select...'}
                </option>
              ))}
            </select>
          </label>

          {/* Row 2 */}
          <label className="claim-form__field">
            <span>Service Number</span>
            <input
              value={formData.serviceNumber}
              onChange={(e) => onFieldChange('serviceNumber', e.target.value)}
               onBlur={() => onFieldBlur('serviceNumber')}
            />     
 {errors.serviceNumber && (
    <small className="claim-form__error">{errors.serviceNumber}</small>
  )}

          </label>

          <label className="claim-form__field">
            <span>Relationship to Policyholder<span className="claim-form__required-star">*</span></span>
            <select
              value={formData.relationship}
              onChange={(e) => onFieldChange('relationship', e.target.value)}
              onBlur={() => onFieldBlur('relationship')}
            >
              
              {RELATIONSHIP_OPTIONS.map(opt => (
                <option key={opt} value={opt}>
                  {opt || 'Select...'}
                </option>
              ))}
            </select>
          </label>

          {/* Row 3 */}
          <label className="claim-form__field">
            <span>First Name <span className="claim-form__required-star">*</span></span>
            <input
              value={formData.firstName}
              onChange={(e) => onFieldChange('firstName', e.target.value)}
              onBlur={() => onFieldBlur('firstName')}
            />
            {errors.firstName && (
    <small className="claim-form__error">{errors.firstName}</small>
  )}

          </label>

          <label className="claim-form__field">
            <span>Last Name <span className="claim-form__required-star">*</span></span>
            <input
              value={formData.lastName}
              onChange={(e) => onFieldChange('lastName', e.target.value)}
              onBlur={() => onFieldBlur('lastName')}
            />
                 {errors.lastName && (
    <small className="claim-form__error">{errors.lastName}</small>
  )}
          </label>

          {/* Row 4 */}
          <label className="claim-form__field">
            <span>Email Address <span className="claim-form__required-star">*</span></span>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => onFieldChange('email', e.target.value)}
              onBlur={() => onFieldBlur('email')}
            />
               {errors.email && (
    <small className="claim-form__error">{errors.email}</small>
  )}
          </label>

          <label className="claim-form__field">
            <span>Phone Number <span className="claim-form__required-star">*</span></span>
            <input
              value={formData.phoneNumber}
              onChange={(e) => onFieldChange('phoneNumber', e.target.value)}
               onBlur={() => onFieldBlur('phoneNumber')}
            />
                   {errors.phoneNumber && (
    <small className="claim-form__error">{errors.phoneNumber}</small>
  )}
          </label>

        </div>
      </div>

      {/* ✅ POLICY ADDRESS SECTION (CARD) */}
      <section className="claim-form__section">
        <h3 className="claim-form__section-title claim-form__section-title--secondary">
          Policyholder Address
        </h3>

        <div className="claim-form__grid">

          <label className="claim-form__field claim-form__field--full">
            <span>Country <span className="claim-form__required-star">*</span></span>
            <select
              value={formData.policyCountry}
              onChange={(e) => onFieldChange('policyCountry', e.target.value)}
                onBlur={() => onFieldBlur('policyCountry')}
            >
              {COUNTRY_OPTIONS.map(opt => (
                <option key={opt} value={opt}>
                  {opt || 'Select...'}
                </option>
              ))}
            </select>
             {errors.policyCountry && (
    <small className="claim-form__error">{errors.policyCountry}</small>
  )}
          </label>

          <label className="claim-form__field claim-form__field--full">
            <span>Address Line 1 <span className="claim-form__required-star">*</span></span>
            <input
              value={formData.policyAddressLine1}
              onChange={(e) => onFieldChange('policyAddressLine1', e.target.value)}
                onBlur={() => onFieldBlur('policyAddressLine1')}
            />
                {errors.policyAddressLine1 && (
    <small className="claim-form__error">{errors.policyAddressLine1}</small>
  )}
          </label>

          <label className="claim-form__field claim-form__field--full">
            <span>Address Line 2</span>
            <input
              value={formData.policyAddressLine2}
              onChange={(e) => onFieldChange('policyAddressLine2', e.target.value)}
              onBlur={() => onFieldBlur('policyAddressLine2')}
            />
                      {errors.policyAddressLine2 && (
    <small className="claim-form__error">{errors.policyAddressLine2}</small>
  )}
          </label>

          <label className="claim-form__field">
            <span>City / Town <span className="claim-form__required-star">*</span></span>
            <input
              value={formData.policyCity}
              onChange={(e) => onFieldChange('policyCity', e.target.value)}
              onBlur={() => onFieldBlur('policyCity')}
            />
             {errors.policyCity && (
    <small className="claim-form__error">{errors.policyCity}</small>
  )}
          </label>

          <label className="claim-form__field">
            <span>Postcode <span className="claim-form__required-star">*</span></span>
            <input
              value={formData.policyPostalCode}
              onChange={(e) => onFieldChange('policyPostalCode', e.target.value)}
              onBlur={() => onFieldBlur('policyPostalCode')}
            />
            {errors.policyPostalCode && (
    <small className="claim-form__error">{errors.policyPostalCode}</small>
  )}
          </label>

        </div>
      </section>
      {/* <PolicyAddressSection
  formData={formData}
  errors={errors}
  onFieldChange={onFieldChange}
/> */}
    </>
  );
}

export default YourDetailsSection;
