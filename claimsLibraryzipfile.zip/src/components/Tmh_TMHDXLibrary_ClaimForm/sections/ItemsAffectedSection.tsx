import type { ClaimFormData, ClaimFormErrors } from '../types';
import { useState } from 'react';
const ITEM_TYPE_OPTIONS = ['', 'Electronics', 'Jewellery', 'Clothing', 'Military Equipment', 'Furniture', 'Other'];
const COUNTRY_OPTIONS = ['', 'United Kingdom', 'United States', 'Australia', 'Canada', 'Germany', 'France', 'Other'];

interface ItemsAffectedSectionProps {
  formData: ClaimFormData;
  errors: ClaimFormErrors;
  onFieldChange: (field: keyof ClaimFormData, value: string) => void;
  onFieldBlur: (field: keyof ClaimFormData) => void;
}

function ItemsAffectedSection({ formData, errors, onFieldChange, onFieldBlur }: ItemsAffectedSectionProps) {
   const [showInfo, setShowInfo] = useState(false);
  return (
    <section className='claim-form__section'>
      <h3 className='claim-form__section-title'>
        {/* <span className='claim-form__section-index'>3</span> */}
        Items Affected
             <button
          type="button"
          className="claim-form__info-icon"
          onClick={() => setShowInfo(prev => !prev)}
          aria-label="Show info"
        >
          i
        </button>
      </h3>
         {showInfo && (
  <div className="claim-form__info-box">

    {/* ✅ LEFT SIDE */}
    <div className="claim-form__info-left">

      {/* ✅ ICON */}
      <div className="claim-form__info-box-icon">
        i
      </div>

      {/* ✅ TEXT */}
      <div className="claim-form__info-content">
        Please provide the policyholder's contact details and policy information.
        If you are claiming on behalf of someone else, select your relationship
        to the policyholder. All required fields are marked with an asterisk.
      </div>

    </div>

    {/* ✅ CLOSE BUTTON (RIGHT) */}
    <button
      type="button"
      className="claim-form__info-close"
      onClick={() => setShowInfo(false)}
    >
      ×
    </button>

  </div>
)}
       <div className="claim-form__group claim-form__field--full">
    <div className='claim-form__grid'>

  {/* ✅ Row 1 */}
  <label className='claim-form__field'>
    <span>
      Type of Item <span className='claim-form__required-star'>*</span>
    </span>
    <select
      required
      value={formData.itemType}
      onChange={e => onFieldChange('itemType', e.target.value)}
      onBlur={() => onFieldBlur('itemType')}
    >
      {ITEM_TYPE_OPTIONS.map(opt => (
        <option key={opt} value={opt}>{opt || 'Select...'}</option>
      ))}
    </select>
    {errors.itemType && <small className='claim-form__error'>{errors.itemType}</small>}
  </label>

  <label className='claim-form__field'>
    <span>
      Claimed Amount (£) <span className='claim-form__required-star'>*</span>
    </span>
    <input
      type='number'
      min='0'
      step='0.01'
      required
      value={formData.claimedAmount}
      onChange={e => onFieldChange('claimedAmount', e.target.value)}
      onBlur={() => onFieldBlur('claimedAmount')}
    />
    {errors.claimedAmount && <small className='claim-form__error'>{errors.claimedAmount}</small>}
  </label>

  {/* ✅ Row 2 */}
  <label className='claim-form__field claim-form__field--full'>
    <span>Item Description <span className='claim-form__required-star'>*</span></span>
    <input
      type='text'
      placeholder='e.g., iPhone 14 Pro'
      value={formData.itemDescription}
       onBlur={() => onFieldBlur('itemDescription')}
      onChange={e => onFieldChange('itemDescription', e.target.value)}
    />
     {errors.itemDescription && <small className='claim-form__error'>{errors.itemDescription}</small>}
  </label>

  {/* ✅ Row 3 */}
  <label className='claim-form__field'>
    <span>
      Purchase Price (£) <span className='claim-form__required-star'>*</span>
    </span>
    <input
      type='number'
      min='0'
      step='0.01'
      required
      value={formData.purchasePrice}
      onChange={e => onFieldChange('purchasePrice', e.target.value)}
      onBlur={() => onFieldBlur('purchasePrice')}
    />
    {errors.purchasePrice && <small className='claim-form__error'>{errors.purchasePrice}</small>}
  </label>

  <label className='claim-form__field'>
    <span>
      Date Purchased <span className='claim-form__required-star'>*</span>
    </span>
    <input
      type='date'
      required
      value={formData.datePurchased || ''}
      onChange={e => onFieldChange('datePurchased', e.target.value)}
      onBlur={() => onFieldBlur('datePurchased')}
    />
    {errors.datePurchased && <small className='claim-form__error'>{errors.datePurchased}</small>}
  </label>

</div>
</div>
    </section>
  );
}

export default ItemsAffectedSection;
