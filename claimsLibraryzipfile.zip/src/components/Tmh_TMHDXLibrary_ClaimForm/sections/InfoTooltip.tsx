import { useState } from 'react';
interface InfoBoxProps {
  message: string;
}

function InfoBox({ message }: InfoBoxProps) {
  const [showInfo, setShowInfo] = useState(false);

  return (
    <>
      {/* TITLE ICON */}
      <button
        type="button"
        className="claim-form__info-icon"
        onClick={() => setShowInfo(prev => !prev)}
        aria-label="Show info"
      >
        i
      </button>

      {/* INFO BOX */}
      {showInfo && (
        <div className="claim-form__info-box">
          <div className="claim-form__info-left">
            <div className="claim-form__info-box-icon">i</div>

            <div className="claim-form__info-content">
              {message}
            </div>
          </div>

          <button
            type="button"
            className="claim-form__info-close"
            onClick={() => setShowInfo(false)}
          >
            ×
          </button>
        </div>
      )}
    </>
  );
}

export default InfoBox;