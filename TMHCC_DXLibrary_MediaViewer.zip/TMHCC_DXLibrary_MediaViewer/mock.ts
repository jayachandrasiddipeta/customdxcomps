
export const configProps = {
  value: 'ATT-101',
  label: 'Attachment',
  testId: 'MediaViewer-12345678',
  displayMode: '',
  variant: '',
  hideLabel: false,
  disabled: false,
  dataPageName: 'D_AttachmentContent',
  dataPageParamName: 'AttachmentID',
  actionType: 'Link' as const,
  buttonVariant: 'secondary' as const,
  showViewLink: true,
  viewLinkLabel: 'View Attachment',
  showDownloadLink: true,
  downloadLinkLabel: 'Download Attachment',
  showPdfToolbar: true,
  allowModalResize: false
};

// Shape of a data page row as returned OOTB: pyAttachStream (base64), pyAttachMimeType, pyRepositoryFileName
// 1x1 transparent PNG, used to demo the view/download flow without a real attachment
export const sampleAttachment = {
  pyAttachStream:
    'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mNkYAAAAAYAAjCB0C8AAAAASUVORK5CYII=',
  pyAttachMimeType: 'image/png',
  pyRepositoryFileName: 'sample-image.png'
};
