// individual style, comment out above, and uncomment here and add styles
import styled, { css } from 'styled-components';
import { Button } from '@pega/cosmos-react-core';

export default styled.div(() => {
  return css`
    margin: 0px 0;
  `;
});

// Link-styled action without the OOTB hover underline
export const StyledLinkAction = styled(Button)(() => {
  return css`
    &,
    &:hover,
    &:active {
      text-decoration: none;
    }
  `;
});
