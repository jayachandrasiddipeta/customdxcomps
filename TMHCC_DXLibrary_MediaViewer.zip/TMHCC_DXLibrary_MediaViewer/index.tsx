import { useState } from 'react';
import { Button, FieldValueList, useModalManager, useToaster, withConfiguration } from '@pega/cosmos-react-core';
import type { PConnFieldProps } from '../shared/PConnProps';
import '../shared/create-nonce';

import AttachmentViewerModal from './AttachmentViewerModal';
import { downloadBase64File, fetchAttachmentContent } from './utils/attachmentContentUtils';
import { useLocalization } from './utils/useLocalization';
import StyledTmhccDxLibraryMediaViewerWrapper, { StyledLinkAction } from './styles';

// interface for props
interface TmhccDxLibraryMediaViewerProps extends PConnFieldProps {
  dataPageName?: string;
  dataPageParamName?: string;
  actionType?: 'Link' | 'Button';
  buttonVariant?: 'primary' | 'secondary';
  showViewLink?: boolean;
  viewLinkLabel?: string;
  showDownloadLink?: boolean;
  downloadLinkLabel?: string;
  showPdfToolbar?: boolean;
  allowModalResize?: boolean;
  variant?: any;
}

// props passed in combination of props from property panel (config.json) and run time props from Constellation
// any default values in config.pros should be set in defaultProps at bottom of this file
function TmhccDxLibraryMediaViewer(props: TmhccDxLibraryMediaViewerProps) {
  const {
    getPConnect,
    value,
    label,
    hideLabel = false,
    testId,
    displayMode,
    variant = 'inline',
    disabled = false,
    dataPageName = '',
    dataPageParamName = '',
    actionType = 'Link',
    buttonVariant = 'secondary',
    showViewLink = true,
    viewLinkLabel = '',
    showDownloadLink = true,
    downloadLinkLabel = '',
    showPdfToolbar = true,
    allowModalResize = false
  } = props;

  const pConn = getPConnect();
  const { create } = useModalManager();
  const { push } = useToaster();
  const l = useLocalization(getPConnect);
  const [isDownloading, setIsDownloading] = useState(false);

  const loadAttachmentContent = async () => {
    if (!dataPageName || !dataPageParamName || !value) {
      return null;
    }
    const attachment = await fetchAttachmentContent(dataPageName, dataPageParamName, value, pConn.getContextName());
    if (!attachment) {
      push({ content: l.UnableToLoadAttachment });
    }
    return attachment;
  };

  const handleView = async () => {
    const modal = create(
      AttachmentViewerModal,
      {
        attachment: null,
        l,
        showPdfToolbar,
        allowModalResize
      },
      { dismissible: true }
    );
    const attachment = await loadAttachmentContent();
    if (attachment) {
      modal.update({ attachment });
    } else {
      modal.dismiss();
    }
  };

  const handleDownload = async () => {
    setIsDownloading(true);
    const attachment = await loadAttachmentContent();
    setIsDownloading(false);
    if (attachment) {
      downloadBase64File(attachment.base64Content, attachment.mimeType, attachment.fileName);
    }
  };

  const renderAction = (key: 'view' | 'download', text: string, onClick: () => void, isLoading: boolean) => {
    if (actionType === 'Button') {
      return (
        <Button key={key} variant={buttonVariant} disabled={disabled} loading={isLoading} onClick={onClick}>
          {text}
        </Button>
      );
    }
    return (
      <StyledLinkAction key={key} variant='link' disabled={disabled} loading={isLoading} onClick={onClick}>
        {text}
      </StyledLinkAction>
    );
  };

  const viewLabel = viewLinkLabel || l.View;
  const downloadLabel = downloadLinkLabel || l.Download;

  const actions = [];
  if (showViewLink) {
    actions.push(renderAction('view', viewLabel, handleView, false));
  }
  if (showDownloadLink) {
    actions.push(renderAction('download', downloadLabel, handleDownload, isDownloading));
  }

  const actionRow =
    value && actions.length > 0 ? (
      <div style={{ display: 'flex', gap: '0.5rem' }}>{actions}</div>
    ) : (
      <span aria-hidden='true'>&ndash;&ndash;</span>
    );

  if (displayMode === 'DISPLAY_ONLY') {
    return <StyledTmhccDxLibraryMediaViewerWrapper data-testid={testId}>{actionRow}</StyledTmhccDxLibraryMediaViewerWrapper>;
  }

  return (
    <StyledTmhccDxLibraryMediaViewerWrapper>
      <FieldValueList
        variant={hideLabel ? 'stacked' : variant}
        data-testid={testId}
        fields={[{ id: '1', name: hideLabel ? '' : label, value: actionRow }]}
      />
    </StyledTmhccDxLibraryMediaViewerWrapper>
  );
}

export default withConfiguration(TmhccDxLibraryMediaViewer);
