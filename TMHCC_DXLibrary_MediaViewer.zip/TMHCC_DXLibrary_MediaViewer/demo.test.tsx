// import { expect, test } from '@jest/globals';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import { composeStories } from '@storybook/react';
import '@testing-library/jest-dom';

import * as DemoStories from './demo.stories';

const { BaseTmhccDxLibraryMediaViewer } = composeStories(DemoStories);

test('renders view and download links and opens the viewer modal', async () => {
  render(<BaseTmhccDxLibraryMediaViewer />);

  const viewLink = await screen.findByText('View Attachment');
  const downloadLink = await screen.findByText('Download Attachment');
  expect(viewLink).toBeVisible();
  expect(downloadLink).toBeVisible();

  await userEvent.click(viewLink);

  await waitFor(() => expect(screen.getByText('sample-image.png')).toBeVisible());
});
