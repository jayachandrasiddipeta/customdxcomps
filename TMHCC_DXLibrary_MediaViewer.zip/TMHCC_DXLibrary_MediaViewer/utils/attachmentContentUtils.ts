export interface AttachmentContent {
  base64Content: string;
  fileName: string;
  mimeType: string;
}

// Data page must return a single row with the OOTB attachment content fields:
// pyAttachStream (base64 content), pyAttachMimeType (file type), pyRepositoryFileName (file name)
export async function fetchAttachmentContent(
  dataPageName: string,
  dataPageParamName: string,
  paramValue: string,
  context?: string
): Promise<AttachmentContent | null> {
  const parameters = { [dataPageParamName]: paramValue };
  const options = {
    invalidateCache: true
  };
  const record = await (window as any).PCore.getDataPageUtils().getPageDataAsync(
    dataPageName,
    context,
    parameters,
    options
  );
  if (!record || !record.pyAttachStream) {
    return null;
  }
  return {
    base64Content: record.pyAttachStream,
    fileName: record.pyRepositoryFileName ?? '',
    mimeType: record.pyAttachMimeType ?? ''
  };
}

// Data pages commonly wrap base64 content with line breaks (RFC 2045 style) or an
// accidental "data:...;base64," prefix; strip both before decoding.
function decodeBase64ToBuffer(base64Content: string): ArrayBuffer {
  const cleaned = base64Content.replace(/^data:[^,]*,/, '').replace(/\s/g, '');
  const byteString = atob(cleaned);
  const buffer = new ArrayBuffer(byteString.length);
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < byteString.length; i += 1) {
    bytes[i] = byteString.charCodeAt(i);
  }
  return buffer;
}

export function createAttachmentBlobUrl(base64Content: string, mimeType: string): string {
  const blob = new Blob([decodeBase64ToBuffer(base64Content)], { type: mimeType || 'application/octet-stream' });
  return URL.createObjectURL(blob);
}

export function downloadBase64File(base64Content: string, mimeType: string, fileName: string) {
  const url = createAttachmentBlobUrl(base64Content, mimeType);
  const link = document.createElement('a');
  link.href = url;
  link.download = fileName || 'attachment';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}
