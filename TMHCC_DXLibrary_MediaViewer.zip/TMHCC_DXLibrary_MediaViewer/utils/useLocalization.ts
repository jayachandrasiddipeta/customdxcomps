import { useMemo } from 'react';
import localizations from '../localizations.json';

export type LocalizationMap = typeof localizations.fields;

export function useLocalization(getPConnect: (() => any) | undefined): LocalizationMap {
  return useMemo(() => {
    const defaults = localizations.fields as LocalizationMap;
    try {
      const locService = typeof getPConnect === 'function' ? getPConnect()?.getLocalizationService?.() : null;
      if (!locService?.getLocalizedText) return defaults;
      const result = { ...defaults };
      for (const key of Object.keys(defaults) as (keyof LocalizationMap)[]) {
        const translated: string | null | undefined = locService.getLocalizedText(key);
        if (translated != null) {
          result[key] = translated;
        }
      }
      return result;
    } catch {
      return defaults;
    }
  }, [getPConnect]);
}
