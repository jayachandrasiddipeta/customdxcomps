
/* eslint-disable react/jsx-no-useless-fragment */
import type { Meta, StoryObj } from '@storybook/react';

import TmhccDxLibraryMediaViewer from './index';

import { configProps, sampleAttachment } from './mock';

const meta: Meta<typeof TmhccDxLibraryMediaViewer> = {
  title: 'TmhccDxLibraryMediaViewer',
  component: TmhccDxLibraryMediaViewer,
  excludeStories: /.*Data$/
};

export default meta;
type Story = StoryObj<typeof TmhccDxLibraryMediaViewer>;

const setPCore = () => {
  (window as any).PCore = {
    getDataPageUtils: () => {
      return {
        getPageDataAsync: () => {
          return Promise.resolve(sampleAttachment);
        }
      };
    }
  };
};

export const BaseTmhccDxLibraryMediaViewer: Story = (args: any) => {
  setPCore();

  const props = {
    value: configProps.value,
    getPConnect: () => {
      return {
        getContextName: () => '',
        getLocalizationService: () => null
      };
    }
  };

  return (
    <>
      <TmhccDxLibraryMediaViewer {...props} {...args} />
    </>
  );
};

BaseTmhccDxLibraryMediaViewer.args = {
  label: configProps.label,
  testId: configProps.testId,
  disabled: configProps.disabled,
  hideLabel: configProps.hideLabel,
  displayMode: configProps.displayMode,
  variant: configProps.variant,
  dataPageName: configProps.dataPageName,
  dataPageParamName: configProps.dataPageParamName,
  actionType: configProps.actionType,
  buttonVariant: configProps.buttonVariant,
  showViewLink: configProps.showViewLink,
  viewLinkLabel: configProps.viewLinkLabel,
  showDownloadLink: configProps.showDownloadLink,
  downloadLinkLabel: configProps.downloadLinkLabel,
  showPdfToolbar: configProps.showPdfToolbar,
  allowModalResize: configProps.allowModalResize
};
