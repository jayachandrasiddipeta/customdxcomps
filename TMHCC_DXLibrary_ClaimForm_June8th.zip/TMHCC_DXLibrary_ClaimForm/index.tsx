import { useEffect, useLayoutEffect, useRef, useState } from 'react';
import { Icon, Progress, registerIcon, useModalManager, withConfiguration } from '@pega/cosmos-react-core';
import * as check from '@pega/cosmos-react-core/lib/components/Icon/icons/check.icon';
// @ts-ignore
import * as information from '@pega/cosmos-react-core/lib/components/Icon/icons/information.icon';
// @ts-ignore
import * as trash from '@pega/cosmos-react-core/lib/components/Icon/icons/trash.icon';
// @ts-ignore
import * as pencil from '@pega/cosmos-react-core/lib/components/Icon/icons/pencil.icon';
// @ts-ignore
import * as caretUp from '@pega/cosmos-react-core/lib/components/Icon/icons/caret-up.icon';
// @ts-ignore
import * as caretDown from '@pega/cosmos-react-core/lib/components/Icon/icons/caret-down.icon';

import type { PConnFieldProps } from '../shared/PConnProps';

import ClaimConfirmationView from './sections/ClaimConfirmationView';
import DiscardChangesModal from './sections/DiscardChangesModal';
import ItemsAffectedSection from './sections/ItemsAffectedSection';
import ReviewSection from './sections/ReviewSection';
import SupportingEvidenceSection from './sections/SupportingEvidenceSection';
import WhatHappenedSection from './sections/WhatHappenedSection';
import YourDetailsSection from './sections/YourDetailsSection';
import StyledTmhccDxLibraryClaimFormWrapper, { ClaimFormGlobalStyles } from './styles';
import type { ClaimFormData, ClaimFormErrors } from './types';
import { fetchAllListValues, fetchCountryList, LIST_CATEGORIES, type ListOption, type CountryOption } from './utils/listValuesUtils';
import { clearAttachmentIdsInSession, saveAttachmentIdsInSession } from './utils/attachmentSessionUtils';
import { uploadAttachments } from './utils/attachmentUploadUtils';
import { attachUploadedFilesToCase } from './utils/caseAttachmentUtils';
import { getClaimFieldValidationError, getClaimFormValidationErrors, getStepValidationErrors } from './utils/claimFormValidation';
import { closeCurrentBrowserContext } from './utils/claimFormStateUtils';
import { useLocalization, useGetLocalizedText } from './utils/useLocalization';
import { createClaimCase } from './utils/claimUtils';
import { validateFileTypes } from './utils/fileValidationUtils';
import { createTurnstileController, type TurnstileController } from './utils/turnstileUtils';
import { usePortalMask } from './utils/usePortalMask';

registerIcon(check);
registerIcon(information);
registerIcon(trash);
registerIcon(pencil);
registerIcon(caretUp);
registerIcon(caretDown);

interface TmhccDxLibraryClaimFormProps extends PConnFieldProps {
  caseTypeID?: string;
  turnstileSiteKey?: string;
  enableTurnstile?: boolean;
  createClaimApiPath?: string;
  /** URL for the left-column image. */
  imageSrc?: string;
  /** Data page name used to fetch LOV (list of values) data. */
  lovDataPageName?: string;
  /** Data page name used to fetch confirmation view content. */
  confirmationDataPageName?: string;
}

const INITIAL_FORM_DATA: ClaimFormData = {
  datePurchased: '',
  theftReported: '',
  crimeReferenceNumber: '',
  firstName: '',
  lastName: '',
  email: '',
  phoneNumber: '',
  phoneDialingCode: 'GB',
  policyNumber: '',
  membershipNumber: '',
  serviceNumber: '',
  schemeOrProduct: '',
  relationship: '',
  dateOfLoss: '',
  lossType: '',
  causeOfLoss: '',
  lossLocationType: 'PHA',
  lossCountry: '',
  lossAddressLine1: '',
  lossAddressLine2: '',
  lossCity: '',
  lossPostalCode: '',
  description: '',
  itemType: '',
  itemDescription: '',
  purchasePrice: '',
  claimedAmount: '',
  policyCountry: '',
  policyAddressLine1: '',
  policyAddressLine2: '',
  policyCity: '',
  policyPostalCode: '',
  hasUserConfirmed: false,
  attachments: [],
  fraudPreventionNotice: false,
  claimAccuracyConfirmation: false,
};


const getCaseDisplayId = (caseId: string): string => {
  const trimmedCaseId = caseId.trim();
  if (!trimmedCaseId) return '';
  const lastSpaceIndex = trimmedCaseId.lastIndexOf(' ');
  return lastSpaceIndex >= 0 ? trimmedCaseId.substring(lastSpaceIndex + 1) : trimmedCaseId;
};

function TmhccDxLibraryClaimForm(props: TmhccDxLibraryClaimFormProps) {
  const {
    caseTypeID = 'TMHCC-Claims-Work-Claim',
    turnstileSiteKey = '',
    enableTurnstile = true,
    createClaimApiPath = 'api/TrinityClaims/v1/create',
    imageSrc = 'https://res.cloudinary.com/dnut6tij7/image/upload/v1780247789/image_trinity_etftbs.png',
    lovDataPageName = 'D_LOVList',
    confirmationDataPageName = 'D_ClaimConfirmationInfo'
  } = props;
  const { getPConnect } = props;
  const l = useLocalization(getPConnect);
  const getLocalizedText = useGetLocalizedText(getPConnect);

  const turnstileSiteKeyTrimmed = enableTurnstile ? (turnstileSiteKey ?? '').trim() : '';
  const turnstileHostRef = useRef<HTMLDivElement | null>(null);
  const turnstileControllerRef = useRef<TurnstileController | null>(null);

  const [formData, setFormData] = useState<ClaimFormData>(INITIAL_FORM_DATA);
  const [errors, setErrors] = useState<ClaimFormErrors>({});
  const [submitError, setSubmitError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [showConfirmationView, setShowConfirmationView] = useState(false);
  const [createdCaseId, setCreatedCaseId] = useState('');
  const [currentStep, setCurrentStep] = useState(1);
  const [turnstileFormUnlocked, setTurnstileFormUnlocked] = useState(!turnstileSiteKeyTrimmed);
  const [isTurnstileBooting, setIsTurnstileBooting] = useState(Boolean(turnstileSiteKeyTrimmed));
  const [turnstileError, setTurnstileError] = useState('');
  const { create } = useModalManager();
  const isMasked = usePortalMask();
  const [listValues, setListValues] = useState<Record<string, ListOption[]>>({});
  const [countryOptions, setCountryOptions] = useState<CountryOption[]>([]);
  const [attachmentErrors, setAttachmentErrors] = useState<Record<string, { docType?: string; otherDocType?: string }>>({});

  const getLabel = (category: string, key: string): string => {
    if (!key?.trim()) return key;
    const optionMap: Record<string, ListOption[]> = {
      product:      listValues[LIST_CATEGORIES.PRODUCT]       ?? [],
      relationship: listValues[LIST_CATEGORIES.RELATIONSHIP]  ?? [],
      lossType:     listValues[LIST_CATEGORIES.LOSS_TYPE]     ?? [],
      lossLocation: listValues[LIST_CATEGORIES.LOSS_LOCATION] ?? [],
      itemType:     listValues[LIST_CATEGORIES.ITEM_TYPE]     ?? [],
      yesNo:        listValues[LIST_CATEGORIES.GENERIC_YES_NO]?? [],
      country:      countryOptions,
    };
    return optionMap[category]?.find(o => o.key === key)?.label ?? key;
  };

  useEffect(() => {
    fetchAllListValues(lovDataPageName).then(setListValues);
    fetchCountryList().then(opts => {
      setCountryOptions(opts);
      setFormData(prev => {
        const gbExists = opts.some(o => o.key === 'GB' && o.dialingCode);
        if (gbExists && prev.phoneDialingCode === 'GB') return prev;
        if (gbExists) return { ...prev, phoneDialingCode: 'GB' };
        const first = opts.find(o => o.dialingCode);
        return first ? { ...prev, phoneDialingCode: first.key } : prev;
      });
    });
  }, [lovDataPageName]);

  useEffect(() => {
    if (formData.lossLocationType === 'PHA') {
      setFormData(prev => ({
        ...prev,
        lossCountry: prev.policyCountry,
        lossAddressLine1: prev.policyAddressLine1,
        lossAddressLine2: prev.policyAddressLine2,
        lossCity: prev.policyCity,
        lossPostalCode: prev.policyPostalCode,
      }));
    }
  }, [formData.lossLocationType]);

  useLayoutEffect(() => {
    if (!turnstileSiteKeyTrimmed) {
      setTurnstileFormUnlocked(true);
      setIsTurnstileBooting(false);
      setTurnstileError('');
      return undefined;
    }

    setTurnstileFormUnlocked(false);
    setIsTurnstileBooting(true);
    setTurnstileError('');

    const host = turnstileHostRef.current;
    if (!host) {
      setIsTurnstileBooting(false);
      setTurnstileError('Security check could not start. Please refresh the page.');
      return undefined;
    }

    let cancelled = false;

    createTurnstileController(host, turnstileSiteKeyTrimmed, {
      onToken: () => {
        if (cancelled) return;
        setTurnstileError('');
        setTurnstileFormUnlocked(true);
      },
      onError: () => {
        if (cancelled) return;
        setTurnstileError('Security verification failed. Please refresh the page and try again.');
      }
    })
      .then(controller => {
        if (cancelled) { controller.destroy(); return; }
        turnstileControllerRef.current = controller;
        setIsTurnstileBooting(false);
      })
      .catch(error => {
        if (!cancelled) {
          setIsTurnstileBooting(false);
          setTurnstileError(error instanceof Error ? error.message : 'Security check failed to load.');
        }
      });

    return () => {
      cancelled = true;
      turnstileControllerRef.current?.destroy();
      turnstileControllerRef.current = null;
    };
  }, [turnstileSiteKeyTrimmed]);

  const handleFieldChange = (field: keyof ClaimFormData, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));
    setErrors(prev => ({ ...prev, [field]: '' }));
    setSubmitError('');
  };

  const handleFieldBlur = (field: keyof ClaimFormData) => {
    const fieldError = getClaimFieldValidationError(field, formData, l);
    setErrors(prev => ({ ...prev, [field]: fieldError }));
  };

 const handleFileUpload = async (files: File[]) => {
  // const MAX_FILE_SIZE = 10 * 1024 * 1024; // 10 MB

  setSubmitError('');

  const MAX_FILES = 10;

  const currentCount = formData.attachments.length;
  const remainingSlots = MAX_FILES - currentCount;

  // ✅ BLOCK if already max
  if (remainingSlots <= 0) {
    setSubmitError(l['MaxAttachmentsReached']);
    return;
  }

  // ✅ LIMIT files to allowed number
  const filesToProcess = files.slice(0, remainingSlots);

 let isMaxExceeded = false;

if (files.length > remainingSlots) {
  setSubmitError(l['MaxAttachmentsReached']);
  isMaxExceeded = true;
}
  const { valid, rejectedNames, errorMessage } = validateFileTypes(filesToProcess);

 if (rejectedNames.length > 0 && !isMaxExceeded) {
  setSubmitError(errorMessage);
}
  if (valid.length === 0) return;

  setIsUploading(true);

  const uploadResponses = await uploadAttachments(valid);

  const successfulUploads = uploadResponses
    .filter(r => r.success && r.attachment)
    .map(r => r.attachment!);

  const failedUploads = uploadResponses.filter(r => !r.success);

  if (successfulUploads.length > 0) {
    setFormData(prev => {
      const combined = [...prev.attachments, ...successfulUploads];

      const deduped = combined.filter(
        (a, i, all) => i === all.findIndex(x => x.id === a.id)
      );

      saveAttachmentIdsInSession(deduped.map(a => a.id));

      return { ...prev, attachments: deduped };
    });
  }

  if (failedUploads.length > 0) {
    setSubmitError(failedUploads[0]?.message || 'Some files failed to upload');
  }

  setIsUploading(false);
};


  const handleDeleteAttachment = (attachmentId: string) => {
    setFormData(prev => {
      const updated = prev.attachments.filter(a => a.id !== attachmentId);
      saveAttachmentIdsInSession(updated.map(a => a.id));
      return { ...prev, attachments: updated };
    });
  };

  const handleDocTypeChange = (attachmentId: string, docType: string) => {
    const docTypeLabel = (listValues[LIST_CATEGORIES.EVIDENCE_TYPE] ?? []).find(o => o.key === docType)?.label;
    setFormData(prev => ({
      ...prev,
      attachments: prev.attachments.map(a =>
        a.id === attachmentId
          ? { ...a, docType, docTypeLabel: docType !== 'OE' ? docTypeLabel : a.docTypeLabel, otherDocType: docType !== 'OE' ? '' : a.otherDocType }
          : a
      )
    }));
    setAttachmentErrors(prev => {
      const next = { ...prev };
      if (next[attachmentId]) {
        const { otherDocType } = next[attachmentId];
        next[attachmentId] = otherDocType ? { otherDocType } : {};
        if (!Object.keys(next[attachmentId]).length) delete next[attachmentId];
      }
      return next;
    });
  };

  const handleOtherDocTypeChange = (attachmentId: string, otherDocType: string) => {
    setFormData(prev => ({
      ...prev,
      attachments: prev.attachments.map(a => a.id === attachmentId ? { ...a, otherDocType } : a)
    }));
    if (otherDocType.trim()) {
      setAttachmentErrors(prev => {
        const next = { ...prev };
        if (next[attachmentId]) {
          delete next[attachmentId].otherDocType;
          if (!Object.keys(next[attachmentId]).length) delete next[attachmentId];
        }
        return next;
      });
    }
  };

  const handleNext = () => {
    const stepErrors = getStepValidationErrors(currentStep, formData, l);
    const mergedErrors = { ...errors, ...stepErrors };
    setErrors(mergedErrors);

    if (Object.values(mergedErrors).some(Boolean)) return;

    if (currentStep === 4) {
      const attErrors: Record<string, { docType?: string; otherDocType?: string }> = {};
      formData.attachments.forEach(a => {
        const e: { docType?: string; otherDocType?: string } = {};
        if (!a.docType) e.docType = l['ErrEvidenceTypeRequired'];
        if (a.docType === 'OE' && !a.otherDocType?.trim()) e.otherDocType = l['ErrEvidenceTypeSpecify'];
        if (Object.keys(e).length > 0) attErrors[a.id] = e;
      });
      if (Object.keys(attErrors).length > 0) {
        setAttachmentErrors(attErrors);
        return;
      }
      setAttachmentErrors({});
    }

    setErrors({});
    setSubmitError('')
    setCurrentStep(prev => (prev < 5 ? prev + 1 : prev));
  };

  const handleBack = () => {
    setErrors({});
    setSubmitError('');
    setCurrentStep(prev => (prev > 1 ? prev - 1 : prev));
  };

  const handleSubmit = async () => {
    const validationErrors = getClaimFormValidationErrors(formData, l);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setCurrentStep(1);
      return;
    }

    setIsSubmitting(true);
    setSubmitError('');

    let turnstileToken: string | undefined;
    if (turnstileSiteKeyTrimmed) {
      const controller = turnstileControllerRef.current;
      if (!controller) {
        setSubmitError('Security verification is not ready. Please refresh the page.');
        setIsSubmitting(false);
        return;
      }
      try {
        turnstileToken = await controller.refreshToken();
      } catch (error) {
        setSubmitError(error instanceof Error ? error.message : 'Security verification failed before submit.');
        setIsSubmitting(false);
        return;
      }
    }

    const response = await createClaimCase({ createClaimApiPath, caseTypeID, formData, turnstileToken });

    if (response.success) {
      const fullCaseId = response.ID || '';
      const attachResponse = await attachUploadedFilesToCase(fullCaseId, formData.attachments);
      if (!attachResponse.success) {
        setSubmitError(attachResponse.message || 'Case created but file attachment failed');
      }
      setCreatedCaseId(getCaseDisplayId(fullCaseId));
      setShowConfirmationView(true);
      setFormData(INITIAL_FORM_DATA);
      setErrors({});
      clearAttachmentIdsInSession();
    } else {
      setSubmitError(response.message || 'Failed to create claim case.');
    }

    setIsSubmitting(false);
  };

  const handleDiscardAndClose = () => {
    setFormData(INITIAL_FORM_DATA);
    setErrors({});
    setSubmitError('');
    setCurrentStep(1);
    clearAttachmentIdsInSession();
    closeCurrentBrowserContext();
  };

  const handleCancel = () => {
    create(() => <DiscardChangesModal onDiscard={handleDiscardAndClose}  l={l} />, {}, { dismissible: true });
  };

  const stepDefinitions: Array<{ label: string; name: string }> = [
    { label: l['Step 1'], name: l['Your Details'] },
    { label: l['Step 2'], name: l['What Happened'] },
    { label: l['Step 3'], name: l['Items Affected'] },
    { label: l['Step 4'], name: l['Evidence'] },
  ];

  const renderImageOverlay = () => (
    <div className='claim-form__image-overlay'>
      <h1 className='claim-form__image-title'>{l['HelpTextHeader']}</h1>
      <p className='claim-form__image-subtext'>{l['HelpDescription']}</p>
      <div className='claim-form__image-contact'>
        <div><strong>{l['HelpTelephoneKey']}</strong><p>{l['HelpTelephoneValue']}</p></div>
        <div><strong>{l['HelpEmailKey']}</strong><p>{l['HelpEmailValue']}</p></div>
        <div><strong>{l['HelpOverseasKey']}</strong><p>{l['HelpOverseasValue']}</p></div>
      </div>
      <div className='claim-form__image-hours'>
        <strong>{l['HelpSupportHoursKey']}</strong>
        <p>{l['HelpSupportHoursValue']}</p>
      </div>
    </div>
  );

  const renderStepNav = () => (
    <div className='claim-form__step-nav'>
      {stepDefinitions.map(({ label, name }, i) => {
        const step = i + 1;
        const isComplete = currentStep > step;
        const isCurrent = currentStep === step;
        let stateClass = 'claim-form__step-card--upcoming';
        if (isComplete) stateClass = 'claim-form__step-card--complete';
        else if (isCurrent) stateClass = 'claim-form__step-card--current';
        return (
          <div
            key={step}
            className={`claim-form__step-card ${stateClass}${isComplete ? ' claim-form__step-card--clickable' : ''}`}
            onClick={isComplete ? () => setCurrentStep(step) : undefined}
            role={isComplete ? 'button' : undefined}
            aria-label={isComplete ? `Go back to step ${step}: ${name}` : undefined}
          >
            <div className='claim-form__step-card-info'>
              <span className='claim-form__step-card-label'>{label}</span>
              <span className='claim-form__step-card-name'>{name}</span>
            </div>
            <div className='claim-form__step-card-icon'>{isComplete ? <Icon name='check' size='s' /> : ''}</div>
          </div>
        );
      })}
    </div>
  );

  const renderCurrentSection = () => {
    if (currentStep === 5) {
      return <ReviewSection formData={formData} setCurrentStep={setCurrentStep} onFieldChange={handleFieldChange} l={l} getLocalizedText={getLocalizedText} getLabel={getLabel} />;
    }

    if (Boolean(turnstileSiteKeyTrimmed) && !turnstileFormUnlocked) {
      return (
        <div className='claim-form__turnstile-gate' aria-live='polite'>
          <p className='claim-form__turnstile-gate-text'>
            Complete the security verification below to open the claim form.
          </p>
          {isTurnstileBooting && (
            <div className='claim-form__turnstile-booting'>
              <Progress />
              <span>Loading security check…</span>
            </div>
          )}
          {turnstileError && (
            <div className='claim-form__feedback claim-form__feedback--error' role='alert'>
              {turnstileError}
            </div>
          )}
        </div>
      );
    }

    switch (currentStep) {
      case 1:
        return (
          <YourDetailsSection
            formData={formData}
            errors={errors}
            onFieldChange={(f, v) => handleFieldChange(f, v as string)}
            onFieldBlur={handleFieldBlur}
            productOptions={listValues[LIST_CATEGORIES.PRODUCT] ?? []}
            relationshipOptions={listValues[LIST_CATEGORIES.RELATIONSHIP] ?? []}
            countryOptions={countryOptions}
            l={l}
          />
        );
      case 2:
        return (
          <WhatHappenedSection
            formData={formData}
            errors={errors}
            onFieldChange={(f, v) => handleFieldChange(f, v)}
            onFieldBlur={handleFieldBlur}
            lossTypeOptions={listValues[LIST_CATEGORIES.LOSS_TYPE] ?? []}
            lossLocationOptions={listValues[LIST_CATEGORIES.LOSS_LOCATION] ?? []}
            theftReportedOptions={listValues[LIST_CATEGORIES.GENERIC_YES_NO] ?? []}
            countryOptions={countryOptions}
            l={l}
          />
        );
      case 3:
        return (
          <ItemsAffectedSection
            formData={formData}
            errors={errors}
            onFieldChange={(f, v) => handleFieldChange(f, v)}
            onFieldBlur={handleFieldBlur}
            itemTypeOptions={listValues[LIST_CATEGORIES.ITEM_TYPE] ?? []}
            l={l}
          />
        );
      case 4:
        return (
          <SupportingEvidenceSection
            formData={formData}
            errors={errors}
            isUploading={isUploading}
            onFileUpload={handleFileUpload}
            onDeleteAttachment={handleDeleteAttachment}
            onDocTypeChange={handleDocTypeChange}
            onOtherDocTypeChange={handleOtherDocTypeChange}
            evidenceTypeOptions={listValues[LIST_CATEGORIES.EVIDENCE_TYPE] ?? []}
            attachmentErrors={attachmentErrors}
            l={l}
          />
        );
      default:
        return null;
    }
  };

  const renderActions = () => {
    const isReview = currentStep === 5;
    const isFirst = currentStep === 1;

    const leftButton = (
      <div className='claim-form__actions-left'>
        <button
          type='button'
          className='claim-form__button claim-form__button--secondary'
          onClick={handleCancel}
          disabled={isSubmitting || isUploading}
        >
          {l['Cancel']}
        </button>
        {!isFirst && (
          <button
            type='button'
            className='claim-form__button claim-form__button--secondary'
            onClick={handleBack}
            disabled={isSubmitting}
          >
            {l['Back']}
          </button>
        )}
      </div>
    );

    const rightButton = isReview ? (
      <button
        type='button'
        className='claim-form__button claim-form__button--primary'
        onClick={handleSubmit}
        disabled={isSubmitting || isUploading || (Boolean(turnstileSiteKeyTrimmed) && !turnstileFormUnlocked) || !(formData.fraudPreventionNotice && formData.claimAccuracyConfirmation)}
      >
        {isSubmitting ? (
          <span className='claim-form__processing-content'>
            <Progress />
            <span>{l['Processing...']}</span>
          </span>
        ) : l['Submit']}
      </button>
    ) : (
      <button
        type='button'
        className='claim-form__button claim-form__button--primary'
        onClick={handleNext}
        disabled={isUploading || (Boolean(turnstileSiteKeyTrimmed) && !turnstileFormUnlocked && currentStep === 1)}
      >
        {l['Continue']}
      </button>
    );

    return (
      <div className='claim-form__actions'>
        {leftButton}
        {rightButton}
      </div>
    );
  };

  const portalMaskOverlay = isMasked && (
    <div className='claim-form__portal-mask' aria-hidden='true'>
      <Progress />
    </div>
  );

  const imageStyle = imageSrc ? { backgroundImage: `url(${imageSrc})` } : undefined;

  if (showConfirmationView) {
    return (
      <>
        {portalMaskOverlay}
        <ClaimFormGlobalStyles />
        <StyledTmhccDxLibraryClaimFormWrapper>
          <div className='claim-form-page'>
          <div className='claim-form-page__image' style={imageStyle}>

  {renderImageOverlay()}

</div>
            <div className='claim-form-page__panel'>
              <div className='claim-form'>
  <ClaimConfirmationView
  caseId={createdCaseId}
  confirmationDataPageName={confirmationDataPageName}
  onClose={() => {
    setShowConfirmationView(false);
    setCurrentStep(1);
  }}
  l={l}
/>

              </div>
            </div>
          </div>
        </StyledTmhccDxLibraryClaimFormWrapper>
      </>
    );
  }

  return (
    <>
      {portalMaskOverlay}
      <ClaimFormGlobalStyles />
      <StyledTmhccDxLibraryClaimFormWrapper>
        <div className='claim-form-page'>
                    <div className='claim-form-page__image' style={imageStyle}>

  {renderImageOverlay()}

</div>
          <div className='claim-form-page__panel'>
            {renderStepNav()}
            <div className='claim-form'>
              {Boolean(turnstileSiteKeyTrimmed) && (
                <div
                  ref={turnstileHostRef}
                  className={
                    turnstileFormUnlocked
                      ? 'claim-form__turnstile-host claim-form__turnstile-host--hidden'
                      : 'claim-form__turnstile-host'
                  }
                />
              )}
              {renderCurrentSection()}
              {submitError && (
                <div className='claim-form__feedback claim-form__feedback--error' role='alert'>
                  {submitError}
                </div>
              )}
            </div>
            <div className='claim-form__footer'>
              {renderActions()}
            </div>
          </div>
        </div>
      </StyledTmhccDxLibraryClaimFormWrapper>
    </>
  );
}

export default withConfiguration(TmhccDxLibraryClaimForm);
