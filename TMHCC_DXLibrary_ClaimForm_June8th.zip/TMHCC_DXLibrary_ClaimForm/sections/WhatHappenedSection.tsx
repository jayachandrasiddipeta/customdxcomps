import { useState } from 'react';
import type { ClaimFormData, ClaimFormErrors } from '../types';
import InfoIcon from './InfoIcon';
import type { ListOption } from '../utils/listValuesUtils';
import type { LocalizationMap } from '../utils/useLocalization';
// import { getPostcodeLabelKey } from '../utils/countryConfig';
interface WhatHappenedSectionProps {
  formData: ClaimFormData;
  errors: ClaimFormErrors;
  onFieldChange: (field: keyof ClaimFormData, value: string) => void;
  onFieldBlur: (field: keyof ClaimFormData) => void;
  lossTypeOptions: ListOption[];
  lossLocationOptions: ListOption[];
  theftReportedOptions: ListOption[];
  countryOptions: ListOption[];
  l: LocalizationMap;
}

function WhatHappenedSection({
  formData,
  errors,
  onFieldChange,
  onFieldBlur,
  lossTypeOptions,
  lossLocationOptions,
  theftReportedOptions,
  countryOptions,
  l
}: WhatHappenedSectionProps) {
  const [showInfo, setShowInfo] = useState(false);
const postcodeLabelKey = `${formData.lossCountry}_PCLabel`;

const postcodeLabel =
  l[postcodeLabelKey as keyof typeof l] || l['Postal Code'];

const postcodePlaceholder = `Enter ${postcodeLabel.toLowerCase()}`;
  const sortedTheftOptions = [...theftReportedOptions].sort((a) =>
    a.key === 'Yes' ? -1 : 1
  );

  const sortedLocationOptions = [...lossLocationOptions].sort((a) =>
    a.key === 'PHA' ? -1 : 1
  );
  return (
    <section className="claim-form__section">
      <h3 className="claim-form__section-title claim-form__title-with-icon">
        <span className="claim-form__section-index">2</span>
        {l['What Happened']}
        <button
          type="button"
          className="claim-form__info-icon"
          onClick={() => setShowInfo(prev => !prev)}
          aria-label="Show info"
        >
          <InfoIcon />
        </button>
      </h3>
      {/* ✅ INFO BOX */}
     {showInfo && (
  <div className="claim-form__info-box">

    {/* ✅ LEFT SIDE */}
    <div className="claim-form__info-left">

      {/* ✅ ICON */}
      <div className="claim-form__info-box-icon">
        <InfoIcon />
      </div>

      {/* ✅ TEXT */}
      <div className="claim-form__info-content">
        {l['WhatHappenedInstructions']}
      </div>

    </div>

    {/* ✅ CLOSE BUTTON (RIGHT) */}
    <button
      type="button"
      className="claim-form__info-close"
      onClick={() => setShowInfo(false)}
    >
      ×
    </button>

  </div>
)}
      <div className="claim-form__grid">

        {/* ✅ CARD 1 */}
        <div className="claim-form__group claim-form__field--full">
          <div className="claim-form__grid">

            {/* Date */}
            <label className="claim-form__field">
              <span>{l['Date of Loss']} <span className="claim-form__required-star">*</span></span>
              <input
                type="date"
                value={formData.dateOfLoss}
                onChange={(e) => onFieldChange('dateOfLoss', e.target.value)}
                onBlur={() => onFieldBlur('dateOfLoss')}
              />
              {errors.dateOfLoss && (
                <small className="claim-form__error">{errors.dateOfLoss}</small>
              )}
            </label>

            {/* Loss Type */}
            <label className="claim-form__field">
              <span>{l['Loss Type']} <span className="claim-form__required-star">*</span></span>
              <select
                value={formData.lossType}
                onChange={(e) => onFieldChange('lossType', e.target.value)}
                onBlur={() => onFieldBlur('lossType')}
              >
                <option value=''>{l['Select loss type']}</option>
                {lossTypeOptions.map(opt => (
                  <option key={opt.key} value={opt.key}>{opt.label}</option>
                ))}
              </select>
              {errors.lossType && (
                <small className="claim-form__error">{errors.lossType}</small>
              )}
            </label>

            {/* Other */}
            {formData.lossType === 'OTH' && (
              <label className="claim-form__field claim-form__field--full">
                <span>{l['OtherLossType']} <span className="claim-form__required-star">*</span></span>
                <input
                  value={formData.otherLossType || ''}
                  placeholder={l['OtherLossTypePH']}
                  onChange={(e) => onFieldChange('otherLossType', e.target.value)}
                  onBlur={() => onFieldBlur('otherLossType' as keyof ClaimFormData)}
                />
                {errors.otherLossType && (
                  <small className="claim-form__error">{errors.otherLossType}</small>
                )}
              </label>
            )}

            {/* Theft */}
            {formData.lossType === 'TH' && (
              <>
                <h4 className="claim-form__section-title claim-form__section-title--secondary claim-form__field--full">
                  {l['Theft Details']}
                </h4>

                <label className="claim-form__field">
                  <span>{l['ReportedToPolice']} <span className="claim-form__required-star">*</span></span>
                  <select
                    value={formData.theftReported || ''}
                    onChange={(e) => {
                      const value = e.target.value;
                      onFieldChange('theftReported', value);
                      if (value === 'No') {
                        onFieldChange('crimeReferenceNumber', '');
                      }
                    }}
                    onBlur={() => onFieldBlur('theftReported' as keyof ClaimFormData)}
                  >
                    <option value=''>{l['SelectOptionPH']}</option>
                    {sortedTheftOptions.map(opt => (
                      <option key={opt.key} value={opt.key}>{opt.label}</option>
                    ))}
                  </select>
                  {errors.theftReported && (
                    <small className="claim-form__error">{errors.theftReported}</small>
                  )}
                </label>

                {formData.theftReported === 'Yes' && (
                  <label className="claim-form__field">
                    <span>{l['Crime Reference Number']} <span className="claim-form__required-star">*</span></span>
                    <input
                      value={formData.crimeReferenceNumber || ''}
                      placeholder={l['CrimeReferenceNumberHT']}
                      onChange={(e) => onFieldChange('crimeReferenceNumber', e.target.value)}
                      onBlur={() => onFieldBlur('crimeReferenceNumber' as keyof ClaimFormData)}
                    />
                    {errors.crimeReferenceNumber && (
                      <small className="claim-form__error">{errors.crimeReferenceNumber}</small>
                    )}
                  </label>
                )}
              </>
            )}

            {/* Description */}
            <label className="claim-form__field claim-form__field--full">
              <span>{l['Description']} <span className="claim-form__required-star">*</span></span>
              <small className='claim-form_hint'>{l['HintDescriptionLength']}</small>
              <textarea
                rows={4}
                placeholder={l['DescriptionPlaceholder']}
                value={formData.description}
                onChange={(e) => onFieldChange('description', e.target.value)}
                onBlur={() => onFieldBlur('description')}
                maxLength={l['DescriptionMaxLength']}
              />
              <div className="claim-form_field-footer">
                <span>{errors.description && <small className="claim-form_error">{errors.description}</small>}</span>
                <small className={`claim-form_char-counter${formData.description.length>=950 ? ' claim-form_char-counter-warn' : ''}`}>
                  {formData.description.length} / {l['DescriptionMaxLength']}
                </small>
              </div>
            </label>

          </div>
        </div>

        {/* ✅ CARD 2 */}
        <div className="claim-form__group claim-form__group--card claim-form__field--full">

          <h4 className="claim-form__card-title">
            {l['Where did this happen']}
          </h4>

          {/* Radios */}
          <div className="claim-form__radio-group">
            {sortedLocationOptions.map(opt => (
              <label key={opt.key} className="claim-form__radio">
                <input
                  type="radio"
                  name="lossLocationType"
                  value={opt.key}
                  checked={formData.lossLocationType === opt.key}
             onChange={() => {
  const value = opt.key;

  onFieldChange('lossLocationType', value);

  // ✅ CLEAR address fields for BOTH cases
  if (value === 'DL' || value === 'PHA') {
    onFieldChange('lossCountry', '');
    onFieldChange('lossAddressLine1', '');
    onFieldChange('lossAddressLine2', '');
    onFieldChange('lossCity', '');
    onFieldChange('lossPostalCode', '');
  }

  onFieldBlur('lossLocationType');
}}
                />
                <span>{opt.label}</span>
              </label>
            ))}
          </div>

          {errors.lossLocationType && (
            <small className="claim-form__error">{errors.lossLocationType}</small>
          )}

          {/* Address — shown when "Different location" (key: DL) is selected */}
          {formData.lossLocationType === 'DL' && (
            <>
         
            <div className="claim-form__divider claim-form__field--full" />
            <div className="claim-form__grid">

              <label className="claim-form__field claim-form__field--full">
                <span>{l['Country']} <span className="claim-form__required-star">*</span></span>
                <select
                  value={formData.lossCountry}
         onChange={(e) => {
  const value = e.target.value;

  // ✅ update country
  onFieldChange('lossCountry', value);

  // ✅ clear dependent values
  onFieldChange('lossPostalCode', '');
  onFieldChange('lossCity', '');
  onFieldChange('lossAddressLine1', '');
}}

                  onBlur={() => onFieldBlur('lossCountry')}
                >
                  <option value=''>{l['CountryPH']}</option>
                  {countryOptions.map(opt => (
                    <option key={opt.key} value={opt.key}>{opt.label}</option>
                  ))}
                </select>
                {errors.lossCountry && (
                  <small className="claim-form__error">{errors.lossCountry}</small>
                )}
              </label>

              <label className="claim-form__field claim-form__field--full">
                <span>{l['Address Line 1']} <span className="claim-form__required-star">*</span></span>
                <input
                  value={formData.lossAddressLine1}
                  placeholder={l['StreetAddress1PH']}
                  onChange={(e) => onFieldChange('lossAddressLine1', e.target.value)}
                  onBlur={() => onFieldBlur('lossAddressLine1')}
                />
                {errors.lossAddressLine1 && (
                  <small className="claim-form__error">{errors.lossAddressLine1}</small>
                )}
              </label>

              <label className="claim-form__field claim-form__field--full">
                <span>{l['Address Line 2']}</span>
                <input
                  value={formData.lossAddressLine2}
                  placeholder={l['StreetAddress2PH']}
                  onChange={(e) => onFieldChange('lossAddressLine2', e.target.value)}
                />
              </label>

              <label className="claim-form__field">
                <span>{l['CityTown']} <span className="claim-form__required-star">*</span></span>
                <input
                  value={formData.lossCity}
                  placeholder={l['CityTownPH']}
                  onChange={(e) => onFieldChange('lossCity', e.target.value)}
                  onBlur={() => onFieldBlur('lossCity')}
                />
                {errors.lossCity && (
                  <small className="claim-form__error">{errors.lossCity}</small>
                )}
              </label>

              <label className="claim-form__field">
             <span>
 {postcodeLabel}
  <span className="claim-form__required-star">*</span>
</span>
                <input
                  inputMode='text'
                  value={formData.lossPostalCode}
                  placeholder={postcodePlaceholder}
                  onChange={(e) => onFieldChange('lossPostalCode', e.target.value.replace(/[^a-zA-Z0-9 ]/g, ''))}
                  onBlur={() => onFieldBlur('lossPostalCode')}
                />
                {errors.lossPostalCode && (
                  <small className="claim-form__error">{errors.lossPostalCode}</small>
                )}
              </label>

            </div>
            </>
          )}

        </div>

      </div>
    </section>
  );
}

export default WhatHappenedSection;