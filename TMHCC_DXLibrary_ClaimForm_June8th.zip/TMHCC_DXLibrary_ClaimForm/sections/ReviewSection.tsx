import { useState } from 'react';
import { Icon } from '@pega/cosmos-react-core';
import type { ClaimFormData, UploadedAttachment } from '../types';
import type { LocalizationMap } from '../utils/useLocalization';

interface ReviewSectionProps {
  formData: ClaimFormData;
  l: LocalizationMap;
  getLocalizedText: (key: string, args?: any[]) => string;
  getLabel: (category: string, key: string) => string;
  onFieldChange: (field: keyof ClaimFormData, value: string | boolean) => void;
}

const formatAddress = (...parts: (string | undefined)[]): string =>
  parts.filter(p => p?.trim()).join(', ') || '—';

function ReviewField({ label, value }: { label: string; value: string }) {
  return (
    <div className='review-field'>
      <span className='review-field__label'>{label}</span>
      <span className='review-field__value'>{value || '—'}</span>
    </div>
  );
}

function ReviewBlock({
  title,
  stepNum,
  children,
  onEdit
}: {
  title: string;
  stepNum: number;
  children: React.ReactNode;
  onEdit: () => void;
}) {
  const [isOpen, setIsOpen] = useState(false);

  return (
    <div className='review-card'>
      <div
        className='review-card__header'
        onClick={() => setIsOpen(prev => !prev)}
        role='button'
        aria-expanded={isOpen}
      >
        <div className='review-card__title'>
          <span className='review-card__index'>{stepNum}</span>
          <span className='review-card__heading'>{title}</span>
        </div>
        <div className='review-card__icons'>
          <button
            type='button'
            className='review-card__icon-btn'
            aria-label='Edit'
            onClick={e => { e.stopPropagation(); onEdit(); }}
          >
            <Icon name='pencil' />
          </button>
          <button
            type='button'
            className='review-card__icon-btn'
            aria-label={isOpen ? 'Collapse' : 'Expand'}
            onClick={e => { e.stopPropagation(); setIsOpen(prev => !prev); }}
          >
            <Icon name={isOpen ? 'caret-up' : 'caret-down'} />
          </button>
        </div>
      </div>

      {isOpen && (
        <div className='review-card__content'>
          <div className='review-grid'>{children}</div>
        </div>
      )}
    </div>
  );
}

function ReviewSection({
  formData,
  setCurrentStep,
  onFieldChange,
  l,
  getLocalizedText,
  getLabel
}: ReviewSectionProps & { setCurrentStep: (step: number) => void }) {

  const policyAddress = formatAddress(
    formData.policyAddressLine1,
    formData.policyAddressLine2,
    formData.policyCity,
    formData.policyPostalCode,
    getLabel('country', formData.policyCountry)
  );

  const riskAddress = formData.lossLocationType === 'PHA'
    ? policyAddress
    : formatAddress(
        formData.lossAddressLine1,
        formData.lossAddressLine2,
        formData.lossCity,
        formData.lossPostalCode,
        getLabel('country', formData.lossCountry)
      );

  return (
    <div>
      <ReviewBlock title={l['Your Details']} stepNum={1} onEdit={() => setCurrentStep(1)}>
        <ReviewField label={l['First Name']} value={formData.firstName} />
        <ReviewField label='Last Name' value={formData.lastName} />
        <ReviewField label={l['Email Address']} value={formData.email} />
        <ReviewField label={l['Phone Number']} value={formData.phoneNumber} />
        <ReviewField label={l['Policy Number']} value={formData.policyNumber} />
        <ReviewField label={l['Relationship to Policyholder']} value={getLabel('relationship', formData.relationship)} />
        <ReviewField label={l['Service Number']} value={formData.serviceNumber} />
        <ReviewField label='Scheme / Product' value={getLabel('product', formData.schemeOrProduct)} />
        <ReviewField label='Address' value={policyAddress} />
      </ReviewBlock>

      <ReviewBlock title={l['What Happened']} stepNum={2} onEdit={() => setCurrentStep(2)}>
        <ReviewField label={l['Date of Loss']} value={formData.dateOfLoss} />
        <ReviewField label={l['Loss Type']} value={getLabel('lossType', formData.lossType)} />
        <div className='review-field'>
          <span className='review-field__label'>{l['Description']}</span>
          <span className='review-field__value'>{formData.description || '—'}</span>
        </div>
        <ReviewField label='Risk Address' value={riskAddress} />
      </ReviewBlock>

      <ReviewBlock title={l['Items Affected']} stepNum={3} onEdit={() => setCurrentStep(3)}>
        <ReviewField label={l['Item Type']} value={getLabel('itemType', formData.itemType)} />
        <ReviewField label={l['Item Description']} value={formData.itemDescription} />
        <ReviewField label={`${l['Purchase Price']} (£)`} value={formData.purchasePrice} />
        <ReviewField label={`${l['Claimed Amount']} (£)`} value={formData.claimedAmount} />
      </ReviewBlock>

      <ReviewBlock title='Supporting Evidence' stepNum={4} onEdit={() => setCurrentStep(4)}>
        <div className='review-field'>
          <span className='review-field__label'>
            {l['Files Uploaded']}: <strong>{getLocalizedText('FilesNumber', [formData.attachments.length])}</strong>
          </span>
          {formData.attachments.length > 0 ? (
            <ul className='review-field__file-list'>
              {formData.attachments.map((a: UploadedAttachment) => {
                const typeLabel = a.docType === 'OE'
                  ? (a.otherDocType?.trim() || 'Other')
                  : (a.docTypeLabel || a.docType);
                return (
                  <li key={a.id}>
                    {a.name}{typeLabel ? ` (${typeLabel})` : ''}
                  </li>
                );
              })}
            </ul>
          ) : (
            <span className='review-field__value'>{l['No files uploaded']}</span>
          )}
        </div>
      </ReviewBlock>

      <div className='review-declaration'>
        <h3 className='review-declaration__title'>{l['Declaration']}</h3>

        <div className='review-declaration__item'>
          <label className='review-declaration__checkbox'>
            <input
              type='checkbox'
              checked={formData.fraudPreventionNotice}
              onChange={e => onFieldChange('fraudPreventionNotice', e.target.checked)}
            />
            <span className='review-declaration__heading'>{l['Fraud prevention notice']}</span>
          </label>
          <p className='review-declaration__text'>{l['FPNText']}</p>
        </div>

        <div className='review-declaration__item'>
          <label className='review-declaration__checkbox'>
            <input
              type='checkbox'
              checked={formData.claimAccuracyConfirmation}
              onChange={e => onFieldChange('claimAccuracyConfirmation', e.target.checked)}
            />
            <span className='review-declaration__heading'>{l['Claim accuracy confirmation']}</span>
          </label>
          <p className='review-declaration__text'>{l['CACText']}</p>
        </div>
      </div>
    </div>
  );
}

export default ReviewSection;
