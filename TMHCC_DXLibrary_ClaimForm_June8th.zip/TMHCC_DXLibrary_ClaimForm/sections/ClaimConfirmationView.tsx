import { useEffect, useState } from 'react';
import { LocalizationMap } from '../utils/useLocalization';

interface ClaimConfirmationViewProps {
  caseId: string;
  confirmationDataPageName: string;
  onClose: () => void;
  l:LocalizationMap
}

function ClaimConfirmationView({ caseId, confirmationDataPageName, onClose,l }: ClaimConfirmationViewProps) {
  const referenceId = caseId || 'Pending';
  const [confirmationHtml, setConfirmationHtml] = useState('');
  const [loading, setLoading] = useState(true);
  const context = "";

  const parameters = {
    pyID: caseId,
  };
  const options = {
    invalidateCache: true,
  };

  useEffect(() => {
    (async () => {
      try {
        const response = await (window as any).PCore.getDataPageUtils().getPageDataAsync(
          confirmationDataPageName,
          context,
          parameters,
          options
        );
        setConfirmationHtml(response?.pyConfirmationNote ?? '');
      } catch {
        // fall through — empty content
      } finally {
        setLoading(false);
      }
    })();
  }, [confirmationDataPageName]);

  const handleSaveReference = () => {
    const content = `Claim Reference:${referenceId}`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `Claim-Reference-${referenceId}.txt`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    window.URL.revokeObjectURL(url);
  };

  return (
    <div className='claim-confirmation-shell'>
      <div className='claim-confirmation'>

        {!loading && confirmationHtml && (
          <div
            className='claim-confirmation__rich-text'
            dangerouslySetInnerHTML={{ __html: confirmationHtml }}
          />
        )}

        <div className='claim-confirmation__actions'>
          <button
            type='button'
            className='claim-confirmation__button claim-confirmation__button--outline'
            onClick={handleSaveReference}
          >
            Save Claim Reference
          </button>
          
<button
  type='button'
  className='claim-confirmation__button claim-confirmation__button--primary'
  onClick={() => {
    const url = l['ReturnHomePageLink'];

    if (url) {
      window.location.href = url; // ✅ redirect
    } else {
      onClose(); // fallback
    }
  }}
>
  Return to Home Page
</button>

        </div>

      </div>
    </div>
  );
}

export default ClaimConfirmationView;
