import { Modal, useModalContext } from '@pega/cosmos-react-core';
import { LocalizationMap } from '../utils/useLocalization';

interface DiscardChangesModalProps {
  onDiscard: () => void;
  l: LocalizationMap;
}


function DiscardChangesModal({ onDiscard,l }: DiscardChangesModalProps) {
  const { dismiss } = useModalContext();

  const handleDiscard = () => {
  dismiss();
  onDiscard();

  const url = l['ReturnHomePageLink'];

  if (url) {
    window.location.href = url; // ✅ redirect to homepage
  }
};

  return (
    <Modal heading='Cancel claim form?'>
      <div className='claim-form__discard-modal'>
        <p className='claim-form__discard-modal-text'>
          Are you sure you want to cancel the form? If you do, all progress will be lost and you will have to start again.
        </p>
        <div className='claim-form__discard-modal-actions'>
          <button
            type='button'
            className='claim-form__button claim-form__button--secondary'
            onClick={() => dismiss()}
          >
            No, Continue
          </button>
          <button
            type='button'
            className='claim-form__button claim-form__button--cancel'
            onClick={handleDiscard}
          >
            Yes, Cancel Form
          </button>
        </div>
      </div>
    </Modal>
  );
}

export default DiscardChangesModal;
