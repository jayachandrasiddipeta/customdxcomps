// export interface ListOption {
//   key: string;
//   label: string;
// }

// export interface CountryOption extends ListOption {
//   dialingCode: string;
// }

// export const LIST_CATEGORIES = {
//   PRODUCT: 'Product',
//   RELATIONSHIP: 'Relationship',
//   LOSS_TYPE: 'LossType',
//   LOSS_LOCATION: 'LossLocation',
//   GENERIC_YES_NO: 'GenericYesNo',
//   ITEM_TYPE: 'ItemType',
//   EVIDENCE_TYPE: 'EvidenceType'
// } as const;

// export async function fetchListValues(category: string, dataPageName: string): Promise<ListOption[]> {
//   try {
//     const context = '';
//     const parameters = { Category: category };
//     const paging = {
//       pageNumber: 1,
//       pageSize: 500,
//     };
//     const listValuesQuery = {
//       select: [
//         { field: "pyKeyString" },
//         { field: "pyActualValue" },
//         { field: "pyCategory" },
//       ],
//       useExtendedTimeout: false,
//     };
//     const response = await (
//       window as any
//     ).PCore.getDataPageUtils().getDataAsync(
//       dataPageName,
//       context,
//       parameters,
//       paging,
//       listValuesQuery,
//     );
//     return (response?.data ?? []).map((item: Record<string, string>) => ({
//       key: item.pyKeyString ?? '',
//       label: item.pyActualValue ?? ''
//     }));
//   } catch {
//     return [];
//   }
// }

// export async function fetchAllListValues(dataPageName: string): Promise<Record<string, ListOption[]>> {
//   const entries = await Promise.all(
//     Object.values(LIST_CATEGORIES).map(async cat => ({
//       cat,
//       opts: await fetchListValues(cat, dataPageName)
//     }))
//   );
//   return Object.fromEntries(entries.map(({ cat, opts }) => [cat, opts]));
// }

// export async function fetchCountryList(): Promise<CountryOption[]> {
//   try {
//     const context = '';
//     const dataPageName = 'D_CountryList';
//     const parameters = {};
//     const paging = {
//       pageNumber: 1,
//       pageSize: 500,
//     };
//     const countryListQuery = {
//       select: [
//         { field: "Name" },
//         { field: "ISOCode" },
//         { field: "DialingCode" }
//       ],
//       useExtendedTimeout: false,
//     };
//     const response = await (
//       window as any
//     ).PCore.getDataPageUtils().getDataAsync(
//       dataPageName,
//       context,
//       parameters,
//       paging,
//       countryListQuery,
//     );
//     return (response?.data ?? []).map((item: Record<string, string>) => ({
//       key: item.ISOCode ?? '',
//       label: item.Name ?? '',
//       dialingCode: item.DialingCode ?? ''
//     }));
//   } catch {
//     return [];
//   }
// }

export interface ListOption {
  key: string;
  label: string;
}

export interface CountryOption extends ListOption {
  dialingCode: string;
}

export const LIST_CATEGORIES = {
  PRODUCT: 'Product',
  RELATIONSHIP: 'Relationship',
  LOSS_TYPE: 'LossType',
  LOSS_LOCATION: 'LossLocation',
  GENERIC_YES_NO: 'GenericYesNo',
  ITEM_TYPE: 'ItemType',
  EVIDENCE_TYPE: 'EvidenceType'
} as const;


export async function fetchAllListValues(dataPageName: string): Promise<Record<string, ListOption[]>> {
    try {
    const context = '';
    const parameters = {};
    const paging = {
      pageNumber: 1,
      pageSize: 500,
    };
    const listValuesQuery = {
      select: [
        { field: "pyKeyString" },
        { field: "pyActualValue" },
        { field: "pyCategory" },
        { field: "pyRowNumber"}
      ],
      useExtendedTimeout: false,
    };
    const response = await (window as any).PCore.getDataPageUtils().getDataAsync(
      dataPageName,
      context,
      parameters,
      paging,
      listValuesQuery,
    );

    const grouped: Record<string, ListOption[]> = {};
    const items = (response?.data??[]) as Record<string, string>[];
    items.sort((a,b) => Number(a.pyRowNumber ?? 0) - Number(b.pyRowNumber ?? 0));
    for(const item of items){
      const cat = item.pyCategory ?? ''
      if(!grouped[cat]) grouped[cat] = [];
      grouped[cat].push({key: item.pyKeyString ?? '', label: item.pyActualValue ?? ''});
    }
    return grouped;
  }
  catch{
    return {};
  }
}

export async function fetchCountryList(): Promise<CountryOption[]> {
  try {
    const context = '';
    const dataPageName = 'D_CountryList';
    const parameters = {};
    const paging = {
      pageNumber: 1,
      pageSize: 500,
    };
    const countryListQuery = {
      select: [
        { field: "Name" },
        { field: "ISOCode" },
        { field: "DialingCode" }
      ],
      useExtendedTimeout: false,
    };
    const response = await (
      window as any
    ).PCore.getDataPageUtils().getDataAsync(
      dataPageName,
      context,
      parameters,
      paging,
      countryListQuery,
    );
    return (response?.data ?? []).map((item: Record<string, string>) => ({
      key: item.ISOCode ?? '',
      label: item.Name ?? '',
      dialingCode: item.DialingCode ?? ''
    }));
  } catch {
    return [];
  }
}
