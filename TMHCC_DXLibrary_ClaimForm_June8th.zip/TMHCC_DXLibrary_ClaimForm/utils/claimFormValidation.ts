import type { ClaimFormData, ClaimFormErrors } from '../types';
import type { LocalizationMap } from './useLocalization';

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_PATTERN = /^\d{11}$/;
const POSTAL_CODE_PATTERN = /^[a-zA-Z0-9 ]+$/;

type FieldValidator = (value: string, formData: ClaimFormData) => string;

const buildValidators = (l: LocalizationMap): Partial<Record<keyof ClaimFormData, FieldValidator>> => {
  const req = (key: keyof LocalizationMap) => (v: string) => v ? '' : l[key];

  const notFuture = (reqKey: keyof LocalizationMap, futureKey: keyof LocalizationMap) => (v: string) => {
    if (!v) return l[reqKey];
    const today = new Date().toISOString().slice(0, 10);
    return v > today ? l[futureKey] : '';
  };

const postalCode = (country: string) => (v: string) => {
  const labelKey = `${country}_PCLabel`;
  const label = l[labelKey as keyof typeof l] || l['Postal Code'];

  const errKey = `${country}_PCErrMsg`;
  const errorMessage =
    l[errKey as keyof typeof l] || l['PCErrMsg'];

  if (!v) return errorMessage;

  return POSTAL_CODE_PATTERN.test(v)
    ? ''
    : `${label} is invalid`; // ✅ unchanged
};


const minMax = (
  reqKey : keyof LocalizationMap,
  minKey : keyof LocalizationMap,
  maxKey : keyof LocalizationMap,
  min: number,
  max: number
) => (v: string) =>{
  if(!v) return l[reqKey];
  if(v.length < min) return l[minKey];
  if(v.length > max) return l[maxKey];
  return '';
};


  return {
    firstName:          minMax('ErrFirstNameRequired', 'ErrFNTooShort', 'ErrFNTooLong', l['NameMinLength'], l['NameMaxLength']),
    lastName:           minMax('ErrFirstNameRequired', 'ErrFNTooShort', 'ErrFNTooLong', l['NameMinLength'], l['NameMaxLength']),
    policyNumber: v => {
      if (!v) return l['ErrPolicyNumberRequired'];
      return new RegExp(l['PolicyNumberPattern']).test(v) ? '' : l['PolicyNumberFormatError'];
    },
  serviceNumber: () => '',
    relationship:       req('ErrRelationshipRequired'),
    dateOfLoss:         notFuture('ErrDateOfLossRequired', 'ErrDateOfLossFuture'),
    lossType:           req('ErrLossTypeRequired'),
    causeOfLoss:        req('ErrCauseOfLossRequired'),
    lossCountry:        req('ErrCountryRequired'),
    lossAddressLine1:   req('ErrAddressLine1Required'),
    lossCity:           req('ErrCityRequired'),
    lossPostalCode:     (v, fd) => postalCode(fd.lossCountry)(v),
    description:        minMax('ErrDescriptionRequired', 'ErrDescriptionTooShort', 'ErrDescriptionTooLong', l['DescriptionMinLength'], l['DescriptionMaxLength']),
    itemType:           req('ErrItemTypeRequired'),
    purchasePrice:      req('ErrPurchasePriceRequired'),
    policyCountry:      req('ErrCountryRequired'),
    policyAddressLine1: req('ErrAddressLine1Required'),
    policyCity:         req('ErrCityRequired'),
    policyPostalCode:   (v, fd) => postalCode(fd.policyCountry)(v),
    claimedAmount:      req('ErrClaimedAmountRequired'),
    itemDescription:    minMax('ErrItemDescriptionRequired', 'ErrItemDescriptionTooShort', 'ErrItemDescriptionTooLong', l['ItemDescriptionMinLength'], l['ItemDescriptionMaxLength']),
    schemeOrProduct:    req('ErrProductRequired'),
    datePurchased:      notFuture('ErrDatePurchasedRequired', 'ErrDatePurchasedFuture'),

 theftReported: (v, fd) => {
  if (fd.lossType === 'TH') {
    return v ? '' : l['ErrTheftReportedRequired'];
  }
  return '';
},


crimeReferenceNumber: (v, fd) => {
  console.log('fd',fd.theftReported)
  if (fd.lossType === 'TH' && fd.theftReported === 'Yes') {
    return v ? '' : l['ErrCrimeReferenceRequired'];
  }
  return '';
},

    email: v => {
      if (!v) return l['ErrEmailRequired'];
      return EMAIL_PATTERN.test(v) ? '' : l['ErrEmailInvalid'];
    },
    phoneNumber: v => {
     if (!v) return l['ErrPhoneRequired']
      return PHONE_PATTERN.test(v) ? '' : l['ErrPhoneFormat'];
    },
    hasUserConfirmed: (_v, formData) =>
      formData.hasUserConfirmed ? '' : l['ErrConsentRequired'],
  };
  
};

const STEP_FIELDS: Record<number, (keyof ClaimFormData)[]> = {
  1: ['firstName', 'lastName', 'email', 'phoneNumber', 'policyNumber', 'serviceNumber',
'relationship',
    'schemeOrProduct',

    // ✅ Policy Address fields
    'policyCountry',
    'policyAddressLine1',
    'policyCity',
    'policyPostalCode'
],
  2: [

  'dateOfLoss',
  'lossType',
  'description'

],
  3: ['itemType', 'purchasePrice', 'claimedAmount', 'itemDescription', 'datePurchased'],
  4: []
};

export const getClaimFieldValidationError = (
  field: keyof ClaimFormData,
  formData: ClaimFormData,
  l: LocalizationMap
): string => {
  const validators = buildValidators(l);
  const validator = validators[field];
  if (!validator) return '';
  const value = typeof formData[field] === 'string' ? (formData[field] as string).trim() : '';
  return validator(value, formData);
};

export const getStepValidationErrors = (
  step: number,
  formData: ClaimFormData,
  l: LocalizationMap
): ClaimFormErrors => {
  const errors: ClaimFormErrors = {};
  const fields = STEP_FIELDS[step] ?? [];

  fields.forEach(field => {
    const fieldError = getClaimFieldValidationError(field, formData, l);
    if (fieldError) errors[field] = fieldError;
  });

  if (step === 2) {
    if (!formData.lossType) {
      errors.lossType = l['ErrLossTypeRequired'];
    }

   if (formData.lossType === 'OTH' && !formData.otherLossType) {
  errors.otherLossType = l['ErrOtherLossTypeRequired'];
}

    if (formData.lossType === 'TH') {
     if (!formData.theftReported) {
  errors.theftReported = l['ErrTheftReportedRequired'];
}
      if (formData.theftReported === 'Yes' && !formData.crimeReferenceNumber) {
        errors.crimeReferenceNumber = l['ErrCrimeReferenceRequired'];
      }
    }

    if (!formData.lossLocationType) {
      errors.lossLocationType = l['ErrFieldRequired'];
    }

    if (formData.lossLocationType === 'DL') {
     
  if (!formData.lossCountry)      errors.lossCountry      = l['ErrCountryRequired'];
  if (!formData.lossAddressLine1) errors.lossAddressLine1 = l['ErrAddressLine1Required'];
  if (!formData.lossCity)         errors.lossCity         = l['ErrCityRequired'];
if (!formData.lossPostalCode) {
  // const labelKey = `${formData.lossCountry}_PCLabel`;

  // const label =
  //   l[labelKey as keyof typeof l] || l['Postal Code'];

  const errKey = `${formData.lossCountry}_PCErrMsg`;

errors.lossPostalCode =
  l[errKey as keyof typeof l] || l['PCErrMsg'];

}


    }
  }
console.log('STEP 2 ERRORS:', errors);

  return errors;
};

export const getClaimFormValidationErrors = (
  formData: ClaimFormData,
  l: LocalizationMap
): ClaimFormErrors => {
  const errors: ClaimFormErrors = {};
  [1, 2, 3, 4].forEach(step => {
    Object.assign(errors, getStepValidationErrors(step, formData, l));
  });
  return errors;
};

