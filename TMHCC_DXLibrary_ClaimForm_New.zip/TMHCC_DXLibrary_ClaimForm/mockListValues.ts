import countriesData from './countries.json'

interface LovItem {
  pyKeyString: string;
  pyActualValue: string;
  pyCategory: string;
  pyRowNumber: string;
  pyAdditionalContext?: string;
}

interface CountryItem{
  Name: string;
  ISOCode : string;
  DialingCode: string;
}

export const LOV_DATA: LovItem[] = [
        {
            "pyActualValue": "Evidence of Ownership",
            "pyCategory": "EvidenceType",
            "pyKeyString": "EvidenceOfOwnership",
            "pyRowNumber": "2"
        },
        {
            "pyActualValue": "Image of Damaged Item",
            "pyCategory": "EvidenceType",
            "pyKeyString": "ImageOfDamagedItem",
            "pyRowNumber": "3"
        },
        {
            "pyActualValue": "Other",
            "pyCategory": "EvidenceType",
            "pyKeyString": "Other",
            "pyRowNumber": "4"
        },
        {
            "pyActualValue": "Proof of Purchase",
            "pyCategory": "EvidenceType",
            "pyKeyString": "ProofOfPurchase",
            "pyRowNumber": "1"
        },
        {
            "pyActualValue": "False",
            "pyCategory": "GenericTrueFalse",
            "pyKeyString": "false",
            "pyRowNumber": "2"
        },
        {
            "pyActualValue": "True",
            "pyCategory": "GenericTrueFalse",
            "pyKeyString": "true",
            "pyRowNumber": "1"
        },
        {
            "pyActualValue": "No",
            "pyCategory": "GenericYesNo",
            "pyKeyString": "No",
            "pyRowNumber": "2"
        },
        {
            "pyActualValue": "Yes",
            "pyCategory": "GenericYesNo",
            "pyKeyString": "Yes",
            "pyRowNumber": "1"
        },
        {
            "pyActualValue": "Military Kit",
            "pyCategory": "ItemType",
            "pyKeyString": "MK",
            "pyRowNumber": "1"
        },
        {
            "pyActualValue": "Personally Purchased Kit",
            "pyCategory": "ItemType",
            "pyKeyString": "PPK",
            "pyRowNumber": "2"
        },
        {
            "pyActualValue": "Mobile Phone",
            "pyCategory": "ItemType",
            "pyKeyString": "MP",
            "pyRowNumber": "3"
        },
        {
            "pyActualValue": "Jewellery",
            "pyCategory": "ItemType",
            "pyKeyString": "JEW",
            "pyRowNumber": "4"
        },
        {
            "pyActualValue": "Valuables",
            "pyCategory": "ItemType",
            "pyKeyString": "VAL",
            "pyRowNumber": "5"
        },
        {
            "pyActualValue": "Furniture / Household Items",
            "pyCategory": "ItemType",
            "pyKeyString": "FHI",
            "pyRowNumber": "6"
        },
        {
            "pyActualValue": "Bedding & Linen",
            "pyCategory": "ItemType",
            "pyKeyString": "BEL",
            "pyRowNumber": "7"
        },
        {
            "pyActualValue": "Clothing & Uniform",
            "pyCategory": "ItemType",
            "pyKeyString": "CLU",
            "pyRowNumber": "8"
        },
        {
            "pyActualValue": "Footwear",
            "pyCategory": "ItemType",
            "pyKeyString": "FTW",
            "pyRowNumber": "9"
        },
        {
            "pyActualValue": "Sports Equipment",
            "pyCategory": "ItemType",
            "pyKeyString": "SPO",
            "pyRowNumber": "10"
        },
        {
            "pyActualValue": "Cycling Equipment",
            "pyCategory": "ItemType",
            "pyKeyString": "CYC",
            "pyRowNumber": "11"
        },
        {
            "pyActualValue": "Optical Equipment",
            "pyCategory": "ItemType",
            "pyKeyString": "OPE",
            "pyRowNumber": "12"
        },
        {
            "pyActualValue": "Watches",
            "pyCategory": "ItemType",
            "pyKeyString": "WAT",
            "pyRowNumber": "13"
        },
        {
            "pyActualValue": "Bags & Luggage",
            "pyCategory": "ItemType",
            "pyKeyString": "BAL",
            "pyRowNumber": "14"
        },
        {
            "pyActualValue": "Tools & Equipment",
            "pyCategory": "ItemType",
            "pyKeyString": "TOE",
            "pyRowNumber": "15"
        },
        {

            "pyActualValue": "A different location",
            "pyCategory": "LossLocation",
            "pyKeyString": "DL",
            "pyRowNumber": "3",
            "pyAdditionalContext": "Enter an address or describe the location"
        },
        {

            "pyActualValue": "Same as my address",
            "pyCategory": "LossLocation",
            "pyKeyString": "PHA",
            "pyRowNumber": "1",
            "pyAdditionalContext": "On base or at your registered address"
        },
        {

            "pyActualValue": "On deployment or exercise",
            "pyCategory": "LossLocation",
            "pyKeyString": "DE",
            "pyRowNumber": "2",
            "pyAdditionalContext": "Overseas or at a different military location"
        },
        {

            "pyActualValue": "Accidental Damage",
            "pyCategory": "LossType",
            "pyKeyString": "DA",
            "pyRowNumber": "3"
        },
        {

            "pyActualValue": "Damage to my SFA (service family accommodation)",
            "pyCategory": "LossType",
            "pyKeyString": "DSFA",
            "pyRowNumber": "7"
        },
        {

            "pyActualValue": "Damage to my SLA (single living accommodation)",
            "pyCategory": "LossType",
            "pyKeyString": "DSLA",
            "pyRowNumber": "6"
        },
        {

            "pyActualValue": "Fire",
            "pyCategory": "LossType",
            "pyKeyString": "FI",
            "pyRowNumber": "4"
        },
        {

            "pyActualValue": "Accidental Loss",
            "pyCategory": "LossType",
            "pyKeyString": "LO",
            "pyRowNumber": "2"
        },
        {

            "pyActualValue": "Other",
            "pyCategory": "LossType",
            "pyKeyString": "OTH",
            "pyRowNumber": "8"
        },
        {

            "pyActualValue": "Theft",
            "pyCategory": "LossType",
            "pyKeyString": "TH",
            "pyRowNumber": "1"
        },
        {

            "pyActualValue": "Water Damage",
            "pyCategory": "LossType",
            "pyKeyString": "WD",
            "pyRowNumber": "5"
        },
        {

            "pyActualValue": "Military Kit Contents and Personal Possessions",
            "pyCategory": "Product",
            "pyKeyString": "MKCPP",
            "pyRowNumber": "1"
        },
        {

            "pyActualValue": "Dependent",
            "pyCategory": "Relationship",
            "pyKeyString": "DP",
            "pyRowNumber": "3"
        },
        {

            "pyActualValue": "Policyholder",
            "pyCategory": "Relationship",
            "pyKeyString": "PH",
            "pyRowNumber": "1"
        },
        {

            "pyActualValue": "Spouse",
            "pyCategory": "Relationship",
            "pyKeyString": "SP",
            "pyRowNumber": "2"
        },
        {

            "pyActualValue": "Authorised Person",
            "pyCategory": "Relationship",
            "pyKeyString": "AP",
            "pyRowNumber": "4"
        },
        {

            "pyActualValue": "Other (if applicable)",
            "pyCategory": "Relationship",
            "pyKeyString": "OTH",
            "pyRowNumber": "5"
        },
        {

            "pyActualValue": "Military Service Uniform, Equipment and Personally Purchased Kit",
            "pyCategory": "ItemCoverType",
            "pyKeyString": "MEP",
            "pyRowNumber": "1"
        },
        {

            "pyActualValue": "Valuables and Personal Possessions",
            "pyCategory": "ItemCoverType",
            "pyKeyString": "VPP",
            "pyRowNumber": "2"
        },
        {

            "pyActualValue": "Contents",
            "pyCategory": "ItemCoverType",
            "pyKeyString": "CON",
            "pyRowNumber": "3"
        },
        {

            "pyActualValue": "Personal Liability",
            "pyCategory": "ItemCoverType",
            "pyKeyString": "PEL",
            "pyRowNumber": "4"
        },
        {

            "pyActualValue": "Money and Credit Card Cover",
            "pyCategory": "ItemCoverType",
            "pyKeyString": "MCCC",
            "pyRowNumber": "5"
        },
        {

            "pyActualValue": "Pedal Cycles",
            "pyCategory": "ItemCoverType",
            "pyKeyString": "PECY",
            "pyRowNumber": "6"
        },
        {

            "pyActualValue": "Licence to Occupy",
            "pyCategory": "ItemCoverType",
            "pyKeyString": "LTO",
            "pyRowNumber": "7"
        }
    ];

export function mockGetDataAsync(
  dataPage: string,
  _context: unknown,
  parameters: Record<string, string>
): Promise<{ data: LovItem[] | CountryItem[] }> {
  if (dataPage === 'D_LOVList') {
    console.log('lov_da',LOV_DATA)
    const category = parameters?.Category ?? '';
    return Promise.resolve({
      data: category? LOV_DATA.filter(item => item.pyCategory === category) : LOV_DATA
    });
  }
  else if(dataPage === 'D_CountryList'){
    return Promise.resolve({
      data: countriesData.data as CountryItem[]
    });
  }
  return Promise.resolve({ data: [] });
}
