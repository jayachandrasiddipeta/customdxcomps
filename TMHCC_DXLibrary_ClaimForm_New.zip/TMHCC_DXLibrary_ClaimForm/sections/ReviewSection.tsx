import { Fragment, useState } from 'react';
import { Icon } from '@pega/cosmos-react-core';
import type { ClaimFormData, UploadedAttachment } from '../types';
import type { LocalizationMap } from '../utils/useLocalization';
import InfoIcon from './InfoIcon';

interface ReviewSectionProps {
  formData: ClaimFormData;
  l: LocalizationMap;
  getLabel: (category: string, key: string) => string;
  onFieldChange: (field: keyof ClaimFormData, value: string | boolean) => void;
  actions?: React.ReactNode;
}

const formatAddress = (...parts: (string | undefined)[]): string =>
  parts.filter(p => p?.trim()).join(', ') || '—';

function ReviewField({ label, value }: { label: string; value: string }) {
  return (
    <dl className='review-field'>
      <dt className='review-field__label'>{label}</dt>
      <dd className='review-field__value'>{value || '—'}</dd>
    </dl>
  );
}

function ReviewBlock({
  title,
  isOpen,
  onToggle,
  children,
  onEdit
}: {
  title: string;
  isOpen: boolean;
  onToggle: () => void;
  children: React.ReactNode;
  onEdit: () => void;
}) {
  return (
    <div className='review-card'>
      <div
        className='review-card__header'
        onClick={onToggle}
        role='button'
        aria-expanded={isOpen}
      >
        <div className='review-card__title'>
          <span className='review-card__heading'>{title}</span>
        </div>
        <div className='review-card__icons'>
          <button
            type='button'
            className='review-card__icon-btn'
            aria-label='Edit'
            onClick={e => { e.stopPropagation(); onEdit(); }}
          >
            <Icon name='pencil' />
          </button>
          <button
            type='button'
            className='review-card__icon-btn'
            aria-label={isOpen ? 'Collapse' : 'Expand'}
            onClick={e => { e.stopPropagation(); onToggle(); }}
          >
            <Icon name={isOpen ? 'caret-up' : 'caret-down'} />
          </button>
        </div>
      </div>

      {isOpen && (
        <div className='review-card__content'>
          <div className='review-grid'>{children}</div>
        </div>
      )}
    </div>
  );
}

function ReviewSection({
  formData,
  setCurrentStep,
  onFieldChange,
  l,
  getLabel,
  actions
}: ReviewSectionProps & { setCurrentStep: (step: number) => void }) {
  const [showInfo, setShowInfo] = useState(false);
  const [openBlocks, setOpenBlocks] = useState<Record<number, boolean>>({
    1: false,
    2: false,
    3: false,
    4: false
  });

  const allOpen = Object.values(openBlocks).every(Boolean);

  const toggleBlock = (step: number) =>
    setOpenBlocks(prev => ({ ...prev, [step]: !prev[step] }));

  const toggleAll = () => {
    const next = !allOpen;
    setOpenBlocks({ 1: next, 2: next, 3: next, 4: next });
  };

  const policyAddress = formatAddress(
    formData.policyAddressLine1,
    formData.policyAddressLine2,
    formData.policyCity,
    formData.policyPostalCode,
    getLabel('country', formData.policyCountry)
  );

  const riskAddress = formData.lossLocationType === 'PHA'
    ? policyAddress
    : formatAddress(
        formData.lossAddressLine1,
        formData.lossAddressLine2,
        formData.lossCity,
        formData.lossPostalCode,
        getLabel('country', formData.lossCountry)
      );

  const totalClaimedAmount = formData.items.reduce(
    (sum, item) => sum + (parseFloat(item.claimedAmount) || 0),
    0
  );

  return (
    <section className='claim-form__section'>
      <h3 className='claim-form__section-title claim-form__title-with-icon'>
        {l['Review Your Claim']}
        <button
          type='button'
          className='claim-form__info-icon'
          onClick={() => setShowInfo(prev => !prev)}
          aria-label={showInfo ? 'Hide info' : 'Show info'}
        >
          <InfoIcon />
        </button>
      </h3>

      {showInfo && (
        <div className='claim-form__info-box'>
          <div className='claim-form__info-left'>
            <div className='claim-form__info-box-icon'>
              <InfoIcon />
            </div>
            <div className='claim-form__info-content'>
              {l['ReviewInstructions']}
            </div>
          </div>
          <button
            type='button'
            className='claim-form__info-close'
            onClick={() => setShowInfo(false)}
          >
            ×
          </button>
        </div>
      )}

      <div className='review-expand-all-row'>
        <button type='button' className='review-expand-all-link' onClick={toggleAll}>
          {allOpen ? l['CollapseAll'] : l['ExpandAll']}
        </button>
      </div>

      <ReviewBlock
        title={l['Your Details']}
        isOpen={openBlocks[1]}
        onToggle={() => toggleBlock(1)}
        onEdit={() => setCurrentStep(1)}
      >
        <ReviewField label={l['First Name']} value={formData.firstName} />
        <ReviewField label={l['Last Name']} value={formData.lastName} />
        <ReviewField label={l['Email Address']} value={formData.email} />
        <ReviewField label={l['Phone Number']} value={formData.phoneNumber} />
        <ReviewField label={l['Policy Number']} value={formData.policyNumber} />
        <ReviewField label={l['Relationship to Policyholder']} value={getLabel('relationship', formData.relationship)} />

        {formData.relationship === 'SP' && (
          <>
            <div className='review-field review-field--full'>
              <strong>{l['Spouse Details']}</strong>
            </div>
            <ReviewField label={l['First Name']} value={formData.spouseFirstName || ''} />
            <ReviewField label={l['Last Name']} value={formData.spouseLastName || ''} />
            <ReviewField label={l['Email Address']} value={formData.spouseEmail || ''} />
            <ReviewField label={l['Phone Number']} value={formData.spousePhoneNumber || ''} />
          </>
        )}

        {formData.relationship === 'DP' && (
          <>
            <div className='review-field review-field--full'>
              <strong>{l['Dependent Details']}</strong>
            </div>
            <ReviewField label={l['First Name']} value={formData.dependentFirstName || ''} />
            <ReviewField label={l['Last Name']} value={formData.dependentLastName || ''} />
            <ReviewField label={l['Date of Birth']} value={formData.dependentDateOfBirth || ''} />
            <ReviewField label={l['Relationship to Policyholder']} value={formData.dependentRelationship || ''} />
            <ReviewField label={l['Email Address']} value={formData.dependentEmail || ''} />
            <ReviewField label={l['Phone Number']} value={formData.dependentPhoneNumber || ''} />
          </>
        )}

        {formData.relationship === 'AP' && (
          <>
            <div className='review-field review-field--full'>
              <strong>{l['Authorised Person Details']}</strong>
            </div>
            <ReviewField label={l['First Name']} value={formData.authorisedFirstName || ''} />
            <ReviewField label={l['Last Name']} value={formData.authorisedLastName || ''} />
            <ReviewField label={l['Email Address']} value={formData.authorisedEmail || ''} />
            <ReviewField label={l['Phone Number']} value={formData.authorisedPhoneNumber || ''} />
          </>
        )}

        {formData.relationship === 'OTH' && (
          <>
            <div className='review-field review-field--full'>
              <strong>{l['Additional Details']}</strong>
            </div>
            <ReviewField
              label={l['Describe your relationship to the policyholder']}
              value={formData.otherRelationshipDescription || ''}
            />
            <ReviewField label={l['First Name']} value={formData.otherPersonFirstName || ''} />
            <ReviewField label={l['Last Name']} value={formData.otherPersonLastName || ''} />
            <ReviewField label={l['Email Address']} value={formData.otherPersonEmail || ''} />
            <ReviewField label={l['Phone Number']} value={formData.otherPersonPhoneNumber || ''} />
          </>
        )}

        <ReviewField label={l['Service Number']} value={formData.serviceNumber} />
        <ReviewField label={l['ReviewSchemeProduct']} value={getLabel('product', formData.schemeOrProduct)} />
        <ReviewField label={l['ReviewAddressLabel']} value={policyAddress} />
      </ReviewBlock>

      <ReviewBlock
        title={l['What Happened']}
        isOpen={openBlocks[2]}
        onToggle={() => toggleBlock(2)}
        onEdit={() => setCurrentStep(2)}
      >
        <ReviewField label={l['Date of Loss']} value={formData.dateOfLoss} />
        <ReviewField label={l['Loss Type']} value={getLabel('lossType', formData.lossType)} />
        {formData.lossType === 'OTH' && (
          <ReviewField label={l['OtherLossType']} value={formData.otherLossType || ''} />
        )}
        <dl className='review-field'>
          <dt className='review-field__label'>{l['Description']}</dt>
          <dd className='review-field__value'>{formData.description || '—'}</dd>
        </dl>

        <ReviewField label={l['Where did this happen']} value={getLabel('lossLocation', formData.lossLocationType)} />

        {formData.lossLocationType === 'DE' ? (
          <>
            <ReviewField label={l['Country of deployment']} value={getLabel('country', formData.deploymentCountry || '')} />
            <ReviewField label={l['Base or location name']} value={formData.deploymentLocationName || ''} />
          </>
        ) : (
          <ReviewField label={l['Risk Address']} value={riskAddress} />
        )}
      </ReviewBlock>

      <ReviewBlock
        title={l['Items Affected']}
        isOpen={openBlocks[3]}
        onToggle={() => toggleBlock(3)}
        onEdit={() => setCurrentStep(3)}
      >
        {formData.items.map((item, index) => (
          <Fragment key={item.id}>
            <div className='review-field review-field--full'>
              <strong>Item {index + 1}</strong>
            </div>

            <ReviewField
              label={l['Item Cover Type']}
              value={getLabel('itemCoverType', item.itemCoverType)}
            />

            <ReviewField
              label={l['Item Type']}
              value={getLabel('itemType', item.itemType)}
            />

            <ReviewField
              label={`${l['Purchase Price']} (£)`}
              value={item.purchasePrice}
            />

            <ReviewField
              label={`${l['Claimed Amount']} (£)`}
              value={item.claimedAmount}
            />

            <ReviewField
              label={l['Date Purchased']}
              value={item.datePurchased}
            />

            <div className='review-field review-field--full'>
              <dt className='review-field__label'>{l['Item Description']}</dt>
              <dd className='review-field__value'>{item.itemDescription || '—'}</dd>
            </div>

            <div className='claim-form__divider review-field--full' />
          </Fragment>
        ))}
      </ReviewBlock>

      <ReviewBlock
        title={l['ReviewSupportingEvidenceTitle']}
        isOpen={openBlocks[4]}
        onToggle={() => toggleBlock(4)}
        onEdit={() => setCurrentStep(4)}
      >
        <div className='review-field review-field--full'>
          <span className='review-field__label'>
            {l['Files Uploaded']}: <strong>{String(l['FilesNumber']).replace('{1}', String(formData.attachments.length))}</strong>
          </span>
          {formData.attachments.length > 0 ? (
            <ul className='review-field__file-list'>
              {formData.attachments.map((a: UploadedAttachment) => {
                const typeLabel = a.docType === 'Other'
                  ? (a.otherDocType?.trim() || String(l['Other']))
                  : (a.docTypeLabel || a.docType);
                return (
                  <li key={a.id}>
                    {a.name}{typeLabel ? ` (${typeLabel})` : ''}
                  </li>
                );
              })}
            </ul>
          ) : (
            <span className='review-field__value'>{l['No files uploaded']}</span>
          )}
        </div>
      </ReviewBlock>

      <div className='claim-form__summary'>
        <h4 className='claim-form__summary-title'>{l['ClaimSummary']}</h4>
        <div className='claim-form__summary-section claim-form__summary-section--row'>
          <div className='claim-form__summary-label'>{l['TotalClaimValue']}:</div>
          <div className='claim-form__summary-total'>£{totalClaimedAmount.toFixed(2)}</div>
        </div>
      </div>

      <div className='review-declaration'>
        <h3 className='review-declaration__title'>{l['Fraud prevention notice']}</h3>
        <div className='review-notice-box'>
          <p>{l['FPNText']}</p>
          <p>{l['FPNText2']}</p>
          <p>
            {l['PrivacyPolicyNoticeText']} <span className='review-privacy-link'>{l['PrivacyPolicyLinkLabel']}</span>.
          </p>
        </div>

        <h3 className='review-declaration__title'>{l['Declaration']}</h3>
        <div className='review-notice-box review-notice-box--declaration'>
          <p>{l['CACText']}</p>
          <p>{l['CACText2']}</p>
        </div>

        <label className='review-declaration__checkbox review-declaration__checkbox--single'>
          <input
            type='checkbox'
            checked={formData.declarationConsent}
            onChange={e => onFieldChange('declarationConsent', e.target.checked)}
          />
          <span>{l['DeclarationConsentText']}</span>
        </label>
      </div>

      {actions && <div className='claim-form__section-actions'>{actions}</div>}
    </section>
  );
}

export default ReviewSection;
