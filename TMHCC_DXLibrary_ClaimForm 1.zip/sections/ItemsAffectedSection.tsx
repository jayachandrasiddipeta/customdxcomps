import type { ClaimFormData, ClaimItem  } from '../types';
import { useState } from 'react';
import InfoIcon from './InfoIcon';
import type { ListOption } from '../utils/listValuesUtils';
import type { LocalizationMap } from '../utils/useLocalization';
import { Icon } from '@pega/cosmos-react-core';

interface ItemsAffectedSectionProps {
  formData: ClaimFormData;
  onItemsChange: (items: ClaimItem[]) => void;
  onItemBlur: (index: number, field: keyof ClaimItem) => void;
  onClearItemError: (index: number, field: keyof ClaimItem) => void; 
  itemErrors:any,
  itemTypeOptions: ListOption[];
  l: LocalizationMap;
}

function ItemsAffectedSection({ formData, onItemsChange, itemTypeOptions, itemErrors,onItemBlur,onClearItemError,l }: ItemsAffectedSectionProps) {
  console.log('items:', formData.items);

   const [showInfo, setShowInfo] = useState(false);
  const [itemsLimitError, setItemsLimitError] = useState('');

const MAX_ITEMS = 20;

const addItem = () => {
  if (formData.items.length >= MAX_ITEMS) {
    setItemsLimitError(l['ErrMaxItemsReached'] || 'Maximum 20 items allowed');
    return;
  }

  setItemsLimitError('');

  onItemsChange([
    ...formData.items,
    {
      id: `${Date.now()}-${Math.random()}`,
      itemType: '',
      otherItemType: '',
      itemDescription: '',
      purchasePrice: '',
      claimedAmount: '',
      datePurchased: ''
    }
  ]);
};

const removeItem = (index: number) => {
  const updated = [...formData.items];
  updated.splice(index, 1);
  onItemsChange(updated);
  
 if (updated.length < MAX_ITEMS) {
    setItemsLimitError('');
};
}

const handleItemChange = (
  index: number,
  field: keyof ClaimItem,
  value: string
) => {
  const updated = [...formData.items];

  updated[index] = {
    ...updated[index],
    [field]: value,
    ...(field === 'itemType' && value !== 'OTH'
      ? { otherItemType: '' }
      : {})
  };

  onItemsChange(updated);

  onClearItemError(index, field);

  if (field === 'itemType' && value !== 'OTH') {
    onClearItemError(index, 'otherItemType');
  }
};
const totalClaimedAmount = formData.items.reduce(
  (sum, item) => sum + (parseFloat(item.claimedAmount) || 0),
  0
);

const totalPurchaseAmount = formData.items.reduce(
  (sum, item) => sum + (parseFloat(item.purchasePrice) || 0),
  0
);

//
const isTotalInvalid = totalClaimedAmount > totalPurchaseAmount;

  return (
    <section className='claim-form__section'>
      <h3 className='claim-form__section-title claim-form__title-with-icon'>
        <span className='claim-form__section-index'>3</span>
        {l['Items Affected']}
        <button
          type="button"
          className="claim-form__info-icon"
          onClick={() => setShowInfo(prev => !prev)}
          aria-label={showInfo ? 'Hide info' : 'Show info'}
        >
          <InfoIcon />
        </button>
      </h3>
         {showInfo && (
  <div className="claim-form__info-box">

    {/* ✅ LEFT SIDE */}
    <div className="claim-form__info-left">

      {/* ✅ ICON */}
      <div className="claim-form__info-box-icon">
        <InfoIcon />
      </div>

      {/* ✅ TEXT */}
      <div className="claim-form__info-content">
        {l['ItemsAffectedInstruction']}
      </div>

    </div>

    {/* ✅ CLOSE BUTTON (RIGHT) */}
    <button
      type="button"
      className="claim-form__info-close"
      onClick={() => setShowInfo(false)}
    >
      ×
    </button>

  </div>
)}
{formData.items.map((item, index) => (
  <div key={item.id} className="claim-form__group claim-form__field--full">

    {/* HEADER */}
    <div className="claim-form__item-header">
      <h4>Item {index + 1}</h4>

      {index > 0 && (
        <button
          type="button"
          className="claim-form__delete-btn"
          onClick={() => removeItem(index)}
          aria-label="Remove item"
        >
          <Icon name="trash" />
        </button>
      )}
    </div>

    <div className="claim-form__grid">

      {/* ITEM TYPE */}
      <label className="claim-form__field">
        <span>{l['Item Type']} <span className="claim-form__required-star">*</span></span>
        <select
          value={item.itemType}
          onChange={e => handleItemChange(index, 'itemType', e.target.value)}
           onBlur={() => onItemBlur(index, 'itemType')}
        >
          <option value="">{l['SelectOptionPH']}</option>
          {itemTypeOptions.map(opt => (
            <option key={opt.key} value={opt.key}>{opt.label}</option>
          ))}
        </select>
        
{itemErrors[index]?.itemType && (
  <div className="claim-form__error">
    {itemErrors[index].itemType}
  </div>
)}

      </label>

      {/* CLAIMED AMOUNT */}
      <label className="claim-form__field">
        <span>{l['Claimed Amount']} (£) <span className="claim-form__required-star">*</span></span>
        <input
         placeholder={l['AmountPH']}
          value={item.claimedAmount}
          onChange={e =>
            handleItemChange(
              index,
              'claimedAmount',
              e.target.value.replace(/[^\d.]/g, '').replace(/(\..*)\./g, '$1')
            )
          }
          onBlur={() => onItemBlur(index, 'claimedAmount')}
        />
        
{itemErrors[index]?.claimedAmount && (
  <div className="claim-form__error">
    {itemErrors[index].claimedAmount}
  </div>
)}

      </label>

      {/* OTHER TYPE */}
      {item.itemType === 'OTH' && (
        <label className="claim-form__field claim-form__field--full">
          <span>{l['OtherItemType']} <span className="claim-form__required-star">*</span></span>
          <input
           placeholder={l['OtherItemTypePH']}
            value={item.otherItemType || ''}
            onChange={e =>
              handleItemChange(index, 'otherItemType', e.target.value)
            }
             onBlur={() => onItemBlur(index, 'otherItemType')}
          />
          {itemErrors[index]?.otherItemType && (
  <div className="claim-form__error">
    {itemErrors[index].otherItemType}
  </div>
)}
        </label>
      )}

      {/* DESCRIPTION */}
      <label className="claim-form__field claim-form__field--full">
        <span>{l['Item Description']} <span className="claim-form__required-star">*</span></span>
    <textarea
  placeholder={l['ItemDescPH']}
  rows={4}
  maxLength={l['ItemDescriptionMaxLength']}
  value={item.itemDescription}
  onChange={e =>
    handleItemChange(index, 'itemDescription', e.target.value)
  }
  onBlur={() => onItemBlur(index, 'itemDescription')}
/>

<div className="claim-form_field-footer">
  {/* ✅ ERROR (left) */}
  <span>
    {itemErrors[index]?.itemDescription && (
      <small className="claim-form__error" role="alert">
        {itemErrors[index].itemDescription}
      </small>
    )}
  </span>

  {/* ✅ COUNTER (right) */}
  <small
    className={`claim-form_char-counter${
      item.itemDescription.length >= l['CharCounterWarnThreshold']
        ? ' claim-form_char-counter-warn'
        : ''
    }`}
  >
    {item.itemDescription.length} / {l['ItemDescriptionMaxLength']}
  </small>
</div>

      </label>

      {/* PURCHASE PRICE */}
      <label className="claim-form__field">
        <span>{l['Purchase Price']} (£) <span className="claim-form__required-star">*</span></span>
        <input
         placeholder={l['AmountPH']}
          value={item.purchasePrice}
          onChange={e =>
            handleItemChange(
              index,
              'purchasePrice',
              e.target.value.replace(/[^\d.]/g, '').replace(/(\..*)\./g, '$1')
            )
          }
          onBlur={() => onItemBlur(index, 'purchasePrice')}
        />
        {itemErrors[index]?.purchasePrice && (
  <div className="claim-form__error">
    {itemErrors[index].purchasePrice}
  </div>
)}
      </label>

      {/* DATE */}
      <label className="claim-form__field">
        <span>{l['Date Purchased']} <span className="claim-form__required-star">*</span></span>
        <input
          type="date"
          value={item.datePurchased || ''}
          onChange={e =>
            handleItemChange(index, 'datePurchased', e.target.value)
          }
            onBlur={() => onItemBlur(index, 'datePurchased')}
        />
        
        {itemErrors[index]?.datePurchased && (
  <div className="claim-form__error">
    {itemErrors[index].datePurchased}
  </div>
)}
     </label>
    </div>
  </div>
))}
<div
  className="claim-form__add-item"
  onClick={addItem}   // ✅ click anywhere
>
 <span className="claim-form__add-item-text">
  <span className="claim-form__add-icon">+</span>
  {l['AddAnotherItem']}
</span>
</div>
{itemsLimitError && (
  <div className="claim-form__error" style={{ marginTop: '8px' }}>
    {itemsLimitError}
  </div>
)}
{/* ✅ CLAIM SUMMARY */}
<div className="claim-form__summary">

  <h4 className="claim-form__summary-title">{l['ClaimSummary']}</h4>

  {/* Items included */}
  <div className="claim-form__summary-section">
    <div className="claim-form__summary-label">{l['ItemsIncluded']}</div>
    <ul className="claim-form__summary-list">
      {formData.items.map((item, index) => (
        <li key={item.id}>
          {item.itemType
            ? itemTypeOptions.find(opt => opt.key === item.itemType)?.label || `Item ${index + 1}`
            : `Item ${index + 1}`}
        </li>
      ))}
    </ul>
  </div>

  <hr className="claim-form__summary-divider" />

  {/* Number of items */}
  <div className="claim-form__summary-section">
    <div className="claim-form__summary-label">{l['NumberOfItems']}</div>
    <div className="claim-form__summary-value">
      {formData.items.length}
    </div>
  </div>

  <hr className="claim-form__summary-divider" />

{/* ✅ Total Purchase Value (FIRST) */}
<div className="claim-form__summary-section">
  <div className="claim-form__summary-label">
    {l['TotalPurchaseAmount']}
  </div>

  <div className="claim-form__summary-value">
    £{totalPurchaseAmount.toFixed(2)}
  </div>
</div>
<hr className="claim-form__summary-divider" />
{/* ✅ Total Claim Value (SECOND) */}
<div className="claim-form__summary-section">
  <div className="claim-form__summary-label">
    {l['TotalClaimAmount']}
  </div>

  <div className="claim-form__summary-total">
    £{totalClaimedAmount.toFixed(2)}
  </div>

  {isTotalInvalid && (
    <div className="claim-form__error">
      {l['ErrTotalClaimExceeds']}
    </div>
  )}
</div>
</div>
    </section>
  );
}

export default ItemsAffectedSection;
