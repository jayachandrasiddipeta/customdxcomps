import type { ClaimFormData } from '../types';
import { fetchClientPublicIp } from './clientIpUtils';
import { extractPegaErrorMessage } from './pegaErrorUtils';

interface ClaimCaseOptions {
  /** Path for PCore.getRestClient().invokeCustomRestApi (e.g. api/TrinityClaims/v1/create). */
  createClaimApiPath: string;
  caseTypeID: string;
  formData: ClaimFormData;
}

interface ClaimCaseResponse {
  ID?: string;
  success: boolean;
  message?: string;
}

export const createClaimCase = async ({
  createClaimApiPath,
  caseTypeID,
  formData
}: ClaimCaseOptions): Promise<ClaimCaseResponse> => {
  try {
    const apiPath = createClaimApiPath.trim();
    if (!apiPath) {
      return {
        success: false,
        message: 'Create claim API path is not configured.'
      };
    }

    const remoteIp = await fetchClientPublicIp();

    const isPHA = formData.lossLocationType === 'PHA';
    const lossCity         = isPHA ? formData.policyCity         : formData.lossCity;
    const lossCountry      = isPHA ? formData.policyCountry      : formData.lossCountry;
    const lossPostalCode   = isPHA ? formData.policyPostalCode   : formData.lossPostalCode;
    const lossAddressLine1 = isPHA ? formData.policyAddressLine1 : formData.lossAddressLine1;
    const lossAddressLine2 = isPHA ? formData.policyAddressLine2 : formData.lossAddressLine2;

    const requestBody = {
      caseTypeID,
      content: 
      {
        ClaimAccuracyConfirmation: formData.claimAccuracyConfirmation,
        CreationSource: "WebForm",
        FraudPreventionNotice: formData.fraudPreventionNotice,
        PolicyNumber: formData.policyNumber,
        Product: formData.schemeOrProduct,
        ServiceNumber: formData.serviceNumber,
        RelationshipWithPolicyHolder: formData.relationship,
        UserDetails: {
          EmailAddress: formData.email,
          FirstName: formData.firstName,
          LastName: formData.lastName,
          PhoneNumber: formData.phoneNumber,
          PolicyAddress: {
            pyCity: formData.policyCity,
            pyCountry: formData.policyCountry,
            pyPostalCode: formData.policyPostalCode,
            pyStreetAddress: formData.policyAddressLine1,
            pyStreetAddress2: formData.policyAddressLine2
          },
        },
        ClaimInfo: {
          CrimeReferenceNumber: formData.crimeReferenceNumber,
          IsTheftReportedToPolice: formData.theftReported === 'Yes',
          LossDate: formData.dateOfLoss,
          LossDescription: formData.description,
          LossType: formData.lossType,
          OtherLossType: formData.otherLossType,
          WhereDidThisHappen: formData.lossLocationType,
          LossAddress: {
            pyCity: lossCity,
            pyCountry: lossCountry,
            pyPostalCode: lossPostalCode,
            pyStreetAddress: lossAddressLine1,
            pyStreetAddress2: lossAddressLine2
          }
        },
       
        ItemsAffected: formData.items.map(item => ({
        ClaimAmount: item.claimedAmount,
        Description: item.itemDescription,
        ItemType: item.itemType,
        PurchaseDate: item.datePurchased,
        PurchasePrice: item.purchasePrice,
        OtherItemType: item.otherItemType
    }))
      }
    };

    const response = await (window as any).PCore.getRestClient().invokeCustomRestApi(apiPath, {
      method: 'POST',
      body: requestBody,
      headers: {
        'Access-Control-Allow-Origin': '*',
        ...(remoteIp ? { RemoteIP: remoteIp } : {})
      }
    });

    return {
      success: true,
      ID: response.data?.ID,
      message: 'Claim case created successfully'
    };
  } catch (error: unknown) {
    return {
      success: false,
      message: extractPegaErrorMessage(error, 'Failed to create claim case')
    };
  }
};
