import countriesData from './countries.json'

interface LovItem {
  pyKeyString: string;
  pyActualValue: string;
  pyCategory: string;
  pyRowNumber: string;
}

interface CountryItem{
  Name: string;
  ISOCode : string;
  DialingCode: string;
}

export const LOV_DATA: LovItem[] = [
        {
            "pyActualValue": "Evidence of Ownership",
            "pyCategory": "EvidenceType",
            "pyKeyString": "EvidenceOfOwnership",
            "pyRowNumber": "2"
        },
        {
            "pyActualValue": "Image of Damaged Item",
            "pyCategory": "EvidenceType",
            "pyKeyString": "ImageOfDamagedItem",
            "pyRowNumber": "3"
        },
        {
            "pyActualValue": "Other",
            "pyCategory": "EvidenceType",
            "pyKeyString": "Other",
            "pyRowNumber": "4"
        },
        {
            "pyActualValue": "Proof of Purchase",
            "pyCategory": "EvidenceType",
            "pyKeyString": "ProofOfPurchase",
            "pyRowNumber": "1"
        },
        {
            "pyActualValue": "False",
            "pyCategory": "GenericTrueFalse",
            "pyKeyString": "false",
            "pyRowNumber": "2"
        },
        {
            "pyActualValue": "True",
            "pyCategory": "GenericTrueFalse",
            "pyKeyString": "true",
            "pyRowNumber": "1"
        },
        {
            "pyActualValue": "No",
            "pyCategory": "GenericYesNo",
            "pyKeyString": "No",
            "pyRowNumber": "2"
        },
        {
            "pyActualValue": "Yes",
            "pyCategory": "GenericYesNo",
            "pyKeyString": "Yes",
            "pyRowNumber": "1"
        },
        {
            "pyActualValue": "Clothing",
            "pyCategory": "ItemType",
            "pyKeyString": "CL",
            "pyRowNumber": "2",
        },
        {

            "pyActualValue": "Electronics",
            "pyCategory": "ItemType",
            "pyKeyString": "EL",
            "pyRowNumber": "1"
        },
        {

            "pyActualValue": "Furniture",
            "pyCategory": "ItemType",
            "pyKeyString": "FU",
            "pyRowNumber": "3"
        },
        {

            "pyActualValue": "Other",
            "pyCategory": "ItemType",
            "pyKeyString": "OTH",
            "pyRowNumber": "5"
        },
        {

            "pyActualValue": "Sports Equipment",
            "pyCategory": "ItemType",
            "pyKeyString": "SE",
            "pyRowNumber": "4"
        },
        {

            "pyActualValue": "Different location",
            "pyCategory": "LossLocation",
            "pyKeyString": "DL",
            "pyRowNumber": "2"
        },
        {

            "pyActualValue": "Same as policyholder address",
            "pyCategory": "LossLocation",
            "pyKeyString": "PHA",
            "pyRowNumber": "1"
        },
        {

            "pyActualValue": "Accidental Damage",
            "pyCategory": "LossType",
            "pyKeyString": "DA",
            "pyRowNumber": "3"
        },
        {

            "pyActualValue": "Damage to my SFA (service family accommodation)",
            "pyCategory": "LossType",
            "pyKeyString": "DSFA",
            "pyRowNumber": "7"
        },
        {

            "pyActualValue": "Damage to my SLA (single living accommodation)",
            "pyCategory": "LossType",
            "pyKeyString": "DSLA",
            "pyRowNumber": "6"
        },
        {

            "pyActualValue": "Fire",
            "pyCategory": "LossType",
            "pyKeyString": "FI",
            "pyRowNumber": "4"
        },
        {

            "pyActualValue": "Accidental Loss",
            "pyCategory": "LossType",
            "pyKeyString": "LO",
            "pyRowNumber": "2"
        },
        {

            "pyActualValue": "Other",
            "pyCategory": "LossType",
            "pyKeyString": "OTH",
            "pyRowNumber": "8"
        },
        {

            "pyActualValue": "Theft",
            "pyCategory": "LossType",
            "pyKeyString": "TH",
            "pyRowNumber": "1"
        },
        {

            "pyActualValue": "Water Damage",
            "pyCategory": "LossType",
            "pyKeyString": "WD",
            "pyRowNumber": "5"
        },
        {

            "pyActualValue": "Military Kit Contents and Personal Possessions",
            "pyCategory": "Product",
            "pyKeyString": "MKCPP",
            "pyRowNumber": "1"
        },
        {

            "pyActualValue": "Dependent",
            "pyCategory": "Relationship",
            "pyKeyString": "DP",
            "pyRowNumber": "3"
        },
        {

            "pyActualValue": "Policyholder",
            "pyCategory": "Relationship",
            "pyKeyString": "PH",
            "pyRowNumber": "1"
        },
        {

            "pyActualValue": "Spouse",
            "pyCategory": "Relationship",
            "pyKeyString": "SP",
            "pyRowNumber": "2"
        }
    ];

export function mockGetDataAsync(
  dataPage: string,
  _context: unknown,
  parameters: Record<string, string>
): Promise<{ data: LovItem[] | CountryItem[] }> {
  if (dataPage === 'D_LOVList') {
    console.log('lov_da',LOV_DATA)
    const category = parameters?.Category ?? '';
    return Promise.resolve({
      data: category? LOV_DATA.filter(item => item.pyCategory === category) : LOV_DATA
    });
  }
  else if(dataPage === 'D_CountryList'){
    return Promise.resolve({
      data: countriesData.data as CountryItem[]
    });
  }
  return Promise.resolve({ data: [] });
}
