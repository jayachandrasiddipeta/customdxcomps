export interface UploadedAttachment {
  id: string;
  name: string;
  size: number; // bytes
  docType: string;
  docTypeLabel?: string;
  otherDocType?: string;
}

export interface ClaimItem {
   id: string;
  itemType: string;
  otherItemType?: string;
  datePurchased: string;
  itemDescription: string;
  purchasePrice: string;
  claimedAmount: string;
}

export interface ClaimFormData {
  // Step 1: Your Details
  firstName: string;
  otherLossType?: string;

  lossLocationType: string
  relationship: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  phoneDialingCode: string;
  policyNumber: string;
  membershipNumber: string;
  serviceNumber: string;
  schemeOrProduct: string;

  // Step 2: What Happened
  dateOfLoss: string;
  theftReported?: string;
  crimeReferenceNumber?: string;

  lossType: string;
  causeOfLoss: string;
  lossCountry: string;
  lossAddressLine1: string;
  lossAddressLine2: string;
  lossCity: string;
  lossPostalCode: string;
  description: string;

  // Step 3: Items Affected
  items: ClaimItem[];
  // itemType: string;
  // otherItemType: string;
  // datePurchased: string;
  // itemDescription: string;
  // purchasePrice: string;
  // claimedAmount: string;
  policyCountry: string;
  policyAddressLine1: string;
  policyAddressLine2: string;
  policyCity: string;
  policyPostalCode: string;

  // Step 4: Supporting Evidence
  hasUserConfirmed: boolean;
  attachments: UploadedAttachment[];

  // Step 5: Review declarations
  fraudPreventionNotice: boolean;
  claimAccuracyConfirmation: boolean;
}

export type ClaimFormErrors = Partial<Record<keyof ClaimFormData, string>>;
