import styled, { createGlobalStyle } from 'styled-components';
import { baseFormStyles } from './styles/baseStyles';

export const ClaimFormGlobalStyles = createGlobalStyle`
  .claim-form__discard-modal {
    padding: 1rem;
    font-family: var(--pega-font-family, 'Open Sans', Arial, sans-serif);
  }

  .claim-form__discard-modal-text {
    margin: 0 0 1rem;
    color: #1f2937;
    font-size: 0.95rem;
  }

  .claim-form__discard-modal-actions {
    display: flex;
    justify-content: space-between;
    align-items: center;
    width: 100%;
    gap: 1.5rem;
  }

  .claim-form__discard-modal .claim-form__button {
    border-radius: 4px !important;
    min-width: 140px;
    font-weight: 600 !important;
    border: 1px solid transparent;
    padding: 0.7rem 1.25rem;
    cursor: pointer;
    font-size: 1rem;
    line-height: 1;
    transition: background-color 0.2s ease, border-color 0.2s ease;
  }

  .claim-form__discard-modal .claim-form__button--cancel {
    background: #b91c1c !important;
    color: #ffffff !important;
    border-color: #b91c1c !important;
  }

  .claim-form__discard-modal .claim-form__button--cancel:hover:not(:disabled) {
    background: #991b1b !important;
    border-color: #991b1b !important;
  }

  .claim-form__discard-modal .claim-form__button--secondary {
    background: #ffffff !important;
    color: #1a3d6b !important;
    border-color: #1a3d6b !important;
  }

  .claim-form__discard-modal .claim-form__button--secondary:hover:not(:disabled) {
    background: #f0f4fa !important;
  }
`;

export default styled.div`
  height: 100%;
  display: flex;
  flex-direction: column;
  ${baseFormStyles}
`;
