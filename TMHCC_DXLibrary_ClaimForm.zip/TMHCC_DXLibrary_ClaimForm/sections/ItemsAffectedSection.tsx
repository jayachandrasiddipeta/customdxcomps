import type { ClaimFormData, ClaimFormErrors } from '../types';
import { useState } from 'react';
import InfoIcon from './InfoIcon';
import type { ListOption } from '../utils/listValuesUtils';
import type { LocalizationMap } from '../utils/useLocalization';

interface ItemsAffectedSectionProps {
  formData: ClaimFormData;
  errors: ClaimFormErrors;
  onFieldChange: (field: keyof ClaimFormData, value: string) => void;
  onFieldBlur: (field: keyof ClaimFormData) => void;
  itemTypeOptions: ListOption[];
  l: LocalizationMap;
}

function ItemsAffectedSection({ formData, errors, onFieldChange, onFieldBlur, itemTypeOptions, l }: ItemsAffectedSectionProps) {
   const [showInfo, setShowInfo] = useState(false);
  return (
    <section className='claim-form__section'>
      <h3 className='claim-form__section-title claim-form__title-with-icon'>
        <span className='claim-form__section-index'>3</span>
        {l['Items Affected']}
        <button
          type="button"
          className="claim-form__info-icon"
          onClick={() => setShowInfo(prev => !prev)}
          aria-label={showInfo ? 'Hide info' : 'Show info'}
        >
          <InfoIcon />
        </button>
      </h3>
         {showInfo && (
  <div className="claim-form__info-box">

    {/* ✅ LEFT SIDE */}
    <div className="claim-form__info-left">

      {/* ✅ ICON */}
      <div className="claim-form__info-box-icon">
        <InfoIcon />
      </div>

      {/* ✅ TEXT */}
      <div className="claim-form__info-content">
        {l['ItemsAffectedInstruction']}
      </div>

    </div>

    {/* ✅ CLOSE BUTTON (RIGHT) */}
    <button
      type="button"
      className="claim-form__info-close"
      onClick={() => setShowInfo(false)}
    >
      ×
    </button>

  </div>
)}
       <div className="claim-form__group claim-form__field--full">
    <div className='claim-form__grid'>

  <label className='claim-form__field'>
    <span>{l['Item Type']} <span className='claim-form__required-star'>*</span></span>
    <select
      required
      value={formData.itemType}
      onChange={e => onFieldChange('itemType', e.target.value)}
      onBlur={() => onFieldBlur('itemType')}
    >
      <option value=''>{l['SelectOptionPH']}</option>
      {itemTypeOptions.map(opt => (
        <option key={opt.key} value={opt.key}>{opt.label}</option>
      ))}
    </select>
    {errors.itemType && <small className='claim-form__error' role='alert'>{errors.itemType}</small>}
  </label>

  <label className='claim-form__field'>
    <span>{l['Claimed Amount']} (£) <span className='claim-form__required-star'>*</span></span>
    <input
      type='text'
      inputMode='decimal'
      value={formData.claimedAmount}
      onChange={e => {
        const filtered = e.target.value.replace(/[^\d.]/g, '').replace(/(\..*)\./g, '$1');
        onFieldChange('claimedAmount', filtered);
      }}
      onBlur={() => onFieldBlur('claimedAmount')}
      placeholder={l['AmountPH']}
    />
    {errors.claimedAmount && <small className='claim-form__error' role='alert'>{errors.claimedAmount}</small>}
  </label>

  <label className='claim-form__field claim-form__field--full'>
    <span>{l['Item Description']} <span className='claim-form__required-star'>*</span>
    <span><small className='claim-form_hint'>&ensp;({l['HintItemDescriptionLength']})</small></span>
    </span>
    <textarea
      rows={4}
      placeholder={l['ItemDescPH']}
      value={formData.itemDescription}
      onBlur={() => onFieldBlur('itemDescription')}
      onChange={e => onFieldChange('itemDescription', e.target.value)}
      maxLength={l['ItemDescriptionMaxLength']}
    />
    <div className="claim-form_field-footer">
      <span>{errors.itemDescription && <small className="claim-form__error" role="alert">{errors.itemDescription}</small>}</span>
      <small className={`claim-form_char-counter${formData.itemDescription.length >= l['CharCounterWarnThreshold'] ? ' claim-form_char-counter-warn' : ''}`}>
        {formData.itemDescription.length} / {l['ItemDescriptionMaxLength']}
      </small>
    </div>
  </label>

  <label className='claim-form__field'>
    <span>{l['Purchase Price']} (£) <span className='claim-form__required-star'>*</span></span>
    <input
      type='text'
      inputMode='decimal'
      value={formData.purchasePrice}
      onChange={e => {
        const filtered = e.target.value.replace(/[^\d.]/g, '').replace(/(\..*)\./g, '$1');
        onFieldChange('purchasePrice', filtered);
      }}
      onBlur={() => onFieldBlur('purchasePrice')}
      placeholder={l['AmountPH']}
    />
    {errors.purchasePrice && <small className='claim-form__error' role='alert'>{errors.purchasePrice}</small>}
  </label>

  <label className='claim-form__field'>
    <span>{l['Date Purchased']} <span className='claim-form__required-star'>*</span></span>
    <input
      type='date'
      required
      value={formData.datePurchased || ''}
      onChange={e => onFieldChange('datePurchased', e.target.value)}
      onBlur={() => onFieldBlur('datePurchased')}
    />
    {errors.datePurchased && <small className='claim-form__error' role='alert'>{errors.datePurchased}</small>}
  </label>

</div>
</div>
    </section>
  );
}

export default ItemsAffectedSection;
