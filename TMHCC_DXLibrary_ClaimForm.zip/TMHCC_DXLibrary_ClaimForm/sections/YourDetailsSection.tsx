
import type { ClaimFormData, ClaimFormErrors } from '../types';
import { useState } from 'react';
import InfoIcon from './InfoIcon';
import type { ListOption, CountryOption } from '../utils/listValuesUtils';
import type { LocalizationMap } from '../utils/useLocalization';

interface YourDetailsSectionProps {
  formData: ClaimFormData;
  errors: ClaimFormErrors;
  onFieldChange: (field: keyof ClaimFormData, value: string) => void;
  onFieldBlur: (field: keyof ClaimFormData) => void;
  productOptions: ListOption[];
  relationshipOptions: ListOption[];
  countryOptions: CountryOption[];
  l: LocalizationMap;
}

function YourDetailsSection({
  formData,
  errors,
  onFieldChange,
  onFieldBlur,
  productOptions,
  relationshipOptions,
  countryOptions,
  l
}: YourDetailsSectionProps) {
  const [showInfo, setShowInfo] = useState(false);
const postcodeLabelKey = `${formData.policyCountry}_PCLabel`;

const postcodeLabel =
  l[postcodeLabelKey as keyof typeof l] || l['Postal Code'];
const postcodePlaceholder = `Enter ${String(postcodeLabel).toLowerCase()}`;

  return (
    <section className="claim-form__section">

      {/* Main heading + info icon */}
      <h3 className="claim-form__section-title claim-form__section-title--primary claim-form__title-with-icon">
        <span className="claim-form__section-index">1</span>
        {l['Your Details']}
        <button
          type="button"
          className="claim-form__info-icon"
          onClick={() => setShowInfo(prev => !prev)}
          aria-label={showInfo ? 'Hide info' : 'Show info'}
        >
          <InfoIcon />
        </button>
      </h3>

      {/* Info box */}
      {showInfo && (
        <div className="claim-form__info-box">
          <div className="claim-form__info-left">
            <div className="claim-form__info-box-icon">
              <InfoIcon />
            </div>
            <div className="claim-form__info-content">
              {l['YourDetailsInstruction']}
            </div>
          </div>
          <button
            type="button"
            className="claim-form__info-close"
            onClick={() => setShowInfo(false)}
          >
            ×
          </button>
        </div>
      )}

      {/* Personal details fields */}
      <div className="claim-form__group">
        <div className="claim-form__grid">

          <label className="claim-form__field">
            <span>{l['Policy Number']} <span className="claim-form__required-star">*</span></span>
            <input
              value={formData.policyNumber}
              onChange={(e) => onFieldChange('policyNumber', e.target.value)}
              onBlur={() => onFieldBlur('policyNumber')}
              placeholder={l['PolicyNumberPH']}
            />
            {errors.policyNumber && (
              <small className="claim-form__error" role="alert">{errors.policyNumber}</small>
            )}
          </label>

          <label className="claim-form__field">
            <span>{l['Product']} <span className="claim-form__required-star">*</span></span>
            <select
              value={formData.schemeOrProduct}
              onChange={(e) => onFieldChange('schemeOrProduct', e.target.value)}
              onBlur={() => onFieldBlur('schemeOrProduct')}
            >
              <option value=''>{l['SelectOptionPH']}</option>
              {productOptions.map(opt => (
                <option key={opt.key} value={opt.key}>{opt.label}</option>
              ))}
            </select>
            {errors.schemeOrProduct && (
              <small className="claim-form__error" role="alert">{errors.schemeOrProduct}</small>
            )}
          </label>

          <label className="claim-form__field">
            <span>{l['Service Number']}</span>
            <input
              value={formData.serviceNumber}
              onChange={(e) => onFieldChange('serviceNumber', e.target.value)}
              onBlur={() => onFieldBlur('serviceNumber')}
              placeholder={l['ServiceNumberPH']}
            />
            {errors.serviceNumber && (
              <small className="claim-form__error" role="alert">{errors.serviceNumber}</small>
            )}
          </label>

          <label className="claim-form__field">
            <span>{l['Relationship to Policyholder']} <span className="claim-form__required-star">*</span></span>
            <select
              value={formData.relationship}
              onChange={(e) => onFieldChange('relationship', e.target.value)}
              onBlur={() => onFieldBlur('relationship')}
            >
              <option value=''>{l['SelectOptionPH']}</option>
              {relationshipOptions.map(opt => (
                <option key={opt.key} value={opt.key}>{opt.label}</option>
              ))}
            </select>
            {errors.relationship && (
              <small className="claim-form__error" role="alert">{errors.relationship}</small>
            )}
          </label>

          <label className="claim-form__field">
            <span>{l['First Name']} <span className="claim-form__required-star">*</span>
            <span><small className='claim-form_hint'>&ensp;({l['HintNameLength']})</small></span>
            </span>
            
            <input
              value={formData.firstName}
              onChange={(e) => onFieldChange('firstName', e.target.value)}
              onBlur={() => onFieldBlur('firstName')}
              placeholder={l['FNPH']}
              maxLength={l['NameMaxLength']}
            />
            {errors.firstName && (
              <small className="claim-form__error" role="alert">{errors.firstName}</small>
            )}
          </label>

          <label className="claim-form__field">
            <span>{l['Last Name']} <span className="claim-form__required-star">*</span>
            <span><small className='claim-form_hint'>&ensp;({l['HintNameLength']})</small></span>
            </span>
            <input
              value={formData.lastName}
              onChange={(e) => onFieldChange('lastName', e.target.value)}
              onBlur={() => onFieldBlur('lastName')}
              placeholder={l['LNPH']}
              maxLength={l['NameMaxLength']}
            />
            {errors.lastName && (
              <small className="claim-form__error" role="alert">{errors.lastName}</small>
            )}
          </label>

          <label className="claim-form__field">
            <span>{l['Email Address']} <span className="claim-form__required-star">*</span></span>
            <input
              type="email"
              value={formData.email}
              onChange={(e) => onFieldChange('email', e.target.value)}
              onBlur={() => onFieldBlur('email')}
              placeholder={l['EmailPH']}
            />
            {errors.email && (
              <small className="claim-form__error" role="alert">{errors.email}</small>
            )}
          </label>

          <label className="claim-form__field">
            <span>{l['Phone Number']} <span className="claim-form__required-star">*</span></span>
            <div className="claim-form__phone-group">
              <input
                className="claim-form__phone-input"
                type="tel"
                inputMode="numeric"
                maxLength={l['PhoneLength']}
                value={formData.phoneNumber}
                onChange={(e) => {
                  const digits = e.target.value.replace(/\D/g, '').slice(0, l['PhoneLength']);
                  onFieldChange('phoneNumber', digits);
                }}
                onBlur={() => onFieldBlur('phoneNumber')}
                placeholder={l['PNPH']}
              />
            </div>
            {errors.phoneNumber && (
              <small className="claim-form__error" role="alert">{errors.phoneNumber}</small>
            )}
          </label>

        </div>
      </div>

      {/* Policyholder Address — nested inside the main section */}
      <div className="claim-form__group claim-form__group--white">
        <h3 className="claim-form__section-title claim-form__section-title--secondary">
          {l['Policyholder Address']}
        </h3>

        <div className="claim-form__grid">

          <label className="claim-form__field claim-form__field--full">
            <span>{l['Country']} <span className="claim-form__required-star">*</span></span>
            <select
              value={formData.policyCountry}
   onChange={(e) => onFieldChange('policyCountry', e.target.value)}



              onBlur={() => onFieldBlur('policyCountry')}
            >
              <option value=''>{l['CountryPH']}</option>
              {countryOptions.map(opt => (
                <option key={opt.key} value={opt.key}>{opt.label}</option>
              ))}
            </select>
            {errors.policyCountry && (
              <small className="claim-form__error" role="alert">{errors.policyCountry}</small>
            )}
          </label>

          <label className="claim-form__field claim-form__field--full">
            <span>{l['Address Line 1']} <span className="claim-form__required-star">*</span></span>
            <input
              value={formData.policyAddressLine1}
              onChange={(e) => onFieldChange('policyAddressLine1', e.target.value)}
              onBlur={() => onFieldBlur('policyAddressLine1')}
              placeholder={l['StreetAddress1PH']}
            />
            {errors.policyAddressLine1 && (
              <small className="claim-form__error" role="alert">{errors.policyAddressLine1}</small>
            )}
          </label>

          <label className="claim-form__field claim-form__field--full">
            <span>{l['Address Line 2']}</span>
            <input
              value={formData.policyAddressLine2}
              onChange={(e) => onFieldChange('policyAddressLine2', e.target.value)}
              onBlur={() => onFieldBlur('policyAddressLine2')}
              placeholder={l['StreetAddress2PH']}
            />
            {errors.policyAddressLine2 && (
              <small className="claim-form__error" role="alert">{errors.policyAddressLine2}</small>
            )}
          </label>

          <label className="claim-form__field">
            <span>{l['CityTown']} <span className="claim-form__required-star">*</span></span>
            <input
              value={formData.policyCity}
              onChange={(e) => onFieldChange('policyCity', e.target.value)}
              onBlur={() => onFieldBlur('policyCity')}
              placeholder={l['CityTownPH']}
            />
            {errors.policyCity && (
              <small className="claim-form__error" role="alert">{errors.policyCity}</small>
            )}
          </label>

          <label className="claim-form__field">
            
           <span>{postcodeLabel} <span className="claim-form__required-star">*</span></span>
            <input
              inputMode='text'
              value={formData.policyPostalCode}
              onChange={(e) => onFieldChange('policyPostalCode', e.target.value.replace(/[^a-zA-Z0-9 ]/g, ''))}
              onBlur={() => onFieldBlur('policyPostalCode')}
              placeholder={postcodePlaceholder}
            />
            {errors.policyPostalCode && (
              <small className="claim-form__error" role="alert">{errors.policyPostalCode}</small>
            )}
          </label>

        </div>
      </div>

    </section>
  );
}

export default YourDetailsSection;
