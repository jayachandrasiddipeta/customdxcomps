import type { ClaimFormData } from '../types';

const COUNTRY_OPTIONS = ['', 'United Kingdom', 'United States', 'Australia', 'Canada'];

interface PolicyAddressSectionProps {
  formData: ClaimFormData;
  onFieldChange: (field: keyof ClaimFormData, value: string) => void;
}

function PolicyAddressSection({
  formData,
  onFieldChange
}: PolicyAddressSectionProps) {
  return (
    <section className="claim-form__section">
      <h3 className="claim-form__section-title claim-form__section-title--secondary">
        Policyholder Address
      </h3>

      <div className="claim-form__grid">

        <label className="claim-form__field claim-form__field--full">
          <span>Country *</span>
          <select
            value={formData.policyCountry}
            onChange={(e) => onFieldChange('policyCountry', e.target.value)}
          >
            {COUNTRY_OPTIONS.map(opt => (
              <option key={opt} value={opt}>
                {opt || 'Select...'}
              </option>
            ))}
          </select>
        </label>

        <label className="claim-form__field claim-form__field--full">
          <span>Address Line 1 *</span>
          <input
            value={formData.policyAddressLine1}
            onChange={(e) => onFieldChange('policyAddressLine1', e.target.value)}
          />
        </label>

        <label className="claim-form__field claim-form__field--full">
          <span>Address Line 2</span>
          <input
            value={formData.policyAddressLine2}
            onChange={(e) => onFieldChange('policyAddressLine2', e.target.value)}
          />
        </label>

        <label className="claim-form__field">
          <span>City / Town *</span>
          <input
            value={formData.policyCity}
            onChange={(e) => onFieldChange('policyCity', e.target.value)}
          />
        </label>

        <label className="claim-form__field">
          <span>Postcode *</span>
          <input
            value={formData.policyPostalCode}
            onChange={(e) => onFieldChange('policyPostalCode', e.target.value)}
          />
        </label>

      </div>
    </section>
  );
}

export default PolicyAddressSection;