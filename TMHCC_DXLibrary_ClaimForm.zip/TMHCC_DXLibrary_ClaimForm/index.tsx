import { useCallback, useEffect, useRef, useState } from 'react';
import {
  Icon,
  Progress,
  registerIcon,
  useModalManager,
  withConfiguration
} from '@pega/cosmos-react-core';
import * as check from '@pega/cosmos-react-core/lib/components/Icon/icons/check.icon';
// @ts-ignore
import * as information from '@pega/cosmos-react-core/lib/components/Icon/icons/information.icon';
// @ts-ignore
import * as trash from '@pega/cosmos-react-core/lib/components/Icon/icons/trash.icon';
// @ts-ignore
import * as pencil from '@pega/cosmos-react-core/lib/components/Icon/icons/pencil.icon';
// @ts-ignore
import * as caretUp from '@pega/cosmos-react-core/lib/components/Icon/icons/caret-up.icon';
// @ts-ignore
import * as caretDown from '@pega/cosmos-react-core/lib/components/Icon/icons/caret-down.icon';
// @ts-ignore
import * as plus from '@pega/cosmos-react-core/lib/components/Icon/icons/plus.icon';
// @ts-ignore
import * as cloudUp from '@pega/cosmos-react-core/lib/components/Icon/icons/cloud-up.icon';

import type { PConnFieldProps } from '../shared/PConnProps';

import ClaimConfirmationView from './sections/ClaimConfirmationView';
import DiscardChangesModal from './sections/DiscardChangesModal';
import ItemsAffectedSection from './sections/ItemsAffectedSection';
import ReviewSection from './sections/ReviewSection';
import SupportingEvidenceSection from './sections/SupportingEvidenceSection';
import WhatHappenedSection from './sections/WhatHappenedSection';
import YourDetailsSection from './sections/YourDetailsSection';
import StyledTmhccDxLibraryClaimFormWrapper, { ClaimFormGlobalStyles } from './styles';
import type { ClaimFormData, ClaimFormErrors, ClaimItem } from './types';
import {
  fetchAllListValues,
  fetchCountryList,
  LIST_CATEGORIES,
  type ListOption,
  type CountryOption
} from './utils/listValuesUtils';
import {
  clearAttachmentIdsInSession,
  saveAttachmentIdsInSession
} from './utils/attachmentSessionUtils';
import { uploadAttachments } from './utils/attachmentUploadUtils';
import { attachUploadedFilesToCase } from './utils/caseAttachmentUtils';
import {
  getClaimFieldValidationError,
  getClaimFormValidationErrors,
  getStepValidationErrors
} from './utils/claimFormValidation';
import { closeCurrentBrowserContext } from './utils/claimFormStateUtils';
import { useLocalization } from './utils/useLocalization';
import { createClaimCase } from './utils/claimUtils';
import { isValidEvidenceTypeText, validateFileTypes } from './utils/fileValidationUtils';
import { usePortalMask } from './utils/usePortalMask';

registerIcon(check);
registerIcon(information);
registerIcon(trash);
registerIcon(pencil);
registerIcon(caretUp);
registerIcon(caretDown);
registerIcon(plus);
registerIcon(cloudUp);

interface TmhccDxLibraryClaimFormProps extends PConnFieldProps {
  caseTypeID?: string;
  createClaimApiPath?: string;
}

const INITIAL_FORM_DATA: ClaimFormData = {
  items: [],
  theftReported: '',
  crimeReferenceNumber: '',
  firstName: '',
  lastName: '',
  email: '',
  phoneNumber: '',
  phoneDialingCode: 'GB',
  policyNumber: '',
  membershipNumber: '',
  serviceNumber: '',
  schemeOrProduct: '',
  relationship: '',
  spouseFirstName: '',
  spouseLastName: '',
  spouseEmail: '',
  spousePhoneNumber: '',
  dependentFirstName: '',
  dependentLastName: '',
  dependentDateOfBirth: '',
  dependentRelationship: '',
  dependentEmail: '',
  dependentPhoneNumber: '',
  authorisedFirstName: '',
  authorisedLastName: '',
  authorisedEmail: '',
  authorisedPhoneNumber: '',
  otherRelationshipDescription: '',
  otherPersonFirstName: '',
  otherPersonLastName: '',
  otherPersonEmail: '',
  otherPersonPhoneNumber: '',
  authorisationConfirmed: false,
  dateOfLoss: '',
  lossType: '',
  causeOfLoss: '',
  lossLocationType: 'PHA',
  lossCountry: '',
  lossAddressLine1: '',
  lossAddressLine2: '',
  lossCity: '',
  lossPostalCode: '',
  description: '',
  deploymentCountry: '',
  deploymentLocationName: '',
  policyCountry: 'GB',
  policyAddressLine1: '',
  policyAddressLine2: '',
  policyCity: '',
  policyPostalCode: '',
  hasUserConfirmed: false,
  attachments: [],
  declarationConsent: false
};

// Fields shown by one of the related-person sections (Spouse/Dependent/Authorised Person/
// Additional Details) — cleared whenever `relationship` changes so stale data/errors from a
// previously-selected section don't linger once a different section is shown.
const RELATED_PERSON_FIELDS: (keyof ClaimFormData)[] = [
  'spouseFirstName', 'spouseLastName', 'spouseEmail', 'spousePhoneNumber',
  'dependentFirstName', 'dependentLastName', 'dependentDateOfBirth', 'dependentRelationship',
  'dependentEmail', 'dependentPhoneNumber',
  'authorisedFirstName', 'authorisedLastName', 'authorisedEmail', 'authorisedPhoneNumber',
  'otherRelationshipDescription', 'otherPersonFirstName', 'otherPersonLastName',
  'otherPersonEmail', 'otherPersonPhoneNumber'
];

const getCaseDisplayId = (caseId: string): string => {
  const trimmedCaseId = caseId.trim();
  if (!trimmedCaseId) return '';
  const lastSpaceIndex = trimmedCaseId.lastIndexOf(' ');
  return lastSpaceIndex >= 0 ? trimmedCaseId.substring(lastSpaceIndex + 1) : trimmedCaseId;
};

function TmhccDxLibraryClaimForm(props: TmhccDxLibraryClaimFormProps) {
  const {
    caseTypeID = 'TMHCC-Claims-Work-Claim',
    createClaimApiPath = 'api/TrinityClaims/v1/create'
  } = props;
  const { getPConnect } = props;
  const l = useLocalization(getPConnect);

  const stepContentRef = useRef<HTMLDivElement>(null);

  const [formData, setFormData] = useState<ClaimFormData>(INITIAL_FORM_DATA);
  const [errors, setErrors] = useState<ClaimFormErrors>({});
  const [submitError, setSubmitError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [showConfirmationView, setShowConfirmationView] = useState(false);
  const [createdCaseId, setCreatedCaseId] = useState('');
  const [currentStep, setCurrentStep] = useState(1);
  const { create } = useModalManager();
  const isMasked = usePortalMask();
  const [listValues, setListValues] = useState<Record<string, ListOption[]>>({});
  const [countryOptions, setCountryOptions] = useState<CountryOption[]>([]);
  const [attachmentErrors, setAttachmentErrors] = useState<
    Record<string, { docType?: string; otherDocType?: string }>
  >({});
  const [heroImageUrl, setHeroImageUrl] = useState('');

  useEffect(() => {
    const imageKey = String(l['HeroImageKey']).trim();
    if (!imageKey) return;
    let isActive = true;

    const loadHeroImage = async () => {
      const assetLoader =
        (window as any).PCore?.getAssetLoader?.() ??
        (window as any).AssetLoader ??
        (window as any).PCore?.AssetLoader;
      if (!assetLoader?.getSvcImageUrl) return;
      try {
        const result: string | Blob = await assetLoader.getSvcImageUrl(imageKey);
        if (!isActive) return;
        const url = result instanceof Blob ? window.URL.createObjectURL(result) : result;
        setHeroImageUrl(url);
      } catch {
        console.log('image unavailable — hero panel renders without background');
      }
    };

    void loadHeroImage();

    return () => {
      isActive = false;
    };
  }, [l['HeroImageKey']]);

  const getLabel = useCallback(
    (category: string, key: string): string => {
      if (!key?.trim()) return key;
      const optionMap: Record<string, ListOption[]> = {
        product: listValues[LIST_CATEGORIES.PRODUCT] ?? [],
        relationship: listValues[LIST_CATEGORIES.RELATIONSHIP] ?? [],
        lossType: listValues[LIST_CATEGORIES.LOSS_TYPE] ?? [],
        lossLocation: listValues[LIST_CATEGORIES.LOSS_LOCATION] ?? [],
        itemType: listValues[LIST_CATEGORIES.ITEM_TYPE] ?? [],
        itemCoverType: listValues[LIST_CATEGORIES.ITEM_COVER_TYPE] ?? [],
        yesNo: listValues[LIST_CATEGORIES.GENERIC_YES_NO] ?? [],
        country: countryOptions
      };
      return optionMap[category]?.find(o => o.key === key)?.label ?? key;
    },
    [listValues, countryOptions]
  );

  useEffect(() => {
    fetchAllListValues(String(l['LovDataPageName'])).then(setListValues);
    fetchCountryList(String(l['CountriesDataPageName'])).then(opts => {
      setCountryOptions(opts);
      setFormData(prev => {
        const gbExists = opts.some(o => o.key === 'GB' && o.dialingCode);
        if (gbExists && prev.phoneDialingCode === 'GB') return prev;
        if (gbExists) return { ...prev, phoneDialingCode: 'GB' };
        const first = opts.find(o => o.dialingCode);
        return first ? { ...prev, phoneDialingCode: first.key } : prev;
      });
    });
  }, [l]);

  useEffect(() => {
    if (stepContentRef.current) {
      stepContentRef.current.scrollTop = 0;
    }
    stepContentRef.current?.focus({ preventScroll: true });
  }, [currentStep]);

  const handleFieldChange = (field: keyof ClaimFormData, value: string | boolean) => {
    setFormData(prev => ({ ...prev, [field]: value }));

    if (field === 'lossType') {
      setFormData(prev => ({ ...prev, description: '' }));
      setErrors(prev => ({
        ...prev,
        lossType: '',
        description: '',
        theftReported: '',
        crimeReferenceNumber: '',
        otherLossType: ''
      }));
    } else if (field === 'policyCountry') {
      setFormData(prev => ({
        ...prev,
        policyPostalCode: '',
        policyCity: '',
        policyAddressLine1: ''
      }));
      setErrors(prev => ({
        ...prev,
        policyCountry: '',
        policyPostalCode: '',
        policyCity: '',
        policyAddressLine1: ''
      }));
    } else if (field === 'lossCountry') {
      setFormData(prev => ({ ...prev, lossPostalCode: '', lossCity: '', lossAddressLine1: '' }));
      setErrors(prev => ({
        ...prev,
        lossCountry: '',
        lossPostalCode: '',
        lossCity: '',
        lossAddressLine1: ''
      }));
    } else if (field === 'lossLocationType') {
      setFormData(prev => ({ ...prev, deploymentCountry: '', deploymentLocationName: '' }));
      setErrors(prev => ({
        ...prev,
        lossLocationType: '',
        deploymentCountry: ''
      }));
    } else if (field === 'relationship') {
      setFormData(prev => ({
        ...prev,
        authorisationConfirmed: false,
        ...Object.fromEntries(RELATED_PERSON_FIELDS.map(f => [f, '']))
      }));
      setErrors(prev => ({
        ...prev,
        relationship: '',
        authorisationConfirmed: '',
        ...Object.fromEntries(RELATED_PERSON_FIELDS.map(f => [f, '']))
      }));
    } else {
      setErrors(prev => ({ ...prev, [field]: '' }));
    }
    setSubmitError('');
  };

  const handleFieldBlur = (field: keyof ClaimFormData) => {
    const fieldError = getClaimFieldValidationError(field, formData, l);
    setErrors(prev => ({ ...prev, [field]: fieldError }));
  };

  const handleFileUpload = async (files: File[]) => {
    setSubmitError('');

    const MAX_FILES = l['MaxAttachmentsCount'];

    const currentCount = formData.attachments.length;
    const remainingSlots = MAX_FILES - currentCount;

    // ✅ BLOCK if already max
    if (remainingSlots <= 0) {
      setSubmitError(l['MaxAttachmentsReached']);
      return;
    }

    // ✅ LIMIT files to allowed number
    const filesToProcess = files.slice(0, remainingSlots);

    const overLimit = files.length > remainingSlots;
    const { valid, rejectedNames, errorMessage } = await validateFileTypes(
      filesToProcess,
      String(l['AllowedFileTypesLabel']),
      String(l['AllowedFileExtensions'])
    );

    if (overLimit && rejectedNames.length > 0) {
      setSubmitError(`${String(l['MaxAttachmentsReached'])} ${errorMessage}`);
    } else if (overLimit) {
      setSubmitError(String(l['MaxAttachmentsReached']));
    } else if (rejectedNames.length > 0) {
      setSubmitError(errorMessage);
    }
    if (valid.length === 0) return;

    setIsUploading(true);

    const uploadResponses = await uploadAttachments(valid);

    const successfulUploads = uploadResponses
      .filter(r => r.success && r.attachment)
      .map(r => r.attachment!);

    const failedUploads = uploadResponses.filter(r => !r.success);

    if (successfulUploads.length > 0) {
      setFormData(prev => {
        const combined = [...prev.attachments, ...successfulUploads];

        const deduped = combined.filter((a, i, all) => i === all.findIndex(x => x.id === a.id));

        saveAttachmentIdsInSession(deduped.map(a => a.id));

        return { ...prev, attachments: deduped };
      });
    }

    if (failedUploads.length > 0) {
      setSubmitError(failedUploads[0]?.message || 'Some files failed to upload');
    }

    setIsUploading(false);
  };

  const handleDeleteAttachment = (attachmentId: string) => {
    setFormData(prev => {
      const updated = prev.attachments.filter(a => a.id !== attachmentId);
      saveAttachmentIdsInSession(updated.map(a => a.id));
      if (updated.length < l['MaxAttachmentsCount']) setSubmitError('');
      return { ...prev, attachments: updated };
    });
  };

  const handleDocTypeChange = (attachmentId: string, docType: string) => {
    const docTypeLabel = (listValues[LIST_CATEGORIES.EVIDENCE_TYPE] ?? []).find(
      o => o.key === docType
    )?.label;
    setFormData(prev => ({
      ...prev,
      attachments: prev.attachments.map(a =>
        a.id === attachmentId
          ? {
              ...a,
              docType,
              docTypeLabel: docType !== 'Other' ? docTypeLabel : a.docTypeLabel,
              otherDocType: docType !== 'Other' ? '' : a.otherDocType
            }
          : a
      )
    }));
    setAttachmentErrors(prev => {
      if (!prev[attachmentId]) return prev;
      const next = { ...prev };
      delete next[attachmentId];
      return next;
    });
  };

  const handleOtherDocTypeChange = (attachmentId: string, otherDocType: string) => {
    setFormData(prev => ({
      ...prev,
      attachments: prev.attachments.map(a => (a.id === attachmentId ? { ...a, otherDocType } : a))
    }));
    if (otherDocType.trim()) {
      setAttachmentErrors(prev => {
        const next = { ...prev };
        if (!otherDocType.trim()) return next;
        const error = !isValidEvidenceTypeText(
          otherDocType,
          String(l['EvidenceTypeAllowedPattern'])
        )
          ? String(l['ErrOtherEvidenceTypeInvalid'])
          : undefined;
        if (error) {
          next[attachmentId] = { ...next[attachmentId], otherDocType: error };
        } else if (next[attachmentId]) {
          delete next[attachmentId].otherDocType;
          if (!Object.keys(next[attachmentId]).length) delete next[attachmentId];
        }
        return next;
      });
    }
  };

  const handleNext = () => {
    const stepErrors = getStepValidationErrors(currentStep, formData, l);
    setErrors(stepErrors);

    if (Object.values(stepErrors).some(Boolean)) return;

    if (currentStep === 4) {
      const attErrors: Record<string, { docType?: string; otherDocType?: string }> = {};
      formData.attachments.forEach(a => {
        const e: { docType?: string; otherDocType?: string } = {};
        if (!a.docType) e.docType = l['ErrEvidenceTypeRequired'];
        if (a.docType === 'Other' && !a.otherDocType?.trim())
          e.otherDocType = l['ErrEvidenceTypeSpecify'];
        if (
          a.docType === 'Other' &&
          !isValidEvidenceTypeText(a.otherDocType!, String(l['EvidenceTypeAllowedPattern']))
        )
          e.otherDocType = l['ErrOtherEvidenceTypeInvalid'];
        if (Object.keys(e).length > 0) attErrors[a.id] = e;
      });
      if (Object.keys(attErrors).length > 0) {
        setAttachmentErrors(attErrors);
        return;
      }
      setAttachmentErrors({});
    }

    setErrors({});
    setSubmitError('');
    setCurrentStep(prev => (prev < 5 ? prev + 1 : prev));
  };

  const handleSubmit = async () => {
    const validationErrors = getClaimFormValidationErrors(formData, l);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setCurrentStep(1);
      return;
    }

    setIsSubmitting(true);
    setSubmitError('');

    const response = await createClaimCase({ createClaimApiPath, caseTypeID, formData });

    if (response.success) {
      const fullCaseId = response.ID || '';
      const attachResponse = await attachUploadedFilesToCase(fullCaseId, formData.attachments);
      if (!attachResponse.success) {
        setSubmitError(attachResponse.message || 'Case created but file attachment failed');
      }
      setCreatedCaseId(getCaseDisplayId(fullCaseId));
      setShowConfirmationView(true);
      setFormData(INITIAL_FORM_DATA);
      setErrors({});
      clearAttachmentIdsInSession();
    } else {
      setSubmitError(response.message || 'Failed to create claim case.');
    }

    setIsSubmitting(false);
  };

  const handleDiscardAndClose = () => {
    setFormData(INITIAL_FORM_DATA);
    setErrors({});
    setSubmitError('');
    setCurrentStep(1);
    clearAttachmentIdsInSession();
    closeCurrentBrowserContext();
  };
  const handleItemsChange = (items: ClaimItem[]) => {
    setFormData(prev => ({
      ...prev,
      items
    }));
  };
  const handleCancel = () => {
    create(
      () => <DiscardChangesModal onDiscard={handleDiscardAndClose} l={l} />,
      {},
      { dismissible: true }
    );
  };
  const stepDefinitions: Array<{ label: string; name: string }> = [
    { label: l['Step 1'], name: l['Your Details'] },
    { label: l['Step 2'], name: l['What Happened'] },
    { label: l['Step 3'], name: l['Items Affected'] },
    { label: l['Step 4'], name: l['Evidence'] }
  ];

  const renderImageOverlay = () => (
    <div className='claim-form__image-overlay'>
      <div className='claim-form__image-content'>
        <h1 className='claim-form__image-title'>
          {l['HelpTextHeaderPrefix'].toUpperCase()}
          <span className='claim-form__image-highlight'>
            {l['HelpTextHeaderHighlight'].toUpperCase()}
          </span>
        </h1>
        <p className='claim-form__image-subtext'>{l['HelpDescription']}</p>

        {/* ✅ Divider below subtext */}
        <div className='claim-form__image-divider' />

        <div className='claim-form__image-contact'>
          <div>
            <strong>{l['HelpTelephoneKey']}</strong>
            <p>{l['HelpTelephoneValue']}</p>
          </div>

          <div>
            <strong>{l['HelpEmailKey']}</strong>
            <p>{l['HelpEmailValue']}</p>
          </div>

          <div>
            <strong>{l['HelpOverseasKey']}</strong>
            <p>{l['HelpOverseasValue']}</p>
          </div>
        </div>

        <div className='claim-form__image-hours'>
          <strong>{l['HelpSupportHoursKey']}</strong>
          <span>{l['HelpSupportHoursValue']}</span>
        </div>
      </div>
    </div>
  );

  const renderStepNav = () => (
    <div className='claim-form__step-nav'>
      {stepDefinitions.map(({ label, name }, i) => {
        const step = i + 1;
        const isComplete = currentStep > step;
        const isCurrent = currentStep === step;
        let stateClass = 'claim-form__step-card--upcoming';
        if (isComplete) stateClass = 'claim-form__step-card--complete';
        else if (isCurrent) stateClass = 'claim-form__step-card--current';
        return (
          <div
            key={step}
            className={`claim-form__step-card ${stateClass}${isComplete ? ' claim-form__step-card--clickable' : ''}`}
            role={isComplete ? 'button' : undefined}
            tabIndex={isComplete ? 0 : undefined}
            aria-label={isComplete ? `Go back to step ${step}: ${name}` : undefined}
            aria-current={isCurrent ? 'step' : undefined}
          >
            <div className='claim-form__step-card-info'>
              <span className='claim-form__step-card-label'>{label}</span>
              <span className='claim-form__step-card-name'>{name}</span>
            </div>
            <div className='claim-form__step-card-icon'>
              {isComplete ? <Icon name='check' size='s' /> : ''}
            </div>
          </div>
        );
      })}
    </div>
  );

  const renderActions = () => {
    const isReview = currentStep === 5;
    // const isFirst = currentStep === 1;

    const leftButton = (
      <div className='claim-form__actions-left'>
        <button
          type='button'
          className='claim-form__button claim-form__button--secondary'
          onClick={handleCancel}
          disabled={isSubmitting || isUploading}
        >
          {l['Cancel']}
        </button>
      </div>
    );

    const rightButton = isReview ? (
      <button
        type='button'
        className='claim-form__button claim-form__button--primary'
        onClick={handleSubmit}
        disabled={
          isSubmitting ||
          isUploading ||
          !formData.declarationConsent
        }
      >
        {isSubmitting ? (
          <span className='claim-form__processing-content'>
            <Progress />
            <span>{l['Processing...']}</span>
          </span>
        ) : (
          l['Submit']
        )}
      </button>
    ) : (
      <button
        type='button'
        className='claim-form__button claim-form__button--primary'
        onClick={handleNext}
        disabled={isUploading || (currentStep === 3 && formData.items.length === 0)}
      >
        {l['Continue']}
      </button>
    );

    return (
      <div className='claim-form__actions'>
        {leftButton}
        {rightButton}
      </div>
    );
  };

  const renderCurrentSection = () => {
    const actions = (
      <>
        {submitError && (
          <div className='claim-form__feedback claim-form__feedback--error claim-form__section-error' role='alert'>
            {submitError}
          </div>
        )}
        {renderActions()}
      </>
    );

    if (currentStep === 5) {
      return (
        <ReviewSection
          formData={formData}
          setCurrentStep={setCurrentStep}
          onFieldChange={handleFieldChange}
          l={l}
          getLabel={getLabel}
          actions={actions}
        />
      );
    }

    switch (currentStep) {
      case 1:
        return (
          <YourDetailsSection
            formData={formData}
            errors={errors}
            onFieldChange={(f, v) => handleFieldChange(f, v as string)}
            onFieldBlur={handleFieldBlur}
            productOptions={listValues[LIST_CATEGORIES.PRODUCT] ?? []}
            relationshipOptions={listValues[LIST_CATEGORIES.RELATIONSHIP] ?? []}
            countryOptions={countryOptions}
            l={l}
            actions={actions}
          />
        );
      case 2:
        return (
          <WhatHappenedSection
            formData={formData}
            errors={errors}
            onFieldChange={(f, v) => handleFieldChange(f, v)}
            onFieldBlur={handleFieldBlur}
            lossTypeOptions={listValues[LIST_CATEGORIES.LOSS_TYPE] ?? []}
            lossLocationOptions={listValues[LIST_CATEGORIES.LOSS_LOCATION] ?? []}
            theftReportedOptions={listValues[LIST_CATEGORIES.GENERIC_YES_NO] ?? []}
            countryOptions={countryOptions}
            l={l}
            actions={actions}
          />
        );
      case 3:
        return (
          <ItemsAffectedSection
            formData={formData}
            onItemsChange={handleItemsChange}
            itemTypeOptions={listValues[LIST_CATEGORIES.ITEM_TYPE] ?? []}
            itemCoverTypeOptions={listValues[LIST_CATEGORIES.ITEM_COVER_TYPE] ?? []}
            l={l}
            actions={actions}
          />
        );
      case 4:
        return (
          <SupportingEvidenceSection
            formData={formData}
            errors={errors}
            isUploading={isUploading}
            onFileUpload={handleFileUpload}
            onDeleteAttachment={handleDeleteAttachment}
            onDocTypeChange={handleDocTypeChange}
            onOtherDocTypeChange={handleOtherDocTypeChange}
            evidenceTypeOptions={listValues[LIST_CATEGORIES.EVIDENCE_TYPE] ?? []}
            attachmentErrors={attachmentErrors}
            l={l}
            actions={actions}
          />
        );
      default:
        return null;
    }
  };

  const portalMaskOverlay = isMasked && (
    <div className='claim-form__portal-mask' aria-hidden='true'>
      <Progress />
    </div>
  );

  const imageStyle = heroImageUrl ? { backgroundImage: `url(${heroImageUrl})` } : undefined;

  if (showConfirmationView) {
    return (
      <>
        {portalMaskOverlay}
        <ClaimFormGlobalStyles />
        <StyledTmhccDxLibraryClaimFormWrapper id='tmhcc-claim-form-root'>
          <div className='claim-form-page'>
            <div className='claim-form-page__image' style={imageStyle}>
              {renderImageOverlay()}
            </div>
            <div className='claim-form-page__panel'>
              <div className='claim-form'>
                <ClaimConfirmationView
                  caseId={createdCaseId}
                  confirmationDataPageName={String(l['ConfirmationDataPageName'])}
                  onClose={() => {
                    setShowConfirmationView(false);
                    setCurrentStep(1);
                  }}
                  l={l}
                />
              </div>
            </div>
          </div>
        </StyledTmhccDxLibraryClaimFormWrapper>
      </>
    );
  }

  return (
    <>
      {portalMaskOverlay}
      <ClaimFormGlobalStyles />
      <StyledTmhccDxLibraryClaimFormWrapper id='tmhcc-claim-form-root'>
        <div className='claim-form-page'>
          <div className='claim-form-page__image' style={imageStyle}>
            {renderImageOverlay()}
          </div>
          <div className='claim-form-page__panel'>
            {renderStepNav()}
            <div className='claim-form' ref={stepContentRef} tabIndex={-1}>
              {renderCurrentSection()}
            </div>
          </div>
        </div>
      </StyledTmhccDxLibraryClaimFormWrapper>
    </>
  );
}

export default withConfiguration(TmhccDxLibraryClaimForm);
