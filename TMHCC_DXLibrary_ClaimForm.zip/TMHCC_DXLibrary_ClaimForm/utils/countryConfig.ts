export const POSTCODE_LABEL_MAP: Record<string, string> = {
  GB: 'UK_PCLabel',
  US: 'US_PCLabel',
  CA: 'CA_PCLabel',
  JP: 'JP_PCLabel'
};

export const getPostcodeLabelKey = (country: string): string => {
  return POSTCODE_LABEL_MAP[country] || 'Postal Code';
};
