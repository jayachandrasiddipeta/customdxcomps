import type { ClaimFormData, ClaimFormErrors } from '../types';
import type { LocalizationMap } from './useLocalization';

type FieldValidator = (value: string, formData: ClaimFormData) => string;

// module-level cache — re-builds only when l identity changes
let _cachedL: LocalizationMap | undefined;
let _cachedValidators: Partial<Record<keyof ClaimFormData, FieldValidator>> | undefined;

// ── Validator factories (module-level so their branches don't count against buildValidators) ──

const req = (l: LocalizationMap, key: keyof LocalizationMap): FieldValidator =>
  (v) => v ? '' : String(l[key]);

const notFuture = (l: LocalizationMap, reqKey: keyof LocalizationMap, futureKey: keyof LocalizationMap): FieldValidator =>
  (v) => {
    if (!v) return String(l[reqKey]);
    const today = new Date().toISOString().slice(0, 10);
    return v > today ? String(l[futureKey]) : '';
  };

const postalCodeFactory = (l: LocalizationMap, postalRx: RegExp) =>
  (country: string) =>
    (v: string): string => {
      const errKey = `${country}_PCErrMsg`;
      const errorMessage = String(l[errKey as keyof typeof l] || l['PCErrMsg']);
      if (!v) return errorMessage;
      const labelKey = `${country}_PCLabel`;
      const label = l[labelKey as keyof typeof l] || l['Postal Code'];
      return postalRx.test(v) ? '' : String(l['ErrPostalCodeInvalid']).replace('{1}', String(label));
    };

const minMax = (
  l: LocalizationMap,
  reqKey: keyof LocalizationMap,
  minKey: keyof LocalizationMap,
  maxKey: keyof LocalizationMap,
  min: number,
  max: number
): FieldValidator =>
  (v) => {
    if (!v) return String(l[reqKey]);
    if (v.length < min) return String(l[minKey]).replace('{1}', String(min));
    if (v.length > max) return String(l[maxKey]).replace('{1}', String(max));
    return '';
  };

const emailValidator = (l: LocalizationMap, emailRx: RegExp): FieldValidator =>
  (v) => {
    if (!v) return String(l['ErrEmailRequired']);
    return emailRx.test(v) ? '' : String(l['ErrEmailInvalid']);
  };

const phoneValidator = (l: LocalizationMap, phoneRx: RegExp, phoneLen: number | string): FieldValidator =>
  (v) => {
    if (!v) return String(l['ErrPhoneRequired']);
    return phoneRx.test(v) ? '' : String(l['ErrPhoneFormat']).replace('{1}', String(phoneLen));
  };

const policyNumberValidator = (l: LocalizationMap, policyRx: RegExp): FieldValidator =>
  (v) => {
    if (!v) return String(l['ErrPolicyNumberRequired']);
    return policyRx.test(v) ? '' : String(l['PolicyNumberFormatError']);
  };

const serviceNumberValidator = (l: LocalizationMap, serviceRx: RegExp): FieldValidator =>
  (v) => {
    if (!v) return '';
    return serviceRx.test(v) ? '' : String(l['ErrServiceNumberFormat']);
  };

const claimedAmountValidator = (l: LocalizationMap): FieldValidator =>
  (v, fd) => {
    if (!v) return String(l['ErrClaimedAmountRequired']);
    const claimed = parseFloat(v);
    const purchase = parseFloat(fd.purchasePrice);
    if (!isNaN(claimed) && !isNaN(purchase) && claimed > purchase) {
      return String(l['ErrClaimedAmountExceedsPurchase']);
    }
    return '';
  };

const datePurchasedValidator = (l: LocalizationMap): FieldValidator =>
  (v, fd) => {
    if (!v) return String(l['ErrDatePurchasedRequired']);
    const today = new Date().toISOString().slice(0, 10);
    if (v > today) return String(l['ErrDatePurchasedFuture']);
    if (fd.dateOfLoss && v > fd.dateOfLoss) return String(l['ErrDatePurchasedAfterLoss']).replace('{1}', fd.dateOfLoss);
    return '';
  };

const theftReportedValidator = (l: LocalizationMap): FieldValidator =>
  (v, fd) => {
    if (fd.lossType === 'TH' && !v) return l['ErrTheftReportedRequired'];
    return '';
  };

const crimeReferenceValidator = (l: LocalizationMap): FieldValidator =>
  (v, fd) => {
    if (fd.lossType === 'TH' && fd.theftReported === 'Yes' && !v) return l['ErrCrimeReferenceRequired'];
    return '';
  };

const consentValidator = (l: LocalizationMap): FieldValidator =>
  (_v, fd) => fd.hasUserConfirmed ? '' : String(l['ErrConsentRequired']);

// ── Assembles the validator map; complexity is low because all logic lives in the factories above ──

const buildValidators = (l: LocalizationMap): Partial<Record<keyof ClaimFormData, FieldValidator>> => {
  if (l === _cachedL && _cachedValidators) return _cachedValidators;
  _cachedL = l;

  const emailRx   = new RegExp(String(l['EmailPattern']));
  const postalRx  = new RegExp(String(l['PostalCodePattern']));
  const serviceRx = new RegExp(String(l['ServiceNumberPattern']));
  const policyRx  = new RegExp(String(l['PolicyNumberPattern']));
  const phoneLen  = l['PhoneLength'];
  const phoneRx   = new RegExp(`^\\d{${phoneLen}}$`);
  const postal    = postalCodeFactory(l, postalRx);

  _cachedValidators = {
    firstName:            minMax(l, 'ErrFirstNameRequired', 'ErrFNTooShort', 'ErrFNTooLong', l['NameMinLength'], l['NameMaxLength']),
    lastName:             minMax(l, 'ErrLastNameRequired', 'ErrLNTooShort', 'ErrLNTooLong', l['NameMinLength'], l['NameMaxLength']),
    policyNumber:         policyNumberValidator(l, policyRx),
    serviceNumber:        serviceNumberValidator(l, serviceRx),
    relationship:         req(l, 'ErrRelationshipRequired'),
    dateOfLoss:           notFuture(l, 'ErrDateOfLossRequired', 'ErrDateOfLossFuture'),
    lossType:             req(l, 'ErrLossTypeRequired'),
    lossCountry:          req(l, 'ErrCountryRequired'),
    lossAddressLine1:     req(l, 'ErrAddressLine1Required'),
    lossCity:             req(l, 'ErrCityRequired'),
    lossPostalCode:       (v, fd) => postal(fd.lossCountry)(v),
    description:          minMax(l, 'ErrDescriptionRequired', 'ErrDescriptionTooShort', 'ErrDescriptionTooLong', l['DescriptionMinLength'], l['DescriptionMaxLength']),
    itemType:             req(l, 'ErrItemTypeRequired'),
    purchasePrice:        req(l, 'ErrPurchasePriceRequired'),
    policyCountry:        req(l, 'ErrCountryRequired'),
    policyAddressLine1:   req(l, 'ErrAddressLine1Required'),
    policyCity:           req(l, 'ErrCityRequired'),
    policyPostalCode:     (v, fd) => postal(fd.policyCountry)(v),
    claimedAmount:        claimedAmountValidator(l),
    itemDescription:      minMax(l, 'ErrItemDescriptionRequired', 'ErrItemDescriptionTooShort', 'ErrItemDescriptionTooLong', l['ItemDescriptionMinLength'], l['ItemDescriptionMaxLength']),
    schemeOrProduct:      req(l, 'ErrProductRequired'),
    datePurchased:        datePurchasedValidator(l),
    theftReported:        theftReportedValidator(l),
    crimeReferenceNumber: crimeReferenceValidator(l),
    email:                emailValidator(l, emailRx),
    phoneNumber:          phoneValidator(l, phoneRx, phoneLen),
    hasUserConfirmed:     consentValidator(l),
  };
  return _cachedValidators!;
};

const STEP_FIELDS: Record<number, (keyof ClaimFormData)[]> = {
  1: [
    'firstName', 'lastName', 'email', 'phoneNumber', 'policyNumber', 'serviceNumber',
    'relationship', 'schemeOrProduct',
    'policyCountry', 'policyAddressLine1', 'policyCity', 'policyPostalCode'
  ],
  2: ['dateOfLoss', 'lossType', 'description'],
  3: ['itemType', 'purchasePrice', 'claimedAmount', 'itemDescription', 'datePurchased'],
  4: []
};

export const getClaimFieldValidationError = (
  field: keyof ClaimFormData,
  formData: ClaimFormData,
  l: LocalizationMap
): string => {
  const validators = buildValidators(l);
  const validator = validators[field];
  if (!validator) return '';
  const value = typeof formData[field] === 'string' ? (formData[field] as string).trim() : '';
  return validator(value, formData);
};

export const getStepValidationErrors = (
  step: number,
  formData: ClaimFormData,
  l: LocalizationMap
): ClaimFormErrors => {
  const errors: ClaimFormErrors = {};
  const fields = STEP_FIELDS[step] ?? [];

  fields.forEach(field => {
    const fieldError = getClaimFieldValidationError(field, formData, l);
    if (fieldError) errors[field] = fieldError;
  });

  if (step === 2) {
    if (!formData.lossType) {
      errors.lossType = l['ErrLossTypeRequired'];
    }
    if (formData.lossType === 'OTH' && !formData.otherLossType) {
      errors.otherLossType = l['ErrOtherLossTypeRequired'];
    }
    if (formData.lossType === 'TH') {
      if (!formData.theftReported) errors.theftReported = l['ErrTheftReportedRequired'];
      if (formData.theftReported === 'Yes' && !formData.crimeReferenceNumber) {
        errors.crimeReferenceNumber = l['ErrCrimeReferenceRequired'];
      }
    }
    if (!formData.lossLocationType) {
      errors.lossLocationType = l['ErrFieldRequired'];
    }
    if (formData.lossLocationType === 'DL') {
      if (!formData.lossCountry)      errors.lossCountry      = l['ErrCountryRequired'];
      if (!formData.lossAddressLine1) errors.lossAddressLine1 = l['ErrAddressLine1Required'];
      if (!formData.lossCity)         errors.lossCity         = l['ErrCityRequired'];
      if (!formData.lossPostalCode) {
        const errKey = `${formData.lossCountry}_PCErrMsg`;
        errors.lossPostalCode = String(l[errKey as keyof typeof l] || l['PCErrMsg']);
      }
    }
  }

  return errors;
};

export const getClaimFormValidationErrors = (
  formData: ClaimFormData,
  l: LocalizationMap
): ClaimFormErrors => {
  const errors: ClaimFormErrors = {};
  [1, 2, 3, 4].forEach(step => {
    Object.assign(errors, getStepValidationErrors(step, formData, l));
  });
  return errors;
};
