import type { ClaimFormData } from '../types';
import { fetchClientPublicIp } from './clientIpUtils';
import { extractPegaErrorMessage } from './pegaErrorUtils';

interface ClaimCaseOptions {
  /** Path for PCore.getRestClient().invokeCustomRestApi (e.g. api/TrinityClaims/v1/create). */
  createClaimApiPath: string;
  caseTypeID: string;
  formData: ClaimFormData;
}

interface ClaimCaseResponse {
  ID?: string;
  success: boolean;
  message?: string;
}

export const createClaimCase = async ({
  createClaimApiPath,
  caseTypeID,
  formData
}: ClaimCaseOptions): Promise<ClaimCaseResponse> => {
  try {
    const apiPath = createClaimApiPath.trim();
    if (!apiPath) {
      return {
        success: false,
        message: 'Create claim API path is not configured.'
      };
    }

    const remoteIp = await fetchClientPublicIp();

    const isPHA = formData.lossLocationType === 'PHA';
    const lossCity         = isPHA ? formData.policyCity         : formData.lossCity;
    const lossCountry      = isPHA ? formData.policyCountry      : formData.lossCountry;
    const lossPostalCode   = isPHA ? formData.policyPostalCode   : formData.lossPostalCode;
    const lossAddressLine1 = isPHA ? formData.policyAddressLine1 : formData.lossAddressLine1;
    const lossAddressLine2 = isPHA ? formData.policyAddressLine2 : formData.lossAddressLine2;

    // The policyholder's own contact details + their real policy address — sent as
    // PolicyHolder on every claim, and also as UserDetails when they are the claimant.
    const policyHolderDetails = {
      EmailAddress: formData.email,
      FirstName: formData.firstName,
      LastName: formData.lastName,
      PhoneNumber: formData.phoneNumber,
      PolicyAddress: {
        pyCity: formData.policyCity,
        pyCountry: formData.policyCountry,
        pyPostalCode: formData.policyPostalCode,
        pyStreetAddress: formData.policyAddressLine1,
        pyStreetAddress2: formData.policyAddressLine2
      }
    };

    // When someone other than the policyholder is claiming, UserDetails holds that
    // person's own details instead, with no policy address of their own.
    const blankPolicyAddress = {
      pyCity: '',
      pyCountry: '',
      pyPostalCode: '',
      pyStreetAddress: '',
      pyStreetAddress2: ''
    };

    let userDetails: Record<string, unknown> = policyHolderDetails;
    let otherRelationship = '';

    if (formData.relationship === 'SP') {
      userDetails = {
        EmailAddress: formData.spouseEmail || '',
        FirstName: formData.spouseFirstName || '',
        LastName: formData.spouseLastName || '',
        PhoneNumber: formData.spousePhoneNumber || '',
        PolicyAddress: blankPolicyAddress
      };
    } else if (formData.relationship === 'DP') {
      userDetails = {
        EmailAddress: formData.dependentEmail || '',
        FirstName: formData.dependentFirstName || '',
        LastName: formData.dependentLastName || '',
        PhoneNumber: formData.dependentPhoneNumber || '',
        DateOfBirth: formData.dependentDateOfBirth || '',
        PolicyAddress: blankPolicyAddress
      };
      otherRelationship = formData.dependentRelationship || '';
    } else if (formData.relationship === 'AP') {
      userDetails = {
        EmailAddress: formData.authorisedEmail || '',
        FirstName: formData.authorisedFirstName || '',
        LastName: formData.authorisedLastName || '',
        PhoneNumber: formData.authorisedPhoneNumber || '',
        PolicyAddress: blankPolicyAddress
      };
    } else if (formData.relationship === 'OTH') {
      userDetails = {
        EmailAddress: formData.otherPersonEmail || '',
        FirstName: formData.otherPersonFirstName || '',
        LastName: formData.otherPersonLastName || '',
        PhoneNumber: formData.otherPersonPhoneNumber || '',
        PolicyAddress: blankPolicyAddress
      };
      otherRelationship = formData.otherRelationshipDescription || '';
    }

    userDetails = {
      ...userDetails,
      AuthorisationConfirmation: String(formData.authorisationConfirmed)
    };

    const requestBody = {
      caseTypeID,
      content: 
      {
        CreationSource: "WebForm",
        PolicyNumber: formData.policyNumber,
        DeclarationConsent: formData.declarationConsent,
        Product: formData.schemeOrProduct,
        ServiceNumber: formData.serviceNumber,
        RelationshipWithPolicyHolder: formData.relationship,
        OtherRelationship: otherRelationship,
        TotalClaimAmount: formData.items.reduce((acc, item) => acc + parseFloat(item.claimedAmount), 0),
        TotalPurchasePrice: formData.items.reduce((acc, item) => acc + parseFloat(item.purchasePrice), 0),
        UserDetails: userDetails,
        PolicyHolder: policyHolderDetails,
        ClaimInfo: {
          CrimeReferenceNumber: formData.crimeReferenceNumber,
          IsTheftReportedToPolice: formData.theftReported,
          LossDate: formData.dateOfLoss,
          LossDescription: formData.description,
          LossType: formData.lossType,
          OtherLossType: formData.otherLossType,
          WhereDidThisHappen: formData.lossLocationType,
          LossAddress: {
            pyCity: lossCity,
            pyCountry: lossCountry,
            pyPostalCode: lossPostalCode,
            pyStreetAddress: lossAddressLine1,
            pyStreetAddress2: lossAddressLine2
          }
        },
        ItemsAffected: formData.items.map(item => ({
            ItemCoverType: item.itemCoverType,
            ClaimAmount: item.claimedAmount,
            Description: item.itemDescription,
            ItemType: item.itemType,
            PurchaseDate: item.datePurchased,
            PurchasePrice: item.purchasePrice,
            OtherItemType: item.otherItemType
        }))
      }
    };

    const response = await (window as any).PCore.getRestClient().invokeCustomRestApi(apiPath, {
      method: 'POST',
      body: requestBody,
      headers: {
        'Access-Control-Allow-Origin': '*',
        ...(remoteIp ? { RemoteIP: remoteIp } : {})
      }
    });

    return {
      success: true,
      ID: response.data?.ID,
      message: 'Claim case created successfully'
    };
  } catch (error: unknown) {
    return {
      success: false,
      message: extractPegaErrorMessage(error, 'Failed to create claim case')
    };
  }
};
