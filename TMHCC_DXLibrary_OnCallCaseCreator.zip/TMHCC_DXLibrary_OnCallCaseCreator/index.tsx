import { useEffect, useRef, useState } from 'react';
import { Progress, withConfiguration } from '@pega/cosmos-react-core';

import type { PConnProps } from '../shared/PConnProps';

interface TmhccDxLibraryOnCallCaseCreatorProps extends PConnProps {
  /** Case type class to create when the CTI event fires, e.g. "OPB1HW-SpaceTra-Work-RequestApproval". */
  caseTypeClassName: string;
  /** PubSub event name published by the CTI integration when a call is answered. */
  eventName?: string;
  /** Message shown on the progress ring while the case is being created. */
  loadingMessage?: string;
  enableDebugLogs?: boolean;
}

const DEFAULT_EVENT_NAME = 'CTI ANSWER CALL';
const DEFAULT_LOADING_MESSAGE = 'Creating case…';

let instanceCounter = 0;

function TmhccDxLibraryOnCallCaseCreator(props: TmhccDxLibraryOnCallCaseCreatorProps) {
  const {
    getPConnect,
    caseTypeClassName,
    eventName = DEFAULT_EVENT_NAME,
    loadingMessage = DEFAULT_LOADING_MESSAGE,
    enableDebugLogs = false
  } = props;

  const [isCreating, setIsCreating] = useState(false);
  const isCreatingRef = useRef(false);
  const subscriptionNameRef = useRef(`oncall-case-creator-${(instanceCounter += 1)}`);

  useEffect(() => {
    const pCore = (window as any).PCore;
    if (!pCore?.getPubSubUtils) {
      return undefined;
    }
    if (!caseTypeClassName) {
      console.error('[OnCallCaseCreator] caseTypeClassName is required; not subscribing to', eventName);
      return undefined;
    }

    const subscriptionName = subscriptionNameRef.current;

    const handleAnswerCall = () => {
      if (isCreatingRef.current) {
        if (enableDebugLogs) {
          console.debug('[OnCallCaseCreator] create already in progress, ignoring event', eventName);
        }
        return;
      }

      isCreatingRef.current = true;
      setIsCreating(true);

      if (enableDebugLogs) {
        console.debug('[OnCallCaseCreator] received event, creating case', { eventName, caseTypeClassName });
      }

      // Rest of createWork's options are left at their OOTB defaults (e.g. openCaseViewAfterCreate
      // stays true), so the first create screen is shown as soon as the case is created.
      getPConnect()
        .getActionsApi()
        .createWork(caseTypeClassName, {})
        .then(() => {
          if (enableDebugLogs) {
            console.debug('[OnCallCaseCreator] case created', caseTypeClassName);
          }
        })
        .catch((error: unknown) => {
          console.error('[OnCallCaseCreator] createWork failed', error);
        })
        .finally(() => {
          isCreatingRef.current = false;
          setIsCreating(false);
        });
    };

    pCore.getPubSubUtils().subscribe(eventName, handleAnswerCall, subscriptionName, false);

    return () => {
      pCore.getPubSubUtils().unsubscribe(eventName, subscriptionName);
    };
  }, [caseTypeClassName, eventName, enableDebugLogs, getPConnect]);

  if (!isCreating) {
    return null;
  }

  return (
    <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', minHeight: '4rem', width: '100%' }}>
      <Progress variant='ring' message={loadingMessage} placement='local' />
    </div>
  );
}

export default withConfiguration(TmhccDxLibraryOnCallCaseCreator);
