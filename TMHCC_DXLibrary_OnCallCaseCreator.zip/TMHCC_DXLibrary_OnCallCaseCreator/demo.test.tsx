import { act, render, screen, waitFor } from '@testing-library/react';
import { composeStories } from '@storybook/react';
import '@testing-library/jest-dom';

import * as DemoStories from './demo.stories';
import { configProps } from './mock';

const { BaseTmhccDxLibraryOnCallCaseCreator } = composeStories(DemoStories);

test('creates a case when the CTI answer call event is published', async () => {
  render(<BaseTmhccDxLibraryOnCallCaseCreator />);

  expect(screen.queryByText(configProps.loadingMessage)).not.toBeInTheDocument();

  act(() => {
    (window as any).PCore.getPubSubUtils().publish(configProps.eventName, {});
  });

  expect(await screen.findByText(configProps.loadingMessage)).toBeVisible();

  await waitFor(() => {
    expect(screen.queryByText(configProps.loadingMessage)).not.toBeInTheDocument();
  });
});

test('ignores a second event while a create is already in progress', async () => {
  render(<BaseTmhccDxLibraryOnCallCaseCreator />);

  act(() => {
    (window as any).PCore.getPubSubUtils().publish(configProps.eventName, {});
    (window as any).PCore.getPubSubUtils().publish(configProps.eventName, {});
  });

  expect(await screen.findByText(configProps.loadingMessage)).toBeVisible();

  await waitFor(() => {
    expect(screen.queryByText(configProps.loadingMessage)).not.toBeInTheDocument();
  });
});
