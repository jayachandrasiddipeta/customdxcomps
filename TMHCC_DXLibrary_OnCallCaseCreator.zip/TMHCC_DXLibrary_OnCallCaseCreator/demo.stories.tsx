/* eslint-disable react/jsx-no-useless-fragment */
import type { Meta, StoryObj } from '@storybook/react';
import { Button } from '@pega/cosmos-react-core';

import TmhccDxLibraryOnCallCaseCreator from './index';

import { configProps } from './mock';

const meta: Meta<typeof TmhccDxLibraryOnCallCaseCreator> = {
  title: 'TmhccDxLibraryOnCallCaseCreator',
  component: TmhccDxLibraryOnCallCaseCreator,
  excludeStories: /.*Data$/
};

export default meta;
type Story = StoryObj<typeof TmhccDxLibraryOnCallCaseCreator>;

if (!window.PCore) {
  window.PCore = {} as any;
}

const pubSubSubscribers: Record<string, (payload?: any) => void> = {};

window.PCore.getPubSubUtils = () => {
  return {
    subscribe: (eventType: string, subscriptionItem: (payload?: any) => void) => {
      pubSubSubscribers[eventType] = subscriptionItem;
    },
    unsubscribe: (eventType: string) => {
      delete pubSubSubscribers[eventType];
    },
    publish: (eventType: string, payload?: any) => {
      pubSubSubscribers[eventType]?.(payload);
    }
  } as any;
};

export const BaseTmhccDxLibraryOnCallCaseCreator: Story = (args: any) => {
  const props = {
    caseTypeClassName: configProps.caseTypeClassName,
    eventName: configProps.eventName,
    loadingMessage: configProps.loadingMessage,

    getPConnect: () => {
      return {
        getActionsApi: () => {
          return {
            createWork: (className: string, options: any) => {
              console.log('[Storybook] createWork called', className, options);
              return new Promise(resolve => {
                setTimeout(resolve, 800);
              });
            }
          };
        }
      };
    }
  };

  return (
    <>
      <Button onClick={() => window.PCore.getPubSubUtils().publish(configProps.eventName, {})}>
        Simulate CTI answer call
      </Button>
      <TmhccDxLibraryOnCallCaseCreator {...props} {...args} />
    </>
  );
};

BaseTmhccDxLibraryOnCallCaseCreator.args = {
  enableDebugLogs: configProps.enableDebugLogs
};
