export const configProps = {
  caseTypeClassName: 'OPB1HW-SpaceTra-Work-RequestApproval',
  eventName: 'CTI ANSWER CALL',
  loadingMessage: 'Creating case…',
  enableDebugLogs: false
};
